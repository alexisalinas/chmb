package com.banamex.cops.update_offer.audit;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.testutil.TestData;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** Requiere Logback como implementación de logging. */
class AuditLogServiceTest {

    private final JsonMapper mapper = JsonMapper.builder().build();
    private AuditLogService service;
    private ListAppender<ILoggingEvent> appender;
    private Logger logger;
    private UpdateOfferHeaders headers;

    @BeforeEach
    void setUp() {
        service = new AuditLogService(mapper);
        ReflectionTestUtils.setField(service, "pointsEnabled", "1001");
        headers = TestData.headers();

        logger = (Logger) LoggerFactory.getLogger(AuditLogService.class);
        appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
    }

    @AfterEach
    void tearDown() {
        logger.detachAppender(appender);
    }

    private List<ILoggingEvent> eventos() {
        return appender.list;
    }

    private String mensaje() {
        return eventos().get(0).getFormattedMessage();
    }

    /** El JSON es todo lo que va después de la primera línea ("[REQUEST] uuid=..."). */
    private JsonNode json(String mensaje) {
        return mapper.readTree(mensaje.substring(mensaje.indexOf('\n') + 1));
    }

    // ------------------------------------------------------------ log del request: lo que recibe el micro

    @Test
    void logRequest_escribeLosHeadersYElJsonDelBody() {
        service.logRequest(headers, List.of(TestData.request()));

        assertThat(eventos()).hasSize(1);
        assertThat(mensaje()).startsWith("[REQUEST] uuid=uuid-1\n");
        JsonNode j = json(mensaje());
        assertThat(j.get("headers").get("uuid").asText()).isEqualTo("uuid-1");
        assertThat(j.get("headers").get("ChannelId").asText()).isEqualTo("CAT");
        assertThat(j.get("headers").get("Org").asText()).isEqualTo("1");
        assertThat(j.get("headers").get("UserID").asText()).isEqualTo("92023797");
        assertThat(j.get("body").isArray()).isTrue();
        assertThat(j.get("body").get(0).get("campaignId").asText()).isEqualTo("CAMP001");
    }

    @Test
    void logRequest_conVariasOfertasEscribeTodasEnElBody() {
        service.logRequest(headers, List.of(TestData.request(), TestData.minimalRequest()));

        assertThat(json(mensaje()).get("body")).hasSize(2);
    }

    @Test
    void logRequest_noLlevaLaEstructuraDeBW_ClientDetailsNiXml() {
        service.logRequest(headers, List.of(TestData.request()));

        assertThat(mensaje()).doesNotContain("ClientDetails", "RqHeader", "ApplicationID", "ComponentName",
                "TransactionID", "<root>", "<Header>", "Logging Service");
    }

    @Test
    void logRequest_enmascaraElNumeroDeTarjeta() {
        service.logRequest(headers, List.of(TestData.request()));

        assertThat(json(mensaje()).get("body").get(0).get("cardNumber").asText()).isEqualTo("************5678");
        assertThat(mensaje()).doesNotContain("1234567812345678");
    }

    @Test
    void logRequest_enmascaraLosHeadersDeSeguridadSinImportarMayusculas() {
        Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        all.put("uuid", "uuid-1");
        all.put("Authorization", "Bearer secreto");
        all.put("COOKIE", "sesion=abc");
        all.put("x-api-key", "clave");
        headers.setAll(all);

        service.logRequest(headers, List.of(TestData.request()));

        JsonNode h = json(mensaje()).get("headers");
        assertThat(h.get("Authorization").asText()).isEqualTo("****");
        assertThat(h.get("COOKIE").asText()).isEqualTo("****");
        assertThat(h.get("x-api-key").asText()).isEqualTo("****");
        assertThat(h.get("uuid").asText()).isEqualTo("uuid-1");
        assertThat(mensaje()).doesNotContain("secreto", "sesion=abc", "clave");
    }

    @Test
    void logRequest_sinElMapaCompletoDeHeaders_usaLosDelSwagger() {
        UpdateOfferHeaders soloSwagger = UpdateOfferHeaders.builder()
                .uuid("u-9").channelId("CAT").countryCode("MX").businessCode("COP").sid("s-1").host("api.test").build();

        service.logRequest(soloSwagger, List.of(TestData.request()));

        JsonNode h = json(mensaje()).get("headers");
        assertThat(h.get("uuid").asText()).isEqualTo("u-9");
        assertThat(h.get("ChannelId").asText()).isEqualTo("CAT");
        assertThat(h.get("countryCode").asText()).isEqualTo("MX");
        assertThat(h.get("businessCode").asText()).isEqualTo("COP");
        assertThat(h.get("sid").asText()).isEqualTo("s-1");
        assertThat(h.has("Accept-Language")).isFalse();   // no llegó: no se inventa
    }

    @Test
    void logRequest_conHeadersOBodyNulos_noLanzaExcepcion() {
        assertThatCode(() -> service.logRequest(null, null)).doesNotThrowAnyException();
        assertThat(eventos()).hasSize(1);
    }

    // ------------------------------------------------------------ log de la respuesta: lo que responde el micro (End)

    private UpdateOfferResponse respuesta(String code, String description) {
        UpdateOfferResponse r = new UpdateOfferResponse();
        r.setCode(code);
        r.setDescription(description);
        return r;
    }

    @Test
    void logResponse_escribeElJsonQueResponde() {
        service.logResponse(headers, List.of(respuesta("COP_UPDOF_0", "Successfully update offer off:mx:C1:W1:111")));

        assertThat(eventos()).hasSize(1);
        assertThat(mensaje()).startsWith("[RESPONSE] uuid=uuid-1\n");
        JsonNode j = json(mensaje());
        assertThat(j.isArray()).isTrue();
        assertThat(j.get(0).get("code").asText()).isEqualTo("COP_UPDOF_0");
        assertThat(j.get(0).get("description").asText()).isEqualTo("Successfully update offer off:mx:C1:W1:111");
    }

    @Test
    void logResponse_conVariasOfertasEscribeUnElementoPorOferta_enOrden() {
        service.logResponse(headers, List.of(respuesta("A", "uno"), respuesta("ERROR", "dos")));

        JsonNode j = json(mensaje());
        assertThat(j).hasSize(2);
        assertThat(j.get(0).get("code").asText()).isEqualTo("A");
        assertThat(j.get(1).get("code").asText()).isEqualTo("ERROR");
    }

    @Test
    void logResponse_noLlevaLaEstructuraDeBW() {
        service.logResponse(headers, List.of(respuesta("A", "uno")));
        assertThat(mensaje()).doesNotContain("LogPayload", "RsHeader", "<UpdateOfferRs>", "Logging Service");
    }

    @Test
    void logResponse_conListaONulaYHeadersNulos_noLanzaExcepcion() {
        assertThatCode(() -> service.logResponse(null, null)).doesNotThrowAnyException();
        assertThatCode(() -> service.logResponse(headers, List.of())).doesNotThrowAnyException();
    }

    // ------------------------------------------------------------ nunca debe afectar la respuesta

    @SuppressWarnings("unchecked")
    @Test
    void siFallaElLog_noSePropagaLaExcepcion_yQuedaUnWarn() {
        JsonMapper roto = mock(JsonMapper.class);
        when(roto.convertValue(any(), eq(Map.class))).thenThrow(new IllegalStateException("no serializa"));
        AuditLogService conFalla = new AuditLogService(roto);
        ReflectionTestUtils.setField(conFalla, "pointsEnabled", "1001");

        assertThatCode(() -> conFalla.logRequest(headers, List.of(TestData.request()))).doesNotThrowAnyException();

        assertThat(eventos()).hasSize(1);
        assertThat(eventos().get(0).getLevel()).isEqualTo(Level.WARN);
        assertThat(mensaje()).contains("No se pudo escribir el log del request", "no serializa");
    }

    @Test
    void elNivelDeEscrituraEsInfo() {
        service.logRequest(headers, List.of(TestData.request()));
        service.logResponse(headers, List.of(respuesta("A", "uno")));

        assertThat(eventos()).extracting(ILoggingEvent::getLevel).containsOnly(Level.INFO);
    }

    // ------------------------------------------------------------ AuditPointsEnabled: una posición por cada log

    private int escritos(String banderas, boolean request) {
        appender.list.clear();
        ReflectionTestUtils.setField(service, "pointsEnabled", banderas);
        if (request) {
            service.logRequest(headers, List.of(TestData.request()));
        } else {
            service.logResponse(headers, List.of(respuesta("A", "uno")));
        }
        return eventos().size();
    }

    @Test
    void logDeLaRespuesta_seActivaSoloConLaPosicionCuatro() {
        for (String valor : new String[]{"0001", "1001", "1111", "abc1"}) {
            assertThat(escritos(valor, false)).as(valor).isEqualTo(1);
        }
        for (String valor : new String[]{"0000", "1000", "1110", "0100", "0010", "001", "1", "", null}) {
            assertThat(escritos(valor, false)).as(String.valueOf(valor)).isZero();
        }
    }

    @Test
    void logDelRequest_seActivaSoloConLaPosicionUno() {
        for (String valor : new String[]{"1000", "1001", "1110", "1"}) {
            assertThat(escritos(valor, true)).as(valor).isEqualTo(1);
        }
        for (String valor : new String[]{"0001", "0111", "0000", "", null}) {
            assertThat(escritos(valor, true)).as(String.valueOf(valor)).isZero();
        }
    }

    @Test
    void conLaPosicionUnoApagada_elRequestNoSeRegistraPeroLaRespuestaSi() {
        ReflectionTestUtils.setField(service, "pointsEnabled", "0001");
        service.logRequest(headers, List.of(TestData.request()));
        service.logResponse(headers, List.of(respuesta("A", "uno")));

        assertThat(eventos()).hasSize(1);
        assertThat(mensaje()).startsWith("[RESPONSE]");
    }

    @Test
    void conLaPosicionCuatroApagada_laRespuestaNoSeRegistraPeroElRequestSi() {
        ReflectionTestUtils.setField(service, "pointsEnabled", "1000");
        service.logRequest(headers, List.of(TestData.request()));
        service.logResponse(headers, List.of(respuesta("A", "uno")));

        assertThat(eventos()).hasSize(1);
        assertThat(mensaje()).startsWith("[REQUEST]");
    }

    @Test
    void conElValorRealDeBW_1001_seRegistranLosDos() {
        service.logRequest(headers, List.of(TestData.request()));
        service.logResponse(headers, List.of(respuesta("A", "uno")));

        assertThat(eventos()).hasSize(2);
    }

    @Test
    void conLaAuditoriaApagada_noSeEscribeNada() {
        ReflectionTestUtils.setField(service, "pointsEnabled", "0000");
        service.logRequest(headers, List.of(TestData.request()));
        service.logResponse(headers, List.of(respuesta("A", "uno")));

        assertThat(eventos()).isEmpty();
    }

    // ------------------------------------------------------------ enmascarado

    @Test
    void mask_dejaSoloLosUltimosCuatroDigitos() {
        assertThat(AuditLogService.mask("1234567812345678")).isEqualTo("************5678");
        assertThat(AuditLogService.mask("1234")).isEqualTo("1234");
        assertThat(AuditLogService.mask("12")).isEqualTo("12");
        assertThat(AuditLogService.mask(null)).isNull();
    }
}
