package com.banamex.cops.update_offer.kafka;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Modo de prueba: no envía nada. El mensaje que se enviaría ya lo escribe FulFillkafkaSender
 * en el log ("[KAFKA] Envía"), con la tarjeta enmascarada.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "offer.kafka.mode", havingValue = "dry-run", matchIfMissing = true)
public class DryRunOfferPublisher implements OfferPublisher {

    @Override
    public String publish(String refId, String json) {
        log.info("[KAFKA] dry-run: no se publicó refId={}", refId);
        return "dry-run";
    }
}
