package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.log.header.RqHeaderDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.banamex.cops.update_offer.mapper.XmlUtil.tag;

/**
 * UpdateOfferRequest (REST) -> XML que se manda al EMS: Envelope con RqHeader + evento UpdateOffer con los
 * OtherProperties, sin URLs. (El log del request ya no usa XML: ver AuditLogService.)
 */
@Component
@RequiredArgsConstructor
public class UpdateOfferRequestXmlMapper {

    private final RqHeaderXmlMapper rqHeaderXmlMapper;
    private final OfferEventMapper offerEventMapper;

    /** BW: _nm_ del evento (nombre del elemento del cuerpo). */
    @Value("${update-offer.ems.body-element:UpdateOffer}")
    private String bodyElement;

    // =====================================================================
    //  1) XML hacia el EMS
    // =====================================================================
    public String toEmsXml(UpdateOfferRequest rq, RqHeaderDTO header,
                           String tzResponseCode, MapRequestResultDTO tz) {
        Map<String, String> fields = offerEventMapper.map(rq, header, tzResponseCode, tz);

        // Sin namespaces ni URLs: elementos simples
        StringBuilder x = new StringBuilder();
        x.append("<Envelope>\n");
        x.append("   <Header>\n");
        x.append(rqHeaderXmlMapper.toEnvelopeHeader(header, "      "));
        x.append("   </Header>\n");
        x.append("   <Body>\n");
        x.append("      <").append(bodyElement).append(">\n");
        fields.forEach((k, v) -> tag(x, "         ", k, v));
        x.append("      </").append(bodyElement).append(">\n");
        x.append("   </Body>\n");
        x.append("</Envelope>");
        return x.toString();
    }

}
