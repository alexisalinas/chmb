package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailsDTO;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntityDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Equivale al {@code SetVariable} del proceso de BW {@code /BW/StartUp/startUpSuppression}: arma la lista de
 * entidades suprimidas ({@code SuppressedEntitiesList}) a partir de las filas de {@code COP_SUPP_CHNL}
 * ({@code FetchChannels}) y {@code COP_SUPP_OPR} ({@code FetchOperations}).
 * <p>
 * Por cada canal se escribe una entidad (país, modo, canal, banderas y sistema origen) y sus
 * {@code OperationDetails} dependen de las banderas del canal (igual que el {@code Choose} de BW):
 * <ul>
 *   <li>{@code SUPPRESSION_FLAG = "N"} y {@code OPERATION_FLAG = "N"}: sin detalles.</li>
 *   <li>{@code "Y"} y {@code "Y"}: solo las operaciones de ese canal ({@code REQCHANNEL = CHANNEL_ID}), con
 *       {@code Operation_Flag} fija en {@code "Y"}.</li>
 *   <li>{@code SUPPRESSION_FLAG = "Y"} y {@code OPERATION_FLAG = "N"}: todas las operaciones, con su propio
 *       {@code OPERATION_SUPPRESS_FLAG}.</li>
 *   <li>Cualquier otra combinación: sin detalles.</li>
 * </ul>
 */
@Component
public class StartUpSuppressionLoader {

    /**
     * Arma la lista de entidades suprimidas.
     *
     * @param channels   filas de {@code COP_SUPP_CHNL} (pueden ser nulas)
     * @param operations filas de {@code COP_SUPP_OPR} (pueden ser nulas)
     * @return la lista, con una entidad por canal y en el mismo orden
     */
    public SuppressedEntitiesListRoot build(List<CopSuppressionChannel> channels, List<CopSuppressionOperation> operations) {
        List<CopSuppressionOperation> ops = operations == null ? List.of() : operations;
        List<SuppressedEntityDTO> entities = new ArrayList<>();
        if (channels != null) {
            for (CopSuppressionChannel channel : channels) {
                entities.add(entity(channel, details(channel, ops)));
            }
        }
        return SuppressedEntitiesListRoot.builder().suppressedEntities(entities).build();
    }

    private SuppressedEntityDTO entity(CopSuppressionChannel c, List<OperationDetailsDTO> details) {
        return SuppressedEntityDTO.builder()
                .countryCode(c.countryCode())
                .mode(c.reqMode())
                .channelId(c.channelId())
                .suppressionFlag(c.suppressionFlag())
                .operationFlag(c.operationFlag())
                .sourceSystem(c.sourceSystem())
                .operationDetails(details)
                .build();
    }

    /** El {@code Choose} de BW: los detalles de operación según las banderas del canal. */
    private List<OperationDetailsDTO> details(CopSuppressionChannel c, List<CopSuppressionOperation> ops) {
        List<OperationDetailsDTO> out = new ArrayList<>();
        if ("Y".equals(c.suppressionFlag()) && "Y".equals(c.operationFlag())) {
            for (CopSuppressionOperation o : ops) {
                // $FetchOperations/resultSet/Record[REQCHANNEL = current()/CHANNEL_ID]
                if (o.reqChannel() != null && o.reqChannel().equals(c.channelId())) {
                    out.add(detail(o, "Y"));                               // Operation_Flag = "Y" (constante)
                }
            }
        } else if ("Y".equals(c.suppressionFlag()) && "N".equals(c.operationFlag())) {
            for (CopSuppressionOperation o : ops) {                       // todas las operaciones
                out.add(detail(o, o.operationSuppressFlag()));             // Operation_Flag = OPERATION_SUPPRESS_FLAG
            }
        }
        return out;
    }

    private OperationDetailsDTO detail(CopSuppressionOperation o, String operationFlag) {
        return OperationDetailsDTO.builder()
                .operationName(o.operationName())
                .operationFlag(operationFlag)
                .reqChannel(o.reqChannel())
                .build();
    }
}
