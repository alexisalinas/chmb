-- ============================================================================
-- PRUEBA DE LAS TABLAS DE SUPRESION (las dos consultas del proceso /BW/StartUp/startUpSuppression)
-- Corre cada bloque por separado (F9) con la conexion UAT_COPS (la misma base que usa el micro).
-- ============================================================================

-- 1) Las dos sentencias exactas de BW (FetchChannels y FetchOperations)
SELECT * FROM COP_SUPP_CHNL;
SELECT * FROM COP_SUPP_OPR;

-- 2) Cuantas filas tiene cada una
SELECT (SELECT COUNT(*) FROM COP_SUPP_CHNL) AS canales,
       (SELECT COUNT(*) FROM COP_SUPP_OPR)  AS operaciones
  FROM dual;

-- 3) Faltan columnas? (debe salir VACIO: las 9 columnas que lee el micro existen)
WITH req (tabla, columna) AS (
  SELECT 'COP_SUPP_CHNL', 'COUNTRY_CODE' FROM dual UNION ALL
  SELECT 'COP_SUPP_CHNL', 'REQMODE' FROM dual UNION ALL
  SELECT 'COP_SUPP_CHNL', 'CHANNEL_ID' FROM dual UNION ALL
  SELECT 'COP_SUPP_CHNL', 'SUPPRESSION_FLAG' FROM dual UNION ALL
  SELECT 'COP_SUPP_CHNL', 'OPERATION_FLAG' FROM dual UNION ALL
  SELECT 'COP_SUPP_CHNL', 'SOURCE_SYSTEM' FROM dual UNION ALL
  SELECT 'COP_SUPP_OPR', 'OPERATION_NAME' FROM dual UNION ALL
  SELECT 'COP_SUPP_OPR', 'OPERATION_SUPPRESS_FLAG' FROM dual UNION ALL
  SELECT 'COP_SUPP_OPR', 'REQCHANNEL' FROM dual
)
SELECT req.tabla, req.columna AS columna_que_falta
  FROM req
 WHERE NOT EXISTS (SELECT 1 FROM all_tab_columns
                    WHERE all_tab_columns.table_name = req.tabla
                      AND all_tab_columns.column_name = req.columna);

-- 4) Que camino del Choose toma cada canal (como el SetVariable de BW)
SELECT CHANNEL_ID, SUPPRESSION_FLAG, OPERATION_FLAG,
       CASE
         WHEN SUPPRESSION_FLAG = 'Y' AND OPERATION_FLAG = 'Y' THEN 'solo las operaciones de ese canal (flag Y)'
         WHEN SUPPRESSION_FLAG = 'Y' AND OPERATION_FLAG = 'N' THEN 'todas las operaciones (con su propia flag)'
         ELSE 'sin detalles de operacion'
       END AS detalles
  FROM COP_SUPP_CHNL;
