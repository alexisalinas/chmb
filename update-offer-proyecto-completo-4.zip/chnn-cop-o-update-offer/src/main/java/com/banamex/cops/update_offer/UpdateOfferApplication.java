package com.banamex.cops.update_offer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Arranque del microservicio {@code chnn-cop-o-update-offer}. */
@SpringBootApplication(scanBasePackages = "com.banamex.cops.update_offer")
public class UpdateOfferApplication {

    public static void main(String[] args) {
        SpringApplication.run(UpdateOfferApplication.class, args);
    }
}
