package com.banamex.cops.update_offer.kafka;

/** Envía el evento a un destino. */
public interface OfferPublisher {
    String publish(String refId, String json) throws Exception;
}
