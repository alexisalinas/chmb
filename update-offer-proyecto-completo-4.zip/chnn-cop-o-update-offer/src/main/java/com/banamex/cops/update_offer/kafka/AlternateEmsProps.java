package com.banamex.cops.update_offer.kafka;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/** Destino alterno del evento: una cola en otro EMS (propiedades offer.alternate-ems.* del yml). */
@Data
@Component
@ConfigurationProperties(prefix = "offer.alternate-ems")
public class AlternateEmsProps {

    private boolean enabled = false;

    /** Bean JmsTemplate de la conexión al EMS alterno (el jmsTemplateName de su conexión en el yml). */
    private String jmsTemplateName = "alternateEmsJmsTemplate";

    private String queue;

    /** json | envelope. */
    private String messageFormat = "json";

    /** Expiración del mensaje en milisegundos (0 = no expira). */
    private long timeToLiveMs = 0;
}
