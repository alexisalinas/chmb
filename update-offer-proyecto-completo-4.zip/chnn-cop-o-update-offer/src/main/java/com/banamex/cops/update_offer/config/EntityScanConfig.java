package com.banamex.cops.update_offer.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;

/** Registra las entidades JPA de la librería para evitar "Not a managed type". */
@Configuration
@EntityScan(basePackages = {"com.banamex.cops.update_offer", "com.banamex.cops.app"})
public class EntityScanConfig {
}
