package com.banamex.cops.update_offer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code UpdateOfferApplication}. */
class UpdateOfferApplicationTest {

    @Test
    void escaneaSoloLosBeansDelMicro_noLosDeLaLibreria() {
        // Given
        SpringBootApplication anotacion = UpdateOfferApplication.class.getAnnotation(SpringBootApplication.class);

        // When / Then
        assertThat(anotacion.scanBasePackages()).containsExactly("com.banamex.cops.update_offer");
    }
}
