package com.banamex.cops.update_offer.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.domain.EntityScanPackages;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Configuration;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code EntityScanConfig}. */
class EntityScanConfigTest {

    @Test
    void escaneaLasEntidadesDeLaLibreria() {
        // Given
        EntityScan entityScan = EntityScanConfig.class.getAnnotation(EntityScan.class);

        // When / Then
        assertThat(entityScan).isNotNull();
        assertThat(entityScan.basePackages()).contains("com.banamex.cops.app", "com.banamex.cops.update_offer");
    }

    @Test
    void registraLosPaquetesEnElContexto_sinImportarCualEsLaClasePrincipal() {
        // Given
        ApplicationContextRunner runner = new ApplicationContextRunner().withUserConfiguration(EntityScanConfig.class);

        // When / Then
        runner.run(ctx -> assertThat(EntityScanPackages.get(ctx).getPackageNames())
                .contains("com.banamex.cops.app", "com.banamex.cops.update_offer"));
    }

    @Test
    void siLaClasePrincipalTambienLoDeclara_losPaquetesSeUnenSinFallar() {
        // Given
        ApplicationContextRunner runner = new ApplicationContextRunner()
                .withUserConfiguration(EntityScanConfig.class, OtraConEntityScan.class);

        // When / Then
        runner.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(EntityScanPackages.get(ctx).getPackageNames()).contains("com.banamex.cops.app", "otro.paquete");
        });
    }

    @Configuration
    @EntityScan(basePackages = "otro.paquete")
    static class OtraConEntityScan {
    }
}
