package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.testutil.TestData;
import org.junit.jupiter.api.Test;

import java.util.List;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Pruebas unitarias de {@code UpdateOfferMapper}. */
@ExtendWith(MockitoExtension.class)
class UpdateOfferMapperTest {

    @Mock UpdateOfferRequestXmlMapper requestXmlMapper;
    @Mock UpdateOfferResponseXmlMapper responseXmlMapper;
    @InjectMocks UpdateOfferMapper mapper;

    @Test
    void toEmsXml_delegaEnElMapperDeRequest() {
        // Given
        var rq = TestData.request();
        var requestTime = TestData.requestTime();
        var tz = new MapRequestResultDTO();
        when(requestXmlMapper.toEmsXml(rq, requestTime, "client-1", "COP_TZCOD_000", tz)).thenReturn("<xml/>");

        // When / Then
        assertThat(mapper.toEmsXml(rq, requestTime, "client-1", "COP_TZCOD_000", tz)).isEqualTo("<xml/>");
    }

    @Test
    void toRestResponse_delegaEnElMapperDeRespuesta() {
        // Given
        UpdateOfferResponse rs = new UpdateOfferResponse();
        when(responseXmlMapper.fromReply("<r/>")).thenReturn(rs);

        // When / Then
        assertThat(mapper.toRestResponse("<r/>")).isSameAs(rs);
    }

    @Test
    void toRestResponses_delegaEnElMapperDeRespuesta() {
        // Given
        List<UpdateOfferResponse> lista = List.of(new UpdateOfferResponse(), new UpdateOfferResponse());
        when(responseXmlMapper.fromReplies("<x/>")).thenReturn(lista);

        // When / Then
        assertThat(mapper.toRestResponses("<x/>")).isSameAs(lista);
        verify(responseXmlMapper).fromReplies("<x/>");
    }

    @Test
    void emsProperties_delegaEnElMapperDelXml() {
        // Given
        var rq = TestData.request();
        var requestTime = TestData.requestTime();
        var tz = new MapRequestResultDTO();
        var esperadas = java.util.Map.of("_nm_", "UpdateOffer");
        when(requestXmlMapper.toEmsProperties(rq, requestTime, "client-1", "COP_TZCOD_000", tz)).thenReturn(esperadas);

        // When / Then
        assertThat(mapper.toEmsProperties(rq, requestTime, "client-1", "COP_TZCOD_000", tz)).isSameAs(esperadas);
    }
}
