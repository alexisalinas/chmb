package com.banamex.cops.update_offer.kafka;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.jms.core.JmsTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Pruebas unitarias de {@code EventDestinations}. */
class EventDestinationsTest {

    private OfferKafkaProps kafka;
    private AlternateEmsProps alterno;
    private BeanFactory beans;
    private EventDestinations destinos;

    @BeforeEach
    void setUp() {
        kafka = new OfferKafkaProps();
        kafka.setMode("jms");
        kafka.setQueue("cola.kafka");
        alterno = new AlternateEmsProps();
        alterno.setQueue("cola.alterna");
        beans = mock(BeanFactory.class);
        destinos = new EventDestinations(kafka, alterno, beans);
    }

    @Test
    void conLosDosApagados_noHayDestinos() {
        // Given
        kafka.setBridgeEnabled(false);
        alterno.setEnabled(false);

        // When / Then
        assertThat(destinos.enabled()).isEmpty();
    }

    @Test
    void soloEmsAlterno() {
        // Given
        alterno.setEnabled(true);

        // When / Then
        assertThat(destinos.enabled()).extracting(EventDestinations.EventDestination::tag).containsExactly("EMS-ALTERNO");
    }

    @Test
    void losDosEncendidos_primeroKafkaYLuegoElAlterno() {
        // Given
        kafka.setBridgeEnabled(true);
        alterno.setEnabled(true);

        // When / Then
        assertThat(destinos.enabled()).extracting(EventDestinations.EventDestination::name).containsExactly("Kafka", "EMS alterno");
    }

    @Test
    void unCambioEnElYmlSeRespetaEnElSiguienteEnvio() {
        // Given
        alterno.setEnabled(false);
        assertThat(destinos.enabled()).isEmpty();

        // When
        alterno.setEnabled(true);

        // Then
        assertThat(destinos.enabled()).hasSize(1);
    }

    @Test
    void elJmsTemplateSePideAlPublicar_noAlArmarLosDestinos() {
        // Given
        alterno.setEnabled(true);

        // When
        destinos.enabled();

        // Then
        verify(beans, never()).getBean(eq("alternateEmsJmsTemplate"), eq(JmsTemplate.class));
    }

    @Test
    void elAlternoUsaElJmsTemplateConfigurado() throws Exception {
        // Given
        alterno.setEnabled(true);
        alterno.setJmsTemplateName("otroTemplate");
        JmsTemplate jms = mock(JmsTemplate.class);
        when(beans.getBean("otroTemplate", JmsTemplate.class)).thenReturn(jms);

        // When
        destinos.enabled().get(0).publisher().publish("ref1", "{}");

        // Then
        verify(beans).getBean("otroTemplate", JmsTemplate.class);
    }

    @Test
    void siNoExisteElJmsTemplate_elErrorDiceQueRevisar() {
        // Given
        alterno.setEnabled(true);
        when(beans.getBean("alternateEmsJmsTemplate", JmsTemplate.class))
                .thenThrow(new NoSuchBeanDefinitionException("alternateEmsJmsTemplate"));

        // When / Then
        assertThatThrownBy(() -> destinos.enabled().get(0).publisher().publish("ref1", "{}"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("alternateEmsJmsTemplate")
                .hasMessageContaining("jmsTemplateName");
    }

    @Test
    void enDryRun_noSeConectaANingunEms() throws Exception {
        // Given
        kafka.setMode("dry-run");
        kafka.setBridgeEnabled(true);
        alterno.setEnabled(true);

        // When
        for (EventDestinations.EventDestination d : destinos.enabled()) {
            assertThat(d.publisher().publish("ref1", "{}")).isEqualTo("dry-run");
        }

        // Then
        verify(beans, never()).getBean(org.mockito.ArgumentMatchers.anyString(), eq(JmsTemplate.class));
    }
}
