# Destinos del evento (Kafka y EMS alterno)

El micro arma el evento (JSON) una vez y lo manda a cada destino activo. Cada destino se prende y apaga en el yml.

| Destino | Interruptor | Conexión | Cola |
|---|---|---|---|
| Kafka (bridge) | `offer.kafka.bridge-enabled` (hoy `false`) | `updateOfferJmsTemplate` (el EMS de siempre) | `offer.kafka.queue` |
| EMS alterno | `offer.alternate-ems.enabled` (hoy `true`) | `alternateEmsJmsTemplate` (plataforma `banamex-cops-alterno`) | `offer.alternate-ems.queue` |

- `offer.kafka.enabled: false` apaga el evento completo. `offer.kafka.mode: dry-run` solo escribe en el log, en todos los destinos.
- Si un destino falla, el otro se envía igual. La respuesta del micro no cambia.
- Logs: `[EMS-ALTERNO] Envía` / `[EMS-ALTERNO] Resultado: …`, `[KAFKA] Resultado: …`; con los dos activos, `[KAFKA+EMS-ALTERNO] Envía`.

## Datos que faltan del EMS alterno (están con `CAMBIAR`)

| Dato | Dónde |
|---|---|
| URL y puerto | `platforms[banamex-cops-alterno].connections[0].brokerUrl` |
| Usuario, contraseña y certificado | Hoy toma los del EMS actual (`broker-config`); si son otros, cámbialos en esa conexión |
| Nombre exacto de la cola | `offer.alternate-ems.queue` |
| Confianza en el servidor | Agregar su certificado y su CA al truststore (`-Djavax.net.ssl.trustStore`) |

## Bean `alternateEmsJmsTemplate`

Lo crea `JmsConfig` (beans `alternateEmsConnectionFactory` y `alternateEmsJmsTemplate`), solo si `offer.alternate-ems.enabled` es `true`. Busca en el yml la conexión cuyo `jmsTemplateName` es `alternateEmsJmsTemplate`, y se crea hasta el primer envío: si faltan datos del EMS alterno, la app arranca igual.
