package com.banamex.cops.update_offer.mapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.fasterxml.jackson.databind.json.JsonMapper;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias de {@code UserTextParser}.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class UserTextParserTest {

    private UserTextParser parser;

    @BeforeEach
    void setUp() {
        parser = new UserTextParser(JsonMapper.builder().build());
    }

    @Test
    void nullOVacio_devuelveMapaVacio() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(parser.parse(null)).isEmpty();
        assertThat(parser.parse("")).isEmpty();
        assertThat(parser.parse("   ")).isEmpty();
    }

    @Test
    void objetoConClaves_seLeenPorIndice() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        Map<Integer, String> r = parser.parse("{\"userField1\":\"a\",\"UserField2\":\"b\",\"USERFIELD30\":\"c\"}");

        // Then
        assertThat(r).containsEntry(1, "a").containsEntry(2, "b").containsEntry(30, "c").hasSize(3);
    }

    @Test
    void formatoParameterNameParameterValue_delSwagger() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        Map<Integer, String> r = parser.parse("{\"parameterName\":\"userField1\",\"parameterValue\":\"This offer is exclusive\"}");

        // Then
        assertThat(r).containsOnlyKeys(1).containsEntry(1, "This offer is exclusive");
    }

    @Test
    void arregloDeParameterNameParameterValue() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        Map<Integer, String> r = parser.parse(
                "[{\"parameterName\":\"userField1\",\"parameterValue\":\"a\"},"
              + "{\"parameterName\":\"userField7\",\"parameterValue\":\"g\"}]");

        // Then
        assertThat(r).containsEntry(1, "a").containsEntry(7, "g").hasSize(2);
    }

    @Test
    void ignoraLosNombresFueraDeRango() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        Map<Integer, String> r = parser.parse(
                "{\"userField0\":\"x\",\"userField101\":\"y\",\"userField100\":\"ok\",\"otroCampo\":\"z\"}");

        // Then
        assertThat(r).containsOnlyKeys(100).containsEntry(100, "ok");
    }

    @Test
    void jsonInvalido_noLanzaExcepcionYDevuelveVacio() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(parser.parse("{esto no es json")).isEmpty();
    }

    @Test
    void valorNulo_seTomaComoCadenaVaciaONull() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        Map<Integer, String> r = parser.parse("{\"userField1\":null}");

        // Then
        assertThat(r).containsKey(1);
    }

    @Test
    void elMapaVieneOrdenadoPorIndice() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        Map<Integer, String> r = parser.parse("{\"userField10\":\"j\",\"userField2\":\"b\",\"userField1\":\"a\"}");

        // Then
        assertThat(r.keySet()).containsExactly(1, 2, 10);
    }
}
