package com.banamex.cops.update_offer.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Arma las claves a partir de los valores SIN modificar (como llegan en el request).
 * Según el ejemplo del evento:
 *   offerKey  = off:mx:CAMPAÑA:OLA:CLIENTE:CUENTA:TARJETA   (OFFPAL.EXTID$, el mismo texto que sale en ResponseText)
 *   refId     = CAMPAÑA_OLA_CLIENTE_CUENTA_TARJETA          (RefID del evento: sin prefijo y con guion bajo)
 *   waveKey   = wvch:OLA:CANAL                              (WAVCH.EXTID$; formato por confirmar con los datos)
 * La cuenta y la tarjeta se omiten si vienen vacías.
 */
@Component
@RequiredArgsConstructor
public class OfferKeyBuilder {

    private final OfferKafkaProps props;

    public String offerKey(String campaignId, String waveId, String customerNo, String accountNo, String cardNumber) {
        return props.getOfferPrefix() + join(props.getKeySeparator(), campaignId, waveId, customerNo, accountNo, cardNumber);
    }

    public String refId(String campaignId, String waveId, String customerNo, String accountNo, String cardNumber) {
        return join("_", campaignId, waveId, customerNo, accountNo, cardNumber);
    }

    public String waveKey(String waveId, String channel) {
        return props.getWavePrefix() + waveId + props.getKeySeparator() + channel;
    }

    /** Campaña, ola y cliente siempre van; cuenta y tarjeta solo si traen valor. */
    private static String join(String sep, String campaignId, String waveId, String customerNo,
                               String accountNo, String cardNumber) {
        StringBuilder sb = new StringBuilder();
        sb.append(campaignId).append(sep).append(waveId).append(sep).append(customerNo);
        if (!isBlank(accountNo)) sb.append(sep).append(accountNo);
        if (!isBlank(cardNumber)) sb.append(sep).append(cardNumber);
        return sb.toString();
    }

    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
