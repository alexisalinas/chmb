package com.banamex.cops.update_offer.sender;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class EmsQueueNameBuilderTest {

    private EmsQueueProperties props;
    private EmsQueueNameBuilder builder;

    @BeforeEach
    void setUp() {
        props = new EmsQueueProperties();
        builder = new EmsQueueNameBuilder(props);
    }

    @Test
    void conLosValoresDeLasGlobales_armaLaColaDelEms() {
        assertThat(builder.build()).isEqualTo("citi.gsg.la.cop_163621.MX_card.offer.update");
    }

    @Test
    void elPaisSeTomaDeLaConfiguracion() {
        props.setCountryCode("CO");
        assertThat(builder.build()).isEqualTo("citi.gsg.la.cop_163621.CO_card.offer.update");
    }

    @Test
    void sePuedePasarElPaisDirectamente_paraCuandoSeConfirmeElDestCountryCode() {
        assertThat(builder.build("PE")).isEqualTo("citi.gsg.la.cop_163621.PE_card.offer.update");
    }

    @Test
    void cadaPiezaDelConcatSaleDeSuVariableGlobal() {
        props.setSector("S");
        props.setBusiness("B");
        props.setRegion("R");
        props.setApplicationName("A");
        props.setApplicationCsiId("1");
        props.setCountryCode("C");
        props.setBankCardEnv("E");
        props.setOperation("O");
        assertThat(builder.build()).isEqualTo("S.B.R.A_1.C_E.O");
    }
}
