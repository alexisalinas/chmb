package com.banamex.cops.update_offer.sender;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * destinationQueue del JMS Queue Requestor:
 *   concat(sector, '.', Business, '.', Región, '.', ApplicationName, '_', Application_CSI_ID, '.',
 *          DestCountryCode, '_', BankCardEnv, '.', UpdateOffer)
 * Con los valores de las globales: citi.gsg.la.cop_163621.MX_card.offer.update
 */
@Component
@RequiredArgsConstructor
public class EmsQueueNameBuilder {

    private final EmsQueueProperties p;

    /** Usa el país configurado en update-offer.ems.queue-parts.country-code (MX). */
    public String build() {
        return build(p.getCountryCode());
    }

    /** Para cuando se confirme de dónde sale el DestCountryCode. */
    public String build(String countryCode) {
        return p.getSector() + "." + p.getBusiness() + "." + p.getRegion() + "."
                + p.getApplicationName() + "_" + p.getApplicationCsiId() + "."
                + countryCode + "_" + p.getBankCardEnv() + "." + p.getOperation();
    }
}
