package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.dto.log.header.RqHeaderDTO;
import com.banamex.cops.update_offer.testutil.TestData;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class KafkaSenderDashboardTest {

    private final KafkaSenderDashboard dashboard = new KafkaSenderDashboard(new OfferKeyBuilder(new OfferKafkaProps()));

    private UpdateOfferResponse respuesta() {
        UpdateOfferResponse r = new UpdateOfferResponse();
        r.setCode("COP_UPDOF_0");
        r.setDescription("Successfully update offer");
        return r;
    }

    @Test
    void armaElEventoDeEntradaConLosDatosDelRequestElHeaderYLaRespuesta() {
        OfferInput in = dashboard.build(TestData.request(), TestData.rqHeader(), respuesta());

        assertThat(in.getUuid()).isEqualTo("uuid-1");
        assertThat(in.getEsbUuid()).isEqualTo("uuid-120261026105455");
        assertThat(in.getChannel()).isEqualTo("CAT");
        assertThat(in.getCampaignId()).isEqualTo("CAMP001");
        assertThat(in.getWaveId()).isEqualTo("WAVE01");
        assertThat(in.getCustomerNo()).isEqualTo("12345678");                  // sin ceros
        assertThat(in.getAccountNo()).isEqualTo("00112233445566");
        assertThat(in.getCardNumber()).isEqualTo("1234567812345678");
        assertThat(in.getOfferStatus()).isEqualTo("01");
        assertThat(in.getResponseCode()).isEqualTo("COP_UPDOF_0");
        assertThat(in.getResponseText()).isEqualTo("Successfully update offer");
    }

    @Test
    void refIdYOfferKeyUsanCampanaOlaClienteCuentaYTarjeta() {
        OfferInput in = dashboard.build(TestData.request(), TestData.rqHeader(), respuesta());
        assertThat(in.getRefId()).isEqualTo("CAMP001_WAVE01_12345678_00112233445566_1234567812345678");
        assertThat(in.getOfferKey()).isEqualTo("off:mx:CAMP001:WAVE01:12345678:00112233445566:1234567812345678");
    }

    @Test
    void actionIdEsElOfferActionDelRequest() {
        OfferInput in = dashboard.build(TestData.request(), TestData.rqHeader(), respuesta());
        assertThat(in.getActionId()).isEqualTo("UPD");

        var rq = TestData.request();
        rq.setOfferActionCode(null);
        assertThat(dashboard.build(rq, TestData.rqHeader(), respuesta()).getActionId()).isNull();
    }

    @Test
    void transactionTimeEsLaHoraDelRqHeaderConMilisegundosYSinOffset() {
        OfferInput in = dashboard.build(TestData.request(), TestData.rqHeader(), respuesta());
        assertThat(in.getTransactionTime()).isEqualTo("2026-10-26T10:54:55.852");
    }

    @Test
    void sinFechaEnElHeader_transactionTimeUsaLaHoraActual() {
        RqHeaderDTO h = TestData.rqHeader();
        h.setDateTimeStamp(null);
        assertThat(dashboard.build(TestData.request(), h, respuesta()).getTransactionTime())
                .matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}");
    }

    @Test
    void responseTimeLlevaMilisegundosYOffset() {
        OfferInput in = dashboard.build(TestData.request(), TestData.rqHeader(), respuesta());
        assertThat(in.getResponseTime()).matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}([+-]\\d{2}:\\d{2}|Z)");
    }

    @Test
    void sinRespuesta_elCodigoYElTextoQuedanNulos() {
        OfferInput in = dashboard.build(TestData.request(), TestData.rqHeader(), null);
        assertThat(in.getResponseCode()).isNull();
        assertThat(in.getResponseText()).isNull();
    }
}
