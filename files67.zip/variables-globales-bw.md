# Variables globales de BW que usa el código (con los valores reales)

Valores tomados de tu archivo `VARIABLES GLOBALES.txt`. Ya están en `update-offer.yml`.

## 1. Globales usadas y aplicadas

| # | Variable global de BW | Valor en BW | Propiedad en el yml | Clase Java | Notas |
|---|---|---|---|---|---|
| 1 | `AuditPointsEnabled` | `1001` | `audit.points-enabled: "1001"` | `AuditLogService` | Activa si el **primer carácter es "1"** (igual que `substring(x,1,1)="1"`). Antes era un booleano |
| 2 | `ApplicationName` | `cop` | `audit.application-name` | `AuditLogService` | `ApplicationID = ApplicationName + "_" + Application_CSI_ID` |
| 3 | `Application_CSI_ID` | `163621` | `audit.application-csi-id` | `AuditLogService` | Da `cop_163621` |
| 4 | `ComponentName` | `COPS` | `audit.component-name` | `AuditLogService` | |
| 5 | `RequestTimeout_Category1` | `7` | `update-offer.ems.timeout-seconds: 7` | `EmsSender` | Segundos |
| 6 | `JMSExpiration` | `30` | `update-offer.ems.time-to-live-ms: 0` | `EmsSender` | **No lo apliqué:** en BW el campo va en milisegundos, y 30 ms haría expirar el mensaje antes de llegar. Ver pendiente 1 |
| 7 | `PadCharacter` | `0` | `update-offer.jms-requestor.customer-padding-char: "0"` | `OfferEventMapper` | |
| 8 | `TranslateTimeZone` | `false` | `update-offer.timezone.translate-time-zone: false` | `UpdateOfferServiceImpl`, `OfferEventMapper` | |
| 9 | `ECRMTimeZone` | `US/Central` | `update-offer.timezone.ecrm-time-zone: US/Central` | `TimeZoneMapRequest`, `OfferEventMapper` | Antes tenía `America/Mexico_City`. Ver pendiente 2 |
| 10 | `TimeZoneDateTimeFormat` | `yyyy-MM-dd'T'HH:mm:ssZ` | `update-offer.timezone.time-zone-date-time-format` | `TimeZoneMapRequest` | |
| 11 | `BETimeFormat` | `HH:mm:ss` | `update-offer.timezone.be-time-format` | `TimeZoneMapRequest` | |
| 12 | `BEDateTimeFormat` | `yyyy-MM-dd HH:mm:ss` | `update-offer.timezone.be-date-time-format` | `TimeZoneMapRequest` | Antes tenía un formato con `T` y offset |
| 13 | `CheckForSuppression` | `N` | `cop.suppression.check-for-suppression: "N"` | `PerformSuppressionCheckService` | Con `N` no se consulta la supresión |
| 14 | `EHKafkaUpdate_Delay` | `200` | `offer.kafka.delay-ms: 200` | `FulFillkafkaSender` | Milisegundos |
| 15 | `isKafkaOn_1` | `true` | `offer.kafka.enabled: true` | `UpdateOfferServiceImpl` | Condición de la transición hacia Kafka. Con `mode: dry-run` solo escribe el JSON en el log |

## 2. Piezas del nombre de la cola (concat del `destinationQueue`)

`destinationQueue = concat(sector,'.',Business,'.',Región,'.',ApplicationName,'_',Application_CSI_ID,'.',DestCountryCode,'_',BankCardEnv,'.',UpdateOffer)`

| Variable global | Valor | Propiedad (`update-offer.ems.queue-parts.*`) |
|---|---|---|
| `sector` | `citi` | `sector` |
| `Business` | `gsg` | `business` |
| `Región` | `la` | `region` |
| `ApplicationName` + `Application_CSI_ID` | `cop` + `163621` | `application-name`, `application-csi-id` |
| `DestCountryCode` | **origen sin confirmar** | `country-code: MX` (el país de la cola, por ahora) |
| `BankCardEnv` | `card` | `bank-card-env` |
| `UpdateOffer` | `offer.update` | `operation` |

Resultado: `citi.gsg.la.cop_163621.MX_card.offer.update`. La arma `EmsQueueNameBuilder`; la propiedad `update-offer.ems.queue` queda solo como sustitución opcional. La misma cola alimenta la configuración de la librería EMS por medio de placeholders.

`AplicationName` y `Aplication_CSI_ID` (con una sola `p`) aparecen repetidas en tu lista con los mismos valores: no se usan.

## 3. Globales del código que **no** vienen en tu lista

| Variable | Dónde se usa | Valor actual | Qué hacer |
|---|---|---|---|
| `COP/Padding/CustomerPadding` | `CustomerNO` (Choose) | `true` (supuesto) | Pasar su valor |
| `COP/Padding/CustomerNo` (longitud del `pad-front`) | `CustomerNO` | `9` (supuesto: el ejemplo de Kafka trae 9 dígitos) | Pasar su valor |

## 4. No se usan en el código

| Variable | Motivo |
|---|---|
| `BEDateFormat` (`yyyy-MM-dd`) | La fecha del Request solo se reformatea con `DateFormat`; no se necesita |
| `update-offer.logging.*` del yml | Era de `LogRequestService`; se reemplazó por `AuditLogService` |

## 5. Valores fijos del código que no son globales

| Valor | Origen en BW | Propiedad |
|---|---|---|
| `UpdateOffer` | `_nm_` (nombre del evento) | `update-offer.ems.body-element` |
| `1.0` | Literal del mapper: `ServiceVersion` | `audit.service-version` |
| `v3_0_0_0` y `Offer` | `ServiceName` del log de request y de respuesta | `audit.request-service-name`, `audit.response-service-name` (supuestos) |
| `MX` | `CountryCode` del header del log | `audit.country-code` (fijo) |
| `Fulfillrequest`, `1.0`, `163621`, `MX`, `DM` | Constantes del header del evento de Kafka (tomadas del ejemplo) | `offer.kafka.event-name`, `event-version`, `producer-csi`, `country-code`, `business-code` |
