# Qué falta para cerrar el desarrollo (sin dejar suposiciones)

Leyenda: **CONFIRMADO** = lo dijiste tú, viene en tus archivos o se ve en una captura. **SUPUESTO** = el código lo asume. **FALTA** = no hay dato.

---

## A. GetContext y ClientDetails

En BW, `GetContext` entrega el `RqHeader` completo. En el micro se arma en `RqHeaderFactory`.

| Campo del RqHeader | Obligatorio | De dónde sale hoy | Estado | Qué hay que confirmar |
|---|---|---|---|---|
| `UUID` | sí | Header HTTP `uuid` | **CONFIRMADO** | — |
| `ESBUUID` | no (?) | `uuid` + `yyyyMMddHHmmss` (se genera) | **CONFIRMADO** | — |
| `DateAndTimeStamp` | sí | Hora actual del micro | SUPUESTO | Confirmar que sirve la hora actual |
| `Version` | no (?) | yml `3.0` | **FALTA** | El ejemplo dice `3.0` y el log de BW `3.0.MX.1` |
| `ClientDetails/Org`, `OrgUnit` | sí | yml (`Banamex`, `COPS`) | **FALTA** | ¿Fijos, o salen de `businessCode` u otro header? |
| `ClientDetails/ChannelID` | sí | Header HTTP `ChannelId` | SUPUESTO | Confirmar |
| `ClientDetails/TerminalID` | sí | yml (`1`) | **FALTA** | ¿Sale del header `sid` o es fijo? |
| `ClientDetails/UserID` | sí | yml (`ATM`) | **FALTA (importante)** | De aquí sale `UpdatedBy` en el mensaje al EMS. ¿`client_id`, token `Authorization` o fijo? |
| `ClientDetails/SrcCountryCode` y `DestCountryCode` | sí | Header HTTP `countryCode` (ambos) | **FALTA** | Tú indicaste que el origen del `DestCountryCode` no está confirmado |
| `ClientDetails/SessionLanguageCode` | no (?) | `Accept-Language` | SUPUESTO | Confirmar |
| `ClientIPAddress`, `UserDomicile*`, `Processing*`, `UserGroup` | no (?) | No se llenan | **FALTA** | ¿Alguna capa de BW las llenaba? |
| Headers `sid`, `businessCode`, `client_id`, `host`, `Authorization` | — | No se mapean | **FALTA** | A qué campo (si alguno) alimentan |

**Dónde verlo en TIBCO:** `OpUpdateOffer` > `GetContext` > `Output` (el RqHeader que recibe BW); la actividad inicial > `Output`; al final `SetContext` > `Input`; y con el equipo del API Gateway (Apigee), cómo se traducen los headers HTTP al RqHeader. Esa respuesta también resuelve el `DestCountryCode`.

---

## B. Mensaje al EMS y su respuesta

| Tema | Estado | Qué falta |
|---|---|---|
| Estructura `Envelope/Header/Body` sin URLs | **CONFIRMADO** | — |
| Cola `citi.gsg.la.cop_163621.MX_card.offer.update`, armada con el `concat` de las globales | **CONFIRMADO** (ya la usaste a mano: se conecta, manda el XML y responde) | El `MX` sale hoy de la configuración; falta el origen del `DestCountryCode` |
| Va por la rama "XSD Format" | **CONFIRMADO** | — |
| `RequestTimeout_Category1 = 7` | **CONFIRMADO** (segundos) | — |
| `JMSExpiration = 30` | **FALTA la unidad** | En milisegundos el mensaje expiraría a los 30 ms. Hoy el yml deja `0` (sin expiración). Confirmar si BW lo trata como segundos |
| Nombre del elemento del cuerpo (`UpdateOffer`) | SUPUESTO | Como ya manda el XML y el EMS responde, confirmar que ese es el correcto |
| Campos de la **respuesta** del EMS | **FALTA** | Pasar el bloque `[EMS] Respuesta recibida` del log. Ya responde, así que solo falta ver su forma |
| Si el EMS espera varias ofertas en un solo mensaje | **FALTA** | Hoy se manda un mensaje por oferta |
| XPath de `ApptEndTime` | **FALTA** | `JMS Queue Requestor` > `Input` > `ApptEndTime - [Choose]`, abrir `[When]` y `[Otherwise]` |

---

## C. Zona horaria

| Tema | Estado | Qué falta |
|---|---|---|
| Valores de `TranslateTimeZone` (false), `ECRMTimeZone` (US/Central), `TimeZoneDateTimeFormat`, `BETimeFormat`, `BEDateTimeFormat` | **CONFIRMADO** | — |
| **`US/Central` y el horario de verano** | **FALTA aclarar** | US/Central tiene horario de verano de EE.UU. (en octubre es −05:00), pero tu ejemplo de Kafka muestra `−06:00` el 28 de octubre. ¿La hora del evento sale del servidor (hora de México) y no de `ECRMTimeZone`? |
| `System` y `SysMode` (hoy `COPS`, `RT`) | **FALTA** | `OpUpdateOffer` > `RequestTimeZoneValidation` > `Input` |
| Códigos `COP_TZCOD_000` y `COP_TZCOD_101` | **FALTA** | `/BW/Common/TimeZoneValidation` > `End` > `Input` y `ErrorVar` |
| Hora y fecha-hora en Request (convertir de la zona del cliente a ECRM) | SUPUESTO | Viene de la guía, no de una captura. Comparar con una ejecución real antes de activar `translate-time-zone` |
| Contenido de `COP_TIMEZONE_LOOKUP` | **FALTA** | `SELECT * FROM COP_TIMEZONE_LOOKUP` |
| `CustomerPadding` y longitud del `pad-front` (`COP/Padding/CustomerNo`) | **FALTA** | No venían en tu lista de globales |

---

## D. Kafka

Con tu ejemplo de JSON quedaron resueltos: el nombre del evento (`Fulfillrequest`), el orden de los campos, el `sid`, el formato del `RefID`, `Action_ID`, los formatos de fecha y la omisión de campos nulos. Qué falta:

| # | Dato que falta | Dónde se obtiene | Por qué hace falta |
|---|---|---|---|
| 1 | ¿Se envía por el bridge JMS o directo a Kafka? | Equipo de la plataforma | Define `offer.kafka.mode` (hoy `dry-run`) |
| 2 | **Cola, conexión, modo de entrega y expiración del bridge** | `/BW/Kafka/FulFillKafkaSender` > `KafkaMsgSender` > `Configuration` | Hoy `queue` es `CAMBIAR_COLA_DEL_BRIDGE` |
| 3 | Formato del mensaje a la cola (`RefId` / `jsonString`, JSON o XML) | Misma actividad > `Input` | Hoy se asume un JSON con esos dos campos |
| 4 | **Formato de las claves de la BD** | Bloque 2 de `kafka-sql-prueba.sql` | La clave de la oferta sale de tu ejemplo (`off:mx:CAMPAÑA:OLA:CLIENTE:CUENTA:TARJETA`); la de la ola (`wvch:OLA:CANAL`) es de la guía y no tiene evidencia |
| 5 | **De qué columna sale `OfferStartDate`** | Mapper de `FulFillKafkaSender` | Hoy usa `OFFERCREATIONDATE_TM` (por la fecha del ejemplo) |
| 6 | Si el evento debe llevar `ReasonCode`, `ReasonDesc`, `ProductType`, `ProductFamily`, `CategoryID`, `AppointmentStartDate` y `AppointmentMinDur` | Contrato del consumidor | La consulta los trae, pero el ejemplo no los incluye; hoy **no se envían** |
| 7 | Nombres y tipos reales de tablas y columnas | Bloques 1 y 4 de `kafka-sql-prueba.sql` | La consulta no se ha probado contra Oracle |
| 8 | **¿`CitiDataStore` es la misma BD `RMXCOP4`?** | Recurso JDBC `CitiDataStore` en el proyecto de BW | La consulta usa el `spring.datasource` de `cops-bd` |
| 9 | **Qué son `AB-KafkaSender...` y `AbInitioResponse`** | `OpUpdateOffer`: el diagrama muestra **dos** llamadas a Kafka y una actividad `AbInitioResponse` | Puede haber un segundo envío con otro destino |
| 10 | Si `CustomerNo` ya llega con 9 dígitos | Un request real | En la clave y en el `RefID` va tal como llega; el body lo rellena a 9 |
| 11 | Si el `sid` es siempre el `UUID` | Mapper de `KafkaSenderDashboard` | En tu ejemplo son iguales; la guía decía `ESBUUID` |
| 12 | Si `CardNumber` va completa | Seguridad / consumidor | El ejemplo la trae completa; hoy va completa (`mask-card-number: false`) |
| 13 | Contrato del consumidor (esquema del evento `Fulfillrequest` 1.0) | Equipo consumidor | `OfferStatus` es obligatorio para Kafka y opcional en tu API: esas ofertas se descartan |
| 14 | Si falla: reintentos, alerta, cola de errores | Operación | Hoy: 3 intentos y un `KAFKA-ERROR` en el log |
| 15 | Volumetría (transacciones por segundo) | Negocio | Para dimensionar el ejecutor |
| 16 | Si es Kafka directo: tópico `lac.*`, brokers, seguridad, FID/keytab, tarjeta Jira MIATR, DR | Plataforma Kafka | Solo para `mode: kafka` |

**Ojo:** con `isKafkaOn_1 = true` el flujo de Kafka ya está activo en el yml. Mientras la librería `cops-bd` nueva no esté instalada, cada petición escribirá `KAFKA-ERROR` en el log (no afecta la respuesta). Si molesta, pon `offer.kafka.enabled: false` mientras tanto.

---

## E. Decisiones abiertas

1. **Un mensaje por oferta o uno por lote** (sección B).
2. **`*` como lista:** hoy una lista vacía es válida; si "de uno a muchos" significa mínimo uno, hay que agregar `@NotEmpty`.
3. **Header `sid`:** ¿se registra en algún campo del log o del RqHeader?
4. **`CountryCode` del log de auditoría:** hoy fijo en `MX`; en BW es el `DestCountryCode`.
5. **Lo que ibas a preguntar:** el origen de `Org`, `OrgUnit`, `TerminalID` y `UserID` (sección A), y quién carga la lista de entidades suprimidas y cuál de las dos clases cliente se conserva.

---

## F. Suposiciones activas en el código

| Archivo | Suposición | Se confirma con |
|---|---|---|
| `RqHeaderFactory` | Tabla A | Sección A |
| `EmsQueueNameBuilder` | `DestCountryCode` = `MX` | Sección A (Apigee) |
| `UpdateOfferRequestXmlMapper.toEmsXml` | El cuerpo es un elemento `UpdateOffer` con los campos del evento | Sección B |
| `UpdateOfferResponseXmlMapper` | La respuesta trae `Code`, `Description`, ... | Respuesta real |
| `OfferEventMapper` | `ApptEndTime` igual que `ApptStartTime`; relleno de `CustomerNO` a 9 | XPath de `ApptEndTime`; sección C |
| `TimeZoneMapRequest` | Request: hora y fecha-hora convertidas de la zona del cliente a ECRM | Sección C |
| `TimeZoneValidationService` | Códigos `000` y `101`; `System` y `SysMode` | Sección C |
| `FulFillkafkaSender` | `OfferStartDate` ← `OFFERCREATIONDATE_TM`; campos que no se envían; clave de la ola | Sección D, puntos 4 a 6 |
| `JmsOfferPublisher` | Cuerpo `{RefId, jsonString}`; `JMSCorrelationID` = RefID | Sección D, puntos 2 y 3 |
| `AuditLogService` | `ServiceName` del request y de la respuesta; `CountryCode` fijo | Sección E |
