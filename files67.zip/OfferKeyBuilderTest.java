package com.banamex.cops.update_offer.kafka;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class OfferKeyBuilderTest {

    private OfferKafkaProps props;
    private OfferKeyBuilder keys;

    @BeforeEach
    void setUp() {
        props = new OfferKafkaProps();
        keys = new OfferKeyBuilder(props);
    }

    @Test
    void offerKey_igualAlDelEjemploDeResponseText() {
        assertThat(keys.offerKey("DIS_SPEI I 26 INC", "H2075HQMQM", "067799015", "0005499490574629473", "0005499490574629473"))
                .isEqualTo("off:mx:DIS_SPEI I 26 INC:H2075HQMQM:067799015:0005499490574629473:0005499490574629473");
    }

    @Test
    void refId_igualAlDelEjemplo_sinPrefijoYConGuionBajo() {
        assertThat(keys.refId("DIS_SPEI I 26 INC", "H2075HQMQM", "067799015", "0005499490574629473", "0005499490574629473"))
                .isEqualTo("DIS_SPEI I 26 INC_H2075HQMQM_067799015_0005499490574629473_0005499490574629473");
    }

    @Test
    void cuentaYTarjetaSeOmitenSiVienenVacias() {
        assertThat(keys.offerKey("C1", "W1", "123", null, null)).isEqualTo("off:mx:C1:W1:123");
        assertThat(keys.offerKey("C1", "W1", "123", "", " ")).isEqualTo("off:mx:C1:W1:123");
        assertThat(keys.offerKey("C1", "W1", "123", "ACC", null)).isEqualTo("off:mx:C1:W1:123:ACC");
        assertThat(keys.refId("C1", "W1", "123", null, null)).isEqualTo("C1_W1_123");
        assertThat(keys.refId("C1", "W1", "123", "ACC", null)).isEqualTo("C1_W1_123_ACC");
    }

    @Test
    void waveKey_usaPrefijoDeOlaYCanal() {
        assertThat(keys.waveKey("W1", "CAT")).isEqualTo("wvch:W1:CAT");
    }

    @Test
    void prefijosYSeparadorSonConfigurables_peroElRefIdSiempreUsaGuionBajo() {
        props.setOfferPrefix("o:");
        props.setWavePrefix("w:");
        props.setKeySeparator("|");
        assertThat(keys.offerKey("C1", "W1", "123", "ACC", "CARD")).isEqualTo("o:C1|W1|123|ACC|CARD");
        assertThat(keys.waveKey("W1", "CAT")).isEqualTo("w:W1|CAT");
        assertThat(keys.refId("C1", "W1", "123", "ACC", "CARD")).isEqualTo("C1_W1_123_ACC_CARD");
    }

    @Test
    void elCustomerNoSeUsaTalCualSinRellenarCeros() {
        assertThat(keys.offerKey("C1", "W1", "7", null, null)).isEqualTo("off:mx:C1:W1:7");
        assertThat(keys.refId("C1", "W1", "7", null, null)).isEqualTo("C1_W1_7");
    }
}
