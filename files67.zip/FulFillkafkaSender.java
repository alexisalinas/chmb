package com.banamex.cops.update_offer.sender;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.update_offer.kafka.KafkaMetrics;
import com.banamex.cops.update_offer.kafka.OfferDataClient;
import com.banamex.cops.update_offer.kafka.OfferInput;
import com.banamex.cops.update_offer.kafka.OfferKafkaProps;
import com.banamex.cops.update_offer.kafka.OfferKeyBuilder;
import com.banamex.cops.update_offer.kafka.OfferPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.stereotype.Service;
import tools.jackson.databind.json.JsonMapper;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;

/**
 * Subproceso /BW/Kafka/FulFillKafkaSender. Se dispara DESPUÉS de responder y nunca afecta la respuesta:
 *  0) evento de entrada (KafkaSenderDashboard)   1) espera de delayMs   2) consulta a la BD (librería cops-bd)
 *  3) ensamblado del evento                      4) reglas de formato   5) publicación { RefId, jsonString }
 *
 * La consulta solo trae columnas; todas las reglas están aquí. El formato del JSON sigue el ejemplo del evento
 * "Fulfillrequest": campos y orden del header y del body, sin los campos nulos.
 *
 * Códigos del log: KAFKA-SENT, KAFKA-NO-ROWS, KAFKA-INVALID, KAFKA-RETRY, KAFKA-ERROR, KAFKA-REJECTED.
 */
@Slf4j
@Service
public class FulFillkafkaSender {

    private static final DateTimeFormatter WITH_OFFSET_MILLIS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
    private static final DateTimeFormatter LOCAL_MILLIS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    private static final DateTimeFormatter WITH_OFFSET_SECONDS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX");

    private final OfferKafkaProps props;
    private final OfferKeyBuilder keys;
    private final OfferDataClient dataClient;
    private final OfferPublisher publisher;
    private final JsonMapper mapper;
    private final KafkaMetrics metrics;
    private final TaskExecutor executor;

    public FulFillkafkaSender(OfferKafkaProps props, OfferKeyBuilder keys, OfferDataClient dataClient,
                              OfferPublisher publisher, JsonMapper mapper, KafkaMetrics metrics,
                              @Qualifier("fulFillKafkaExecutor") TaskExecutor executor) {
        this.props = props;
        this.keys = keys;
        this.dataClient = dataClient;
        this.publisher = publisher;
        this.mapper = mapper;
        this.metrics = metrics;
        this.executor = executor;
    }

    public boolean isEnabled() {
        return props.isEnabled();
    }

    /** Encola el envío. Si la cola está llena, lo descarta y lo cuenta (no bloquea la respuesta). */
    public void sendAsync(OfferInput in) {
        try {
            executor.execute(() -> process(in));
        } catch (TaskRejectedException e) {
            metrics.incRejected();
            log.warn("KAFKA-REJECTED cola llena, no se envió uuid={} refId={}", in.getUuid(), in.getRefId());
        }
    }

    /** Pasos 1 a 5 (síncrono; lo ejecuta el hilo del ejecutor). Nunca lanza excepciones. */
    public void process(OfferInput in) {
        try {
            if (!valid(in)) {
                return;
            }
            if (props.getDelayMs() > 0) {
                Thread.sleep(props.getDelayMs());                       // paso 1
            }
            String waveKey = keys.waveKey(in.getWaveId(), in.getChannel());
            Optional<CopOfferFulfillment> db =
                    retry("consulta a la BD", () -> dataClient.find(waveKey, in.getOfferKey())); // paso 2
            if (db.isEmpty()) {
                metrics.incNoRows();
                log.error("KAFKA-NO-ROWS uuid={} refId={} waveKey={} offerKey={}",
                        in.getUuid(), in.getRefId(), waveKey, in.getOfferKey());
                return;
            }
            String json = mapper.writeValueAsString(assemble(in, db.get()));   // pasos 3 y 4
            String id = retry("publicación", () -> publisher.publish(in.getRefId(), json));  // paso 5
            metrics.incSent();
            log.info("KAFKA-SENT uuid={} refId={} messageId={}", in.getUuid(), in.getRefId(), id);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("KAFKA-ERROR interrumpido uuid={} refId={}", in.getUuid(), in.getRefId());
        } catch (Exception e) {
            metrics.incFailed();
            log.error("KAFKA-ERROR uuid={} refId={} {}", in.getUuid(), in.getRefId(), e.toString(), e);
        }
    }

    // ------------------------------------------------------------------ pasos 3 y 4

    /** Ensambla { "event": { "header": …, "body": … } } con los campos y el orden del ejemplo. */
    Map<String, Object> assemble(OfferInput in, CopOfferFulfillment db) {
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("name", props.getEventName());
        header.put("version", props.getEventVersion());
        header.put("producerCSI", props.getProducerCsi());
        header.put("Channel", in.getChannel());
        header.put("countryCode", props.getCountryCode());
        header.put("businessCode", props.getBusinessCode());
        header.put("UUID", in.getUuid());
        header.put("sid", in.getUuid());                                  // en el ejemplo sid = UUID
        header.put("transactionTime", isBlank(in.getTransactionTime())
                ? LocalDateTime.now().format(LOCAL_MILLIS) : in.getTransactionTime());
        header.put("timeStamp", OffsetDateTime.now().format(WITH_OFFSET_MILLIS));   // siempre la hora actual

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("RefID", in.getRefId());
        body.put("CampaignID", in.getCampaignId());
        body.put("WaveID", in.getWaveId());
        body.put("CustomerNo", padLeft(in.getCustomerNo(), 9));          // DESPUÉS de la consulta
        body.put("AccountNo", in.getAccountNo());
        body.put("CardNumber", props.isMaskCardNumber() ? mask(in.getCardNumber()) : in.getCardNumber());
        body.put("OfferStatus", in.getOfferStatus());
        body.put("Product_Description", db.prdDescription());
        body.put("Action_ID", in.getActionId());
        body.put("ResponseTime", in.getResponseTime());
        body.put("ResponseCode", in.getResponseCode());
        body.put("ResponseText", in.getResponseText());
        body.put("FulfillmentID", db.fulfillmentProcId());
        List<String> userFields = db.userFields();                        // índice 0 = USERFIELD_1
        for (int i = 1; i <= 100; i++) {
            body.put("UserField" + i, userFields != null && i <= userFields.size() ? userFields.get(i - 1) : null);
        }
        body.put("OfferExpiryDate", iso(db.expiryDate()));
        body.put("OfferStartDate", iso(db.offerCreationDate()));          // por confirmar: OFFERCREATIONDATE_TM
        body.put("PrdCode", db.prdCode());
        body.put("Availability", db.availability());

        if (props.isOmitNulls()) {
            header.values().removeIf(Objects::isNull);
            body.values().removeIf(Objects::isNull);
        }

        Map<String, Object> event = new LinkedHashMap<>();
        event.put("header", header);
        event.put("body", body);
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("event", event);
        return root;
    }

    // ------------------------------------------------------------------ validación, reintentos y utilidades

    private boolean valid(OfferInput in) {
        if (isBlank(in.getRefId()) || isBlank(in.getOfferKey()) || isBlank(in.getCampaignId())
                || isBlank(in.getWaveId()) || isBlank(in.getCustomerNo()) || isBlank(in.getOfferStatus())) {
            metrics.incInvalid();
            log.error("KAFKA-INVALID uuid={} refId={} faltan campos obligatorios (RefID, CampaignID, WaveID, CustomerNo, OfferStatus)",
                    in.getUuid(), in.getRefId());
            return false;
        }
        return true;
    }

    /** Reintenta solo fallas de infraestructura (excepciones); un "sin filas" no es excepción y no se reintenta. */
    private <T> T retry(String what, Callable<T> action) throws Exception {
        long backoff = props.getRetryBackoffMs();
        for (int attempt = 1; ; attempt++) {
            try {
                return action.call();
            } catch (Exception e) {
                if (attempt >= props.getMaxAttempts()) {
                    throw e;
                }
                log.warn("KAFKA-RETRY {} intento {}/{}: {}", what, attempt, props.getMaxAttempts(), e.toString());
                if (backoff > 0) {
                    Thread.sleep(backoff);
                }
                backoff *= 2;
            }
        }
    }

    static String padLeft(String s, int len) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = s.length(); i < len; i++) sb.append('0');
        return sb.append(s).toString();
    }

    static String mask(String s) {
        if (s == null || s.length() <= 4) return s;
        return "*".repeat(s.length() - 4) + s.substring(s.length() - 4);
    }

    /** Fechas de la BD como xs:dateTime con offset y sin fracciones, como en el ejemplo (2026-12-31T00:00:00-06:00). */
    static String iso(Object v) {
        if (v == null) return null;
        if (v instanceof Timestamp t) {
            return t.toLocalDateTime().atZone(ZoneId.systemDefault()).format(WITH_OFFSET_SECONDS);
        }
        return v.toString();
    }

    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
