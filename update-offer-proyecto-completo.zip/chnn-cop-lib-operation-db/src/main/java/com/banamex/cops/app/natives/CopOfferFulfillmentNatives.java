package com.banamex.cops.app.natives;

/**
 * Queries nativos de los datos de cumplimiento (fulfillment) de una oferta.
 * Parámetros posicionales (?) para poder fijar timeout y máximo de filas por sentencia:
 *   1) D_WAVECHINFO.EXTID$ (clave de la ola con canal)   2) D_OFFERPALETTE.EXTID$ (clave de la oferta).
 * Solo selecciona columnas: cualquier cálculo o transformación se hace en el microservicio.
 * SQL de Oracle: validar contra el motor real.
 */
public final class CopOfferFulfillmentNatives {

    private CopOfferFulfillmentNatives() {
    }

    public static final String FIND_BY_WAVE_KEY_AND_OFFER_KEY = buildSql();

    private static String buildSql() {
        StringBuilder cols = new StringBuilder(
                "D_WAVECHINFO.CRPCATEGORYID, D_CAMPAIGN.PRDTYPE, D_OFFERPALETTE.REASONCODE, D_OFFERPALETTE.REASONDESC, "
              + "D_PRODUCT.DESCRIPTION, D_CAMPAIGN.FULFILLMENTPROCID");
        for (int i = 1; i <= 100; i++) {
            cols.append(", D_OFFERPALETTE.USERFIELD_").append(i);
        }
        cols.append(", D_OFFERPALETTE.APPTSTARTDATE_TM, D_OFFERPALETTE.APPTENDDATE_TM")
            .append(", D_OFFERPALETTE.EXPIRYDATE_TM, D_OFFERPALETTE.OFFERCREATIONDATE_TM")
            .append(", D_PRODUCT.PRDCODE, D_PRODUCT.PRDFAMILY, D_OFFERPALETTE.AVAILABILITY");
        return "SELECT " + cols
             + " FROM D_OFFERPALETTE, D_CAMPAIGN, D_PRODUCT, D_WAVECHINFO"
             + " WHERE D_OFFERPALETTE.CAMPAIGNID = D_CAMPAIGN.CMPID AND D_CAMPAIGN.PRDCODE = D_PRODUCT.PRDCODE"
             + " AND D_WAVECHINFO.EXTID$ = ? AND D_OFFERPALETTE.EXTID$ = ?";
    }
}
