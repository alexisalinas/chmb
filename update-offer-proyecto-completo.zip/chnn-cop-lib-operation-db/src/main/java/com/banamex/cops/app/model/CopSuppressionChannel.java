package com.banamex.cops.app.model;

/**
 * Una fila de {@code COP_SUPP_CHNL}: la supresión de un canal (consulta {@code FetchChannels} del proceso de BW
 * {@code /BW/StartUp/startUpSuppression}). Los valores salen tal como vienen de la base.
 *
 * @param countryCode     {@code COUNTRY_CODE} (puede ser nulo)
 * @param reqMode         {@code REQMODE}
 * @param channelId       {@code CHANNEL_ID}
 * @param suppressionFlag {@code SUPPRESSION_FLAG} ("Y" o "N")
 * @param operationFlag   {@code OPERATION_FLAG} ("Y" o "N")
 * @param sourceSystem    {@code SOURCE_SYSTEM}
 */
public record CopSuppressionChannel(String countryCode,
                                    String reqMode,
                                    String channelId,
                                    String suppressionFlag,
                                    String operationFlag,
                                    String sourceSystem) {
}
