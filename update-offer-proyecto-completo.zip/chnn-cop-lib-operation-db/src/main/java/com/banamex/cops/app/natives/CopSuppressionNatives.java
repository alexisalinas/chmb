package com.banamex.cops.app.natives;

/**
 * Queries nativos de la lista de entidades suprimidas. Son los dos {@code JDBC Query} del proceso de BW
 * {@code /BW/StartUp/startUpSuppression} (conexión {@code CitiDataStore}): {@code FetchChannels} y
 * {@code FetchOperations}. Solo leen: armar la lista con ellos se hace en el microservicio.
 * SQL de Oracle: validar contra el motor real.
 */
public final class CopSuppressionNatives {

    private CopSuppressionNatives() {
    }

    /** {@code FetchChannels}: todos los canales con su supresión. */
    public static final String FIND_ALL_CHANNELS = "SELECT * FROM COP_SUPP_CHNL";

    /** {@code FetchOperations}: todas las operaciones suprimidas por canal. */
    public static final String FIND_ALL_OPERATIONS = "SELECT * FROM COP_SUPP_OPR";
}
