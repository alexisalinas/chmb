package com.banamex.cops.app.repository;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.natives.CopSuppressionNatives;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;

/**
 * Ejecuta los dos queries nativos de la lista de entidades suprimidas ({@code COP_SUPP_CHNL} y
 * {@code COP_SUPP_OPR}). Usa JDBC (como {@code CopOfferFulfillmentRepository}); el timeout y el máximo de filas
 * de cada sentencia los fija quien llama (en BW: {@code COP/QueryRecords/TimeoutDefault} y
 * {@code COP/Connections/BSDB/MaxConns}). Solo lee columnas y las entrega como vienen.
 */
@Repository
@RequiredArgsConstructor
public class CopSuppressionRepository {

    private static final RowMapper<CopSuppressionChannel> CHANNEL_MAPPER = (rs, rowNum) -> new CopSuppressionChannel(
            rs.getString("COUNTRY_CODE"),
            rs.getString("REQMODE"),
            rs.getString("CHANNEL_ID"),
            rs.getString("SUPPRESSION_FLAG"),
            rs.getString("OPERATION_FLAG"),
            rs.getString("SOURCE_SYSTEM"));

    private static final RowMapper<CopSuppressionOperation> OPERATION_MAPPER = (rs, rowNum) -> new CopSuppressionOperation(
            rs.getString("OPERATION_NAME"),
            rs.getString("OPERATION_SUPPRESS_FLAG"),
            rs.getString("REQCHANNEL"));

    private final NamedParameterJdbcTemplate jdbc;

    /**
     * Consulta todos los canales con su supresión ({@code COP_SUPP_CHNL}).
     *
     * @param timeoutSeconds segundos máximos de la sentencia
     * @param maxRows        filas máximas (0 = sin límite)
     * @return las filas encontradas, o una lista vacía si no hay ninguna
     */
    public List<CopSuppressionChannel> findAllChannels(int timeoutSeconds, int maxRows) {
        return jdbc.getJdbcOperations().query(con -> {
            PreparedStatement ps = con.prepareStatement(CopSuppressionNatives.FIND_ALL_CHANNELS);
            ps.setQueryTimeout(timeoutSeconds);
            ps.setMaxRows(maxRows);
            return ps;
        }, CHANNEL_MAPPER);
    }

    /**
     * Consulta todas las operaciones suprimidas por canal ({@code COP_SUPP_OPR}).
     *
     * @param timeoutSeconds segundos máximos de la sentencia
     * @param maxRows        filas máximas (0 = sin límite)
     * @return las filas encontradas, o una lista vacía si no hay ninguna
     */
    public List<CopSuppressionOperation> findAllOperations(int timeoutSeconds, int maxRows) {
        return jdbc.getJdbcOperations().query(con -> {
            PreparedStatement ps = con.prepareStatement(CopSuppressionNatives.FIND_ALL_OPERATIONS);
            ps.setQueryTimeout(timeoutSeconds);
            ps.setMaxRows(maxRows);
            return ps;
        }, OPERATION_MAPPER);
    }
}
