package com.banamex.cops.app.service;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;

import java.util.List;

/**
 * Servicio de consulta de los datos de supresión (canales y operaciones suprimidas).
 * Solo expone las consultas: armar la lista de entidades suprimidas se hace en el microservicio que lo usa.
 */
public interface CopSuppressionService {

    /**
     * Todos los canales con su supresión (consulta {@code FetchChannels}, solo lectura).
     *
     * @param timeoutSeconds segundos máximos de la sentencia
     * @param maxRows        filas máximas (0 = sin límite)
     * @return las filas de {@code COP_SUPP_CHNL}
     */
    List<CopSuppressionChannel> findAllChannels(int timeoutSeconds, int maxRows);

    /**
     * Todas las operaciones suprimidas por canal (consulta {@code FetchOperations}, solo lectura).
     *
     * @param timeoutSeconds segundos máximos de la sentencia
     * @param maxRows        filas máximas (0 = sin límite)
     * @return las filas de {@code COP_SUPP_OPR}
     */
    List<CopSuppressionOperation> findAllOperations(int timeoutSeconds, int maxRows);
}
