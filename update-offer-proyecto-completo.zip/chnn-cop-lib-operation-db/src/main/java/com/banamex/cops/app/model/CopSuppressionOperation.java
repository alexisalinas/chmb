package com.banamex.cops.app.model;

/**
 * Una fila de {@code COP_SUPP_OPR}: la supresión de una operación por canal (consulta {@code FetchOperations} del
 * proceso de BW {@code /BW/StartUp/startUpSuppression}). Los valores salen tal como vienen de la base.
 *
 * @param operationName         {@code OPERATION_NAME}
 * @param operationSuppressFlag {@code OPERATION_SUPPRESS_FLAG} ("Y" o "N")
 * @param reqChannel            {@code REQCHANNEL}
 */
public record CopSuppressionOperation(String operationName,
                                      String operationSuppressFlag,
                                      String reqChannel) {
}
