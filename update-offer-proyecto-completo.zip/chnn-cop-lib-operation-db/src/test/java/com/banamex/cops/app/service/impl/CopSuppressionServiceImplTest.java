package com.banamex.cops.app.service.impl;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.repository.CopSuppressionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias de {@code CopSuppressionServiceImpl}.
 * <p>
 * Casos cubiertos: cada consulta se delega en el repositorio con sus parámetros y devuelve lo que este responde.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
@ExtendWith(MockitoExtension.class)
class CopSuppressionServiceImplTest {

    @Mock CopSuppressionRepository repository;
    @InjectMocks CopSuppressionServiceImpl service;

    @Test
    void canales_delegaEnElRepositorioConSusParametros() {
        // Given
        List<CopSuppressionChannel> filas = List.of(new CopSuppressionChannel("MX", "RT", "CAT", "Y", "N", "ECRM"));
        when(repository.findAllChannels(30, 0)).thenReturn(filas);

        // When
        List<CopSuppressionChannel> out = service.findAllChannels(30, 0);

        // Then
        assertThat(out).isSameAs(filas);
        verify(repository).findAllChannels(30, 0);
    }

    @Test
    void operaciones_delegaEnElRepositorioConSusParametros() {
        // Given
        List<CopSuppressionOperation> filas = List.of(new CopSuppressionOperation("UpdateOffer", "Y", "CAT"));
        when(repository.findAllOperations(15, 100)).thenReturn(filas);

        // When
        List<CopSuppressionOperation> out = service.findAllOperations(15, 100);

        // Then
        assertThat(out).isSameAs(filas);
        verify(repository).findAllOperations(15, 100);
    }
}
