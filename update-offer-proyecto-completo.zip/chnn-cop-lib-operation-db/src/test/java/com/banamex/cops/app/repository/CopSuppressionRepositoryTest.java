package com.banamex.cops.app.repository;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.natives.CopSuppressionNatives;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias de {@code CopSuppressionRepository}.
 * <p>
 * Casos cubiertos: filas devueltas; lista vacía; sentencia con el timeout y el máximo de filas que se piden;
 * lectura de cada columna de {@code COP_SUPP_CHNL} y de {@code COP_SUPP_OPR}.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CopSuppressionRepositoryTest {

    @Mock NamedParameterJdbcTemplate jdbc;
    @Mock JdbcOperations ops;

    private CopSuppressionRepository repository;

    @BeforeEach
    void setUp() {
        repository = new CopSuppressionRepository(jdbc);
        when(jdbc.getJdbcOperations()).thenReturn(ops);
    }

    // ------------------------------------------------------------ canales

    @Test
    void canales_devuelveLasFilasDelJdbc() {
        // Given
        CopSuppressionChannel fila = new CopSuppressionChannel("MX", "RT", "CAT", "Y", "N", "ECRM");
        when(ops.query(any(PreparedStatementCreator.class), ArgumentMatchers.<RowMapper<CopSuppressionChannel>>any()))
                .thenReturn(List.of(fila));

        // When / Then
        assertThat(repository.findAllChannels(30, 0)).containsExactly(fila);
    }

    @Test
    void canales_sinFilas_devuelveListaVacia() {
        // Given
        when(ops.query(any(PreparedStatementCreator.class), ArgumentMatchers.<RowMapper<CopSuppressionChannel>>any()))
                .thenReturn(List.of());

        // When / Then
        assertThat(repository.findAllChannels(30, 0)).isEmpty();
    }

    @Test
    void canales_creaLaSentenciaConElTimeoutYElMaximoDeFilasPedidos() throws Exception {
        // Given
        Connection con = mock(Connection.class);
        PreparedStatement ps = mock(PreparedStatement.class);
        when(con.prepareStatement(CopSuppressionNatives.FIND_ALL_CHANNELS)).thenReturn(ps);
        ArgumentCaptor<PreparedStatementCreator> creator = ArgumentCaptor.forClass(PreparedStatementCreator.class);
        when(ops.query(creator.capture(), ArgumentMatchers.<RowMapper<CopSuppressionChannel>>any())).thenReturn(List.of());

        // When
        repository.findAllChannels(25, 500);
        creator.getValue().createPreparedStatement(con);

        // Then
        verify(ps).setQueryTimeout(25);
        verify(ps).setMaxRows(500);
    }

    @Test
    @SuppressWarnings("unchecked")
    void canales_leeCadaColumnaDeCopSuppChnl() throws Exception {
        // Given
        ArgumentCaptor<RowMapper<CopSuppressionChannel>> mapper = ArgumentCaptor.forClass(RowMapper.class);
        when(ops.query(any(PreparedStatementCreator.class), mapper.capture())).thenReturn(List.of());
        repository.findAllChannels(30, 0);
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString("COUNTRY_CODE")).thenReturn("MX");
        when(rs.getString("REQMODE")).thenReturn("RT");
        when(rs.getString("CHANNEL_ID")).thenReturn("CAT");
        when(rs.getString("SUPPRESSION_FLAG")).thenReturn("Y");
        when(rs.getString("OPERATION_FLAG")).thenReturn("N");
        when(rs.getString("SOURCE_SYSTEM")).thenReturn("ECRM");

        // When
        CopSuppressionChannel fila = mapper.getValue().mapRow(rs, 0);

        // Then
        assertThat(fila).isEqualTo(new CopSuppressionChannel("MX", "RT", "CAT", "Y", "N", "ECRM"));
    }

    // ------------------------------------------------------------ operaciones

    @Test
    void operaciones_devuelveLasFilasDelJdbc() {
        // Given
        CopSuppressionOperation fila = new CopSuppressionOperation("UpdateOffer", "Y", "CAT");
        when(ops.query(any(PreparedStatementCreator.class), ArgumentMatchers.<RowMapper<CopSuppressionOperation>>any()))
                .thenReturn(List.of(fila));

        // When / Then
        assertThat(repository.findAllOperations(30, 0)).containsExactly(fila);
    }

    @Test
    void operaciones_creaLaSentenciaConElTimeoutYElMaximoDeFilasPedidos() throws Exception {
        // Given
        Connection con = mock(Connection.class);
        PreparedStatement ps = mock(PreparedStatement.class);
        when(con.prepareStatement(CopSuppressionNatives.FIND_ALL_OPERATIONS)).thenReturn(ps);
        ArgumentCaptor<PreparedStatementCreator> creator = ArgumentCaptor.forClass(PreparedStatementCreator.class);
        when(ops.query(creator.capture(), ArgumentMatchers.<RowMapper<CopSuppressionOperation>>any())).thenReturn(List.of());

        // When
        repository.findAllOperations(15, 0);
        creator.getValue().createPreparedStatement(con);

        // Then
        verify(ps).setQueryTimeout(15);
        verify(ps).setMaxRows(0);                  // 0 = sin límite
    }

    @Test
    @SuppressWarnings("unchecked")
    void operaciones_leeCadaColumnaDeCopSuppOpr() throws Exception {
        // Given
        ArgumentCaptor<RowMapper<CopSuppressionOperation>> mapper = ArgumentCaptor.forClass(RowMapper.class);
        when(ops.query(any(PreparedStatementCreator.class), mapper.capture())).thenReturn(List.of());
        repository.findAllOperations(30, 0);
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString("OPERATION_NAME")).thenReturn("UpdateOffer");
        when(rs.getString("OPERATION_SUPPRESS_FLAG")).thenReturn("Y");
        when(rs.getString("REQCHANNEL")).thenReturn("CAT");

        // When
        CopSuppressionOperation fila = mapper.getValue().mapRow(rs, 0);

        // Then
        assertThat(fila).isEqualTo(new CopSuppressionOperation("UpdateOffer", "Y", "CAT"));
    }
}
