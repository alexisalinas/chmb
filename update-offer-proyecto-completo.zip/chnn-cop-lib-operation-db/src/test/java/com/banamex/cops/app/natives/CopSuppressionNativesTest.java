package com.banamex.cops.app.natives;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias de {@code CopSuppressionNatives}.
 * <p>
 * Casos cubiertos: las dos sentencias son las de {@code FetchChannels} y {@code FetchOperations} de BW, sin alias,
 * sin parámetros y solo de lectura.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class CopSuppressionNativesTest {

    @Test
    void canales_esElSelectDeLaTablaDeCanales() {
        // Given
        // (sin precondiciones: son constantes)

        // When / Then
        assertThat(CopSuppressionNatives.FIND_ALL_CHANNELS).isEqualTo("SELECT * FROM COP_SUPP_CHNL");
    }

    @Test
    void operaciones_esElSelectDeLaTablaDeOperaciones() {
        // Given
        // (sin precondiciones: son constantes)

        // When / Then
        assertThat(CopSuppressionNatives.FIND_ALL_OPERATIONS).isEqualTo("SELECT * FROM COP_SUPP_OPR");
    }

    @Test
    void sonSoloDeLectura_ySinParametros() {
        // Given
        // (sin precondiciones: son constantes)

        // When / Then
        assertThat(CopSuppressionNatives.FIND_ALL_CHANNELS).doesNotContain("?", ":", "UPDATE", "DELETE", "INSERT");
        assertThat(CopSuppressionNatives.FIND_ALL_OPERATIONS).doesNotContain("?", ":", "UPDATE", "DELETE", "INSERT");
    }
}
