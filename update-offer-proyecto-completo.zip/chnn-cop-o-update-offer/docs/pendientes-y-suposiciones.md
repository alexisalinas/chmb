# Qué falta para cerrar el desarrollo (sin dejar suposiciones)

Leyenda: **CONFIRMADO** = lo dijiste tú, viene en tus archivos o se ve en una captura. **SUPUESTO** = el código lo asume. **FALTA** = no hay dato.

---

## A. Sin `RqHeader` ni `ClientDetails`

**Decisión:** el flujo ya no usa `RqHeader` ni `ClientDetails`. Se eliminaron `RqHeaderFactory`, `InvalidRqHeaderException`, `RqHeaderXmlMapper`, `RqHeaderDTO` y `ClientDetailsDTO`, y el bloque `update-offer.header` del yml.

| Antes salía del `RqHeader` | Ahora |
|---|---|
| `Header` del mensaje al EMS | **No se manda.** El XML lleva solo el evento `UpdateOffer` con sus campos |
| `UpdatedBy` (`ClientDetails/UserID`) | Sale del **header `client_id`** (si no llega, va vacío: el elemento se escribe porque es obligatorio) |
| `UpdateTime` sin zona horaria | La hora en que se recibe la oferta |
| `uuid` del evento de Kafka | Header HTTP `uuid` |
| `transactionTime` de Kafka | La hora en que se recibe la oferta |
| `ESBUUID` | Ya no se usa |

Los headers que llegan se siguen validando con `HeaderValidation` (`uuid`, `ChannelId`, `sid`, `countryCode`, `businessCode`, `host`, `Accept`, `Content-Type`) y se muestran en el log `[REQUEST]`.

**Pendiente de confirmar con una respuesta real del EMS:**
1. ¿Acepta el mensaje **sin `Header`**? El que sí aceptó (respondió con un error de negocio) llevaba `Envelope/Header/Body`.
2. ¿Espera el `Envelope`? Con `update-offer.ems.envelope: false` se manda solo `<UpdateOffer>`.
3. ~~¿Acepta `UpdatedBy` vacío?~~ Ahora `UpdatedBy` lleva el `client_id` del header; solo va vacío si la petición no lo trae.

---

## B. Mensaje al EMS y su respuesta

| Tema | Estado | Qué falta |
|---|---|---|
| Estructura `Envelope/Header/Body` sin URLs | **CONFIRMADO** | — |
| Cola `citi.gcg.la.cop_163621.mx_card.offer.update` | **CONFIRMADO**: es una sola cola, fija en `update-offer.ems.queue` (ya no se arma con el `concat`) | — |
| Va por la rama "XSD Format" | **CONFIRMADO** | — |
| `RequestTimeout_Category1 = 7` | **CONFIRMADO** (segundos) | — |
| `JMSExpiration = 30` | **CONFIRMADO: milisegundos.** Aplicado: `update-offer.ems.time-to-live-ms: 30` | 30 ms es muy corto: si el EMS no alcanza a recibir el mensaje saldrá `(sin respuesta)` en `[EMS] Responde`. En ese caso, subir el valor |
| Nombre del elemento del cuerpo (`UpdateOffer`) | SUPUESTO | Como ya manda el XML y el EMS responde, confirmar que ese es el correcto |
| Campos de la **respuesta** del EMS | **CONFIRMADO** por el log de BW: `ResponseCode`, `ResponseText` y `ControlField` repetido (el 1.º es el tipo de contexto; el 2.º, un número o vacío) | Falta una respuesta real de tu ambiente (`[EMS] Respuesta recibida`) para confirmar que es igual |
| Varias ofertas en un solo mensaje al EMS | **CONFIRMADO: sí** (el JMS manda múltiples ofertas) | **La respuesta es una por oferta**: según la guía de `OpUpdateOffer`, el mapper recorre un `UpdateOfferRes` por cada oferta (el parser ya lo soporta: `toRestResponses`). El `Start` también trae `UpdateOfferRq` repetido. **Falta la estructura del `Body` del mensaje con varias ofertas** (el log que pasaste solo trae peticiones de una). Hoy el micro manda un mensaje por oferta |
| Formato del log de la respuesta (`LogPayload` > `RsHeader` + `Body/UpdateOfferRs`) | **CONFIRMADO** por el log de BW | `RsHeader/ResponseCode`: solo se vio `0`; para `ERROR` el micro pone `1` (supuesto) |
| XPath de `ApptEndTime` | **FALTA** | `JMS Queue Requestor` > `Input` > `ApptEndTime - [Choose]`, abrir `[When]` y `[Otherwise]` |

---

## B0. Cómo viaja el evento al EMS (propiedades del mensaje o cuerpo XML)

**Hallazgo:** el `JMS Queue Requestor` de BW (rama *XSD Format*) mapea `UpdateOfferRq` a **`OtherProperties`**: en un mensaje JMS eso son las **propiedades del mensaje** (`_nm_` = nombre del evento, `_ns_` = namespace, y un campo por propiedad), no el cuerpo. El XML `Envelope/Header/Body` que mandaba el micro lo armé yo copiando el estilo de tu ejemplo de otro servicio (`UpdateConfigRq`); no salía del mapeo.

**Síntoma que cuadra:** el EMS contestaba "Campaign cmp: ... is not present" aunque la campaña existía: si el consumidor lee `CampaignID` de las propiedades, con solo el cuerpo XML le llegaba vacío.

**Qué se hizo:** `EmsSender` ahora manda también las propiedades (`update-offer.ems.message-format`): `properties` (**por defecto**: solo propiedades, cuerpo vacío; es lo que arma el `Input` del `JMS Queue Requestor` y lo normal con eventos de BusinessEvents, donde `_nm_` y `_ns_` son propiedades del mensaje), `both` (propiedades y XML en el cuerpo) o `xml` (solo el XML, como se probó al inicio). El log `[EMS] Envía` muestra las propiedades (con la tarjeta enmascarada). `_ns_` sale de `update-offer.ems.event-namespace`.

**Falta confirmar con una respuesta real del EMS:** cuál de los tres formatos acepta. Se prueba con `properties`; si el EMS sigue sin encontrar la campaña, probar `both` y luego `xml`. En BW se confirma con la pestaña *Configuration* del `JMS Queue Requestor` (*Message Type*) y el `Input` (¿hay un nodo `Body` mapeado o solo `OtherProperties`?).

---

## B1. Cómo viaja el mensaje al EMS (confirmado: *Message Type* = XML Text)

El `JMS Queue Requestor` es de tipo **XML Text**, así que el cuerpo del mensaje es XML. Por eso el valor por defecto es `update-offer.ems.message-format: both`: **XML en el cuerpo y las propiedades `OtherProperties`** (`_nm_`, `_ns_` y un campo por propiedad). El XML del cuerpo es solo el evento (`<UpdateOffer>…</UpdateOffer>`, sin `Envelope` ni `Header`); con `xml-namespace: true` lleva su namespace como `xmlns`. Si el EMS sigue sin encontrar la campaña, se prueban `properties` o `xml` y las variantes del XML. Falta ver en BW si el `Input` mapea un nodo `Body` o solo `OtherProperties`.

## B2. Respuesta: la del micro o la del EMS

En los logs de BW la respuesta al cliente es lo que contesta el EMS: `COP_UPDOF_0`, `Successfully update offer off:mx:CAMPAÑA:OLA:CLIENTE` y dos `ControlField` (por ejemplo `5` y `8813625550465000`). El micro devuelve su propio mensaje con la fecha (decisión del equipo). Con `update-offer.response.source: ems` devuelve lo que contestó el EMS, como BW (las ofertas `U` siguen el formato de `Map-Data`).

---

## C. Zona horaria

**Respondido por el equipo (archivo 02 de `pendientes-por-proceso`) y aplicado:**

| Tema | Respuesta | Qué quedó en el micro |
|---|---|---|
| `TranslateTimeZone` | Dejarlo en **`true`**, pero configurable en el yml | `update-offer.timezone.translate-time-zone: true` (en las globales de BW está en `false`) |
| `System` | Es el `ChannelID` del `GetContext` | Se toma del header `ChannelId` (ya no hay un valor fijo) |
| `SysMode` | `RealTime` | `update-offer.timezone.sys-mode: RealTime` |
| `ResponseCode` | `COP_TZCOD_115` | `update-offer.timezone.invalid-code: COP_TZCOD_115` (la fecha u hora inválida). **Supuesto:** si 115 es en realidad el código de "no configurado", dímelo |
| Formatos de conversión | Los que ya están | Sin cambios |
| `US/Central` | Es la de las variables y se usa para la hora del evento | `UpdateTime` y, ahora, también `timeStamp` y `ResponseTime` de Kafka usan `ecrm-time-zone: US/Central` |
| Ambientes | Solo que quede en el yml para cambios | Un yml por ambiente |

**Ojo: `COP_TIMEZONE_LOOKUP` está vacía.** Con `translate-time-zone: true` el micro busca la fila `(ChannelId, RealTime, Request)`, no la encuentra y responde `COP_TZCOD_114` ("TimeZone not configured"). Ese código **no detiene** el flujo (así lo dice la condición del mapper de BW), pero **tampoco convierte** fechas ni horas. Para que convierta hay que cargar una fila por canal: plantilla en `docs/cargar-timezone-lookup.sql`.

| Tema | Estado | Qué falta |
|---|---|---|
| Significado de `COP_TZCOD_115` | **SUPUESTO** (fecha u hora inválida) | Confirmar con el proceso `/BW/Common/TimeZoneValidation` > `End` |
| Valores de la tabla de zonas horarias | **FALTA** | Zona, offset y formatos del cliente por canal |
| Horario de verano de `US/Central` | **Aviso** | En horario de verano el offset es −05:00; tu ejemplo de Kafka traía −06:00 (hora del servidor). Ahora el evento usa `US/Central` |

---

## D. Kafka

**Resuelto con la guía de BW (secciones 15 a 18) y con tu ejemplo de JSON:**
- **Cola:** `citi.gcg.la.cop_163621.MX_dm.raw.cops-offer-fulfillment-req`, una sola y fija (`offer.kafka.queue`). No se arma.
- **Mensaje a la cola:** según tu indicación, la cola de Kafka recibe el **JSON del evento todo junto** (`offer.kafka.message-format: json`); el `RefId` va como `JMSCorrelationID` y como propiedad `RefId`. La guía de BW describe `KafkaMsgSender` con `Body/root/RefId` y `Body/root/jsonString`: ese envoltorio XML queda disponible con `message-format: envelope`.
- **Clave de la oferta para la consulta:** `off:mx:CAMPAÑA:OLA:CLIENTE[:CUENTA]`. **La tarjeta no va** (así lo arma el JDBC Query de `DataFetch`). El `RefID` del evento sigue la fórmula de BW: `campaña_ola_cliente_cuenta_tarjeta` **solo si la cuenta y la tarjeta tienen valor**; en cualquier otro caso, `campaña_ola_cliente`.
- **Clave de la ola:** `wvch:OLA:CANAL`, donde el canal es el `RequestingChannel`.
- **Campos que llena la base** (con nombres del esquema de BW): `ID_ProductType` (`PRDTYPE`), `CRP_Category_ID` (`CRPCATEGORYID`), `Reason_Code`, `Reason_Description`, `AppointmentDate` (`APPTSTARTDATE_TM`), `AppointmentMinDur` (minutos de la cita, solo si es mayor que 0) y `PrdFamily`. Se omiten si vienen vacíos, por eso tu ejemplo no los mostraba.
- `ResponseCode` y `ResponseText` del evento salen de la **respuesta del JMS** (alias `JMS` en `KafkaSenderDashboard`). Kafka corre después del JMS, espera su respuesta y no depende de que el código sea de éxito. Sin respuesta del JMS no se envía.

**Qué falta:**

| # | Dato que falta | Dónde se obtiene | Por qué hace falta |
|---|---|---|---|
| 1 | **Pasar de `dry-run` a `jms`** | Tú: `offer.kafka.mode: jms` | La cola ya está; con `dry-run` solo se escribe el JSON en el log |
| 2 | ~~Conexión, modo de entrega y expiración de `KafkaMsgSender`~~ | **Resuelto:** es la misma configuración que el JMS del EMS | `JmsOfferPublisher` usa el mismo `updateOfferJmsTemplate`, entrega no persistente y `offer.kafka.time-to-live-ms` (igual al del EMS: 30 ms) |
| 3 | ~~Nombre del evento~~ | **Resuelto:** `Updateofferrequest` (constante de `header/name` en `KafkaSenderDashboard`; `version` `1.0` y `producerCSI` `163621`) | `offer.kafka.event-name: Updateofferrequest`. Tu ejemplo de JSON traía `Fulfillrequest`; si el consumidor espera ese, se cambia en el yml |
| 4 | ~~`sid`~~ | **Resuelto:** es el `ESBUUID`, un GUID que se genera por evento | `KafkaSenderDashboard` genera el GUID (`UUID.randomUUID()`) y va como `sid`; el `UUID` sigue siendo el del header HTTP |
| 5 | **Datos de la oferta en la base:** clave de la ola y de la oferta reales | Bloques 1 y 2 de `prueba-completa-kafka.sql` | La primera oferta de prueba no tiene ola en `D_WAVECHINFO` |
| 6 | Si en tu base la clave de las ofertas **con tarjeta** incluye la tarjeta | Una oferta con tarjeta de `D_OFFERPALETTE` | `DataFetch` la arma sin tarjeta; si tu `EXTID$` la lleva, saldrá `KAFKA-NO-ROWS` |
| 7 | **De qué columna sale `OfferStartDate`** | Mapper de `FulFillKafkaSender` | Hoy usa `OFFERCREATIONDATE_TM` (por la fecha del ejemplo) |
| 8 | ~~¿`CitiDataStore` es la misma BD `MXCPO2U`?~~ | **Resuelto: sí, es la misma base** | La consulta de Kafka usa el `spring.datasource` del yml (Oracle `MXCPO2U`, usuario `RMXCOP4`): no hace falta otra conexión |
| 9 | **`AB-KafkaSender...` y `AbInitioResponse`** | `OpUpdateOffer` | Camino alterno cuando `AbInitioTest = 'Y'`. Hoy vale `N`; con `Y` el micro avisa en el log y sigue por el JMS |
| 10 | Si `CustomerNo` ya llega con 9 dígitos | Un request real | En la clave y en el `RefID` va tal como llega; el body lo rellena a 9 |
| 11 | Si `CardNumber` va completa | Seguridad / consumidor | El ejemplo la trae completa (`mask-card-number: false`) |
| 12 | Contrato del consumidor (esquema del evento 1.0) | Equipo consumidor | `OfferStatus` es obligatorio para Kafka y opcional en tu API: esas ofertas se descartan |
| 13 | Si falla: reintentos, alerta, cola de errores | Operación | Hoy: 3 intentos y un `KAFKA-ERROR` en el log |
| 14 | Volumetría (transacciones por segundo) | Negocio | Para dimensionar el ejecutor |
| 15 | Si es Kafka directo: tópico `lac.*`, brokers, seguridad, FID, tarjeta Jira MIATR | Plataforma Kafka | Solo para `mode: kafka` |

---

## D2. Mapper final de `OpUpdateOffer` (el que arma `UpdateOfferRes`)

Según `guia_OpUpdateOffer.md`:

| Caso del mapper | Qué hace en BW | En el micro | Qué falta |
|---|---|---|---|
| **1.** Existe el `ResponseCode` de zona horaria | Responde con su `ResponseCode` y `ResponseText`; `ContactReference`, `StartDate`, `EndDate` y `CmpMode` vacíos | **Implementado** (`UpdateOfferServiceImpl` + `UpdateOfferFlowConditions`) | El sub-`Choose` **`ControlField`**: **confirmado, todas sus ramas van vacías**. Y dos condiciones extra de la guía: `OfferStatus != "U"` y `CounterOfferAvailUpdate != 'Y'` |
| **2.** `OfferStatus = "U"` | Arma la llave `off:mx:...` (con `_`) y responde `COP_UPDOF_432` si falta `CampaignID`, o `COP_UPDOF_0` y `Successfully update offer <llave>`, **sin leer la respuesta del EMS** | **Implementado** en `UpdateOfferResponseFactory.success(request)` (sin fecha; configurable en `update-offer.response.status-u-*`) | Nada: `ControlField` y los campos opcionales no tienen valor en este caso (confirmado) |
| **3.** Cualquier otro caso | `AbInitioTest='Y'`: respuesta de AbInitio; si no, la respuesta del JMS (un `UpdateOfferRes` por oferta) | La respuesta del JMS **sí** (una oferta por mensaje); AbInitio **no** | Valor de `AbInitioTest`; estructura del `Body` para varias ofertas |

Globales que salen de esta guía: `COP/ParametricConfiguration/CounterOfferAvailUpdate` = **`Y`** (confirmado) y `AbInitioTest` = **`N`** (confirmado; está en el yml como `update-offer.ab-initio-test`). Con `CounterOfferAvailUpdate = Y`, la condición corta del Notepad (`OfferStatus = "U"` y `CounterOfferAvailUpdate = 'Y'`) se cumple para los pedidos con estatus `U`, y la condición larga del error de zona horaria (que exige `CounterOfferAvailUpdate != 'Y'`) nunca se cumple. En el log que pasaste todas las peticiones tienen `OfferStatus` `G`, `K` o `R`; ninguna `U`. Todas las respuestas traen `COP_UPDOF_0` y `Successfully update offer off:mx:...`, así que ese texto lo arma el EMS en el flujo normal.

**Pendiente de tu parte (la guía lo pide):** expandir en TIBCO el `ControlField` del Caso 1 y el `UpdateOfferRes` del Caso 2, con la tabla de qué escribe cada campo.

---

## D3. `SetContext` (el `RsHeader` de la respuesta)

Según `migracion-updateoffer-setcontext.md`, `SetContext` arma el `RsHeader` de la respuesta de BW: `DateAndTimeStamp`, `UUID` y `ESBUUID` se copian del `GetContext`, y el `ResponseCode` sale así:

| Supresión (`Indicator`) | Global `COP/Connections/JSON/updateoffer` | `RsHeader/ResponseCode` |
|---|---|---|
| `"true"` | cualquiera | El `ResponseCode` del primer `ResponseDetails` de la supresión |
| distinto de `"true"` | distinto de `'Y'` | El `ResponseCode` de `Map-Data` (la respuesta final, camino JMS) |
| distinto de `"true"` | `'Y'` | El `ResponseCode` de `RsUpdateOffer` (camino REST/JSON del backend) |

**En el micro:** la API REST no devuelve `RsHeader` (la respuesta es la lista de ofertas), así que no hay nada que migrar para el cliente. La lógica de supresión ya coincide: si el `Indicator` es `"true"`, se responde con el `ResponseCode` y `ResponseText` del detalle, y las listas vacías o los `Indicator` nulos no fallan.

**Valor confirmado: `COP/Connections/JSON/updateoffer = Y`.** Entonces el `RsHeader/ResponseCode` sale de `RsUpdateOffer`, la respuesta de una llamada **REST/JSON** del backend (`RenderJSON` → `Invoke-REST` → `Parse-JSON`).

**Corrección a lo que dije antes:** había afirmado que esto explicaba el `RsHeader/ResponseCode = 0` del log de ejemplo frente a `COP_UPDOF_0` en el cuerpo. No se sostiene: según `guia_migracion_logresponse_tibco_a_java.md`, con `updateoffer = Y` el cuerpo que se registra también sale de `RsUpdateOffer`, así que cabecera y cuerpo tendrían el **mismo** código. El `0` del log de ejemplo sigue **sin explicación** (probablemente es de otra versión del proceso).

**Consecuencia:** en BW, con `updateoffer = Y`, además del mensaje JMS hay una llamada REST/JSON al backend, y el micro **no la hace**. Hoy el micro escribe `RsHeader/ResponseCode` = `0` (o `1` si responde `ERROR`), un supuesto que coincide con lo visto en el log.

**Preguntas:**
1. ¿Qué es esa llamada REST (`Invoke-REST`): URL, método, JSON que manda (`RenderJSON`) y qué conexión usa? ¿Va antes o después del JMS? ¿Si falla, cambia la respuesta al cliente o solo el `RsHeader`?
2. ¿Qué valor lleva `RsHeader/ResponseCode` en los casos de error y de supresión? (`SetContext` toma el código del primer detalle de supresión cuando el `Indicator` es `"true"`).

---

## D4. Logs (nuevo enfoque)

Cambio de rumbo: el micro ya no replica los logs de BW. Quedan solo estos, todos en JSON o con el mensaje tal cual:

| Log | Qué muestra | Dónde |
|---|---|---|
| `[REQUEST]` | Los **headers recibidos** y el **JSON del body** (tarjeta y headers de seguridad enmascarados) | `AuditLogService.logRequest`, al entrar |
| `[EMS] Envía` / `[EMS] Responde` | El XML que se manda al EMS y lo que responde (`(sin respuesta)` si no contesta) | `EmsSender` |
| `[KAFKA] Envía` | El JSON que se le va a enviar a Kafka (tarjeta enmascarada en el log). **Ya no se registra lo que recibe** | `FulFillkafkaSender` |
| `[KAFKA] Resultado` | Si el evento se envió o no: `Successfully send offer to Kafka {fecha}` o `Error send offer to Kafka {fecha}. Falló en {paso}: {causa}` (fecha de `ECRMTimeZone`, `yyyy/MM/dd HH:mm:ss`). En `dry-run`: `Kafka en dry-run: el mensaje no se publicó {fecha}` | `FulFillkafkaSender` |
| `[RESPONSE]` | El JSON que responde el micro (une `LogResponse` y `End`) | `AuditLogService.logResponse`, al salir |

- No hay logs en los subprocesos (zona horaria, supresión, etc.), salvo errores reales (`error`/`warn`).
- `AuditPointsEnabled` se conserva: posición 1 = `[REQUEST]`, posición 4 = `[RESPONSE]`. Con `1001` salen los dos.
- Se eliminaron los XML de log de BW (`<root>`, `LogPayload`, `RsHeader`), `TransactionContext` y los métodos `toLog...` de los mappers. Con eso dejan de aplicar las dudas anteriores sobre el formato del `Payload`, el `ServiceName` y el `RsHeader/ResponseCode`.
- El `ClientDetails` ya no existe en el micro.

---

## D5. `End` de `OpUpdateOffer` (la respuesta que se devuelve al cliente)

**Decisión tomada (opción B): la respuesta la arma el micro** y no depende de la del JMS:

| Situación | Respuesta del micro |
|---|---|
| El flujo funciona | Código `COP_UPDOF_0` y `Successfully update offer {dateTime}`, con la fecha de `ECRMTimeZone` en formato `yyyy/MM/dd HH:mm:ss` |
| Falla un paso (zona horaria, supresión, armado del XML o envío al EMS) | Código `ERROR` y `Error update offer {dateTime}. Falló en {step}: {detail}` |
| Zona horaria inválida | El código y texto de la validación (`COP_TZCOD_115`) |
| Operación suprimida | El código y texto del detalle suprimido |

Todo se configura en `update-offer.response.*` (código, texto y formato de fecha). Lo que contesta el JMS (`ResponseCode` y `ResponseText`) **solo se envía a Kafka**; Kafka va **después** del JMS y espera su respuesta. **Si el JMS no devuelve `ResponseCode` y `ResponseText`, Kafka no se envía** (`[KAFKA] Resultado` dice `Falló en Respuesta del JMS`).

**Falta confirmar** (archivo 04 de `pendientes-por-proceso`):
1. Los códigos y textos exactos (y si el texto de éxito lleva la clave de la oferta).
2. ~~Si el EMS contesta un error de negocio~~: **decidido, el flujo sigue como ahora**: el micro responde éxito y lo que contestó el EMS solo va a Kafka. Lo que se agregó es el log `[KAFKA] Resultado`, que dice si el evento se envió o no.
3. Si el JMS contesta o no (el log `[EMS] Responde:` lo dirá).

**Decisión sobre `Indicator` (lista):** en XPath, `Indicator != "true"` es verdadero si **al menos un** `Indicator` existe y es distinto de `"true"`. Opción A (paridad con BW) frente a opción B (lo que hace hoy el micro: cualquier `"true"` suprime). Se recomienda la B, pero conviene confirmarlo con datos reales.

---

## D6. Lista de entidades suprimidas (`/BW/StartUp/startUpSuppression`)

**Resuelto con tus capturas:** la lista se carga de `COP_SUPP_CHNL` y `COP_SUPP_OPR` (misma base `CitiDataStore` = `MXCPO2U`) y se arma como el `SetVariable` de BW. Queda implementado (librería + `StartUpSuppressionLoader` + `DbSuppressedEntitiesClient`, que carga la primera vez y guarda en memoria). Se activa con `cop.suppression.check-for-suppression: "Y"` (hoy `"N"`, como la global `CheckForSuppression`). Para revisar las tablas: `docs/prueba-supresion.sql`.

**Falta:** los valores de `COP/QueryRecords/TimeoutDefault` y `COP/Connections/BSDB/MaxConns`; la global `SuppressionType` (`CHNL_LV...`); y comprobar que las nueve columnas existen (bloque 3 del `.sql`).

---

## E. Decisiones abiertas

1. ~~Un mensaje por oferta o uno por lote~~: **resuelta, va un solo mensaje con todas las ofertas.** Falta implementarlo (ver sección B).
2. ~~Camino de la respuesta con `updateoffer = Y`~~: **resuelta, la arma el micro** (sección D5). Falta decidir qué pasa si el EMS contesta un error de negocio.
3. **`*` como lista:** hoy una lista vacía es válida; si "de uno a muchos" significa mínimo uno, hay que agregar `@NotEmpty`.
4. **Header `sid`:** ¿se usa en algún campo?
5. **Lo que ibas a preguntar:** el origen de `Org`, `OrgUnit`, `TerminalID` y `UserID` (sección A), y quién carga la lista de entidades suprimidas y cuál de las dos clases cliente se conserva.

---

## F. Suposiciones activas en el código

| Archivo | Suposición | Se confirma con |
|---|---|---|

| `UpdateOfferRequestXmlMapper.toEmsXml` | El EMS acepta el mensaje sin `Header` y con `Envelope/Body/UpdateOffer` | Archivo 06 de `pendientes-por-proceso` |
| `OfferEventMapper` | `ApptEndTime` igual que `ApptStartTime`; relleno de `CustomerNO` a 9 | XPath de `ApptEndTime`; sección C |
| `TimeZoneMapRequest` | Request: hora y fecha-hora convertidas de la zona del cliente a ECRM | Sección C |
| `TimeZoneValidationService` | Códigos `000` y `101`; `System` y `SysMode` | Sección C |
| `FulFillkafkaSender` | `OfferStartDate` ← `OFFERCREATIONDATE_TM`; campos que no se envían; clave de la ola | Sección D, puntos 4 a 6 |
| `JmsOfferPublisher` | El mensaje a la cola es el JSON del evento todo junto (`message-format: json`); `JMSCorrelationID` y propiedad `RefId` = RefID | Confirmar con el bridge: si espera el envoltorio XML, `message-format: envelope` |
