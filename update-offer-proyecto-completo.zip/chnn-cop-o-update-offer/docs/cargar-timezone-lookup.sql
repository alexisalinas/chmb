-- ============================================================================
-- COP_TIMEZONE_LOOKUP esta VACIA en UAT_COPS. Con translate-time-zone = true el micro responde
-- COP_TZCOD_114 ("TimeZone not configured") y CONTINUA SIN CONVERTIR fechas ni horas.
-- Para que convierta hace falta una fila por canal (System = ChannelId), modo y tipo de operacion.
--
-- El micro busca con:  TZ_SYSTEM_NAME = <ChannelId del request>
--                      TZ_MODE         = RealTime
--                      TZ_OPERATION_TYPE = Request   (y Response, cuando se use)
--
-- Los valores entre < > los define el equipo de TIBCO / negocio; NO los invento.
-- ============================================================================

-- 1) Ver si ya hay algo (debe seguir devolviendo 0 filas hasta que se cargue)
SELECT COUNT(*) AS filas FROM COP_TIMEZONE_LOOKUP;

-- 2) Plantilla de carga (una fila por canal y tipo de operacion)
INSERT INTO COP_TIMEZONE_LOOKUP
       (TZ_SYSTEM_NAME, TZ_MODE,   TZ_TIMEZONE,      TZ_OPERATION_TYPE, TZ_TIME_OFFSET,
        TZ_DATETIME_FORMAT, TZ_DATE_FORMAT, TZ_TIME_FORMAT)
VALUES ('<CHANNELID, por ejemplo el valor del header ChannelId>',
        'RealTime',
        '<zona horaria del cliente>',
        'Request',
        '<offset, por ejemplo -06:00>',
        '<formato fecha-hora del cliente>',
        '<formato de fecha del cliente>',
        '<formato de hora del cliente>');

-- 3) Comprobar la fila que usara el micro
SELECT * FROM COP_TIMEZONE_LOOKUP
 WHERE TZ_SYSTEM_NAME = '<CHANNELID>' AND TZ_MODE = 'RealTime' AND TZ_OPERATION_TYPE = 'Request';
