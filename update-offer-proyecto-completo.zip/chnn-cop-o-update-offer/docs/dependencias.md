# Dependencias del micro (`pom.xml`)

Es **tu `pom.xml` original** (Java 21, Spring Boot 3.5.15) con solo lo que le faltaba. Todo lo agregado está marcado con `AGREGADO` y no se quitó ninguna línea tuya.

## Lo que se agregó

| Dependencia | Para qué | Quién la usa |
|---|---|---|
| `org.springframework:spring-jms` | `JmsTemplate` | `EmsSender`, `JmsOfferPublisher` |
| `jakarta.jms:jakarta.jms-api` | API de JMS (`Session`, `TemporaryQueue`, ...) | `EmsSender`, `JmsOfferPublisher` |
| `spring-boot-starter-jdbc` | `NamedParameterJdbcTemplate` con el `spring.datasource` del yml | `OfferFulfillmentConfig` (consulta de Kafka) |
| `maven-surefire-plugin` con `argLine` | Pasa el agente de JaCoCo a las pruebas y evita el aviso de Mockito en Java 21 | pruebas |
| Exclusión `**/KafkaExecutorConfig*` en JaCoCo | Clase de configuración sin lógica | cobertura |

Las dos de JMS no llevan versión: la maneja Spring Boot. Si ya llegaban por `mafim-u-messaging-connector`, no cambian nada.

## Opcionales (comentadas en el `pom`)

Descoméntalas solo si al compilar falta el paquete:

| Dependencia | Si marca error en... |
|---|---|
| `io.swagger.core.v3:swagger-annotations-jakarta` 2.2.30 | `io.swagger.v3.oas.annotations.media.Schema` (`RqHeaderDTO`, `ClientDetailsDTO`) |
| `tools.jackson.core:jackson-databind` 3.0.0 | `tools.jackson.databind.json.JsonMapper` (`AuditLogService`, `HeaderValidation`, `UpdateOfferResponseXmlMapper`, `UserTextParser`, `FulFillkafkaSender`, `JmsOfferPublisher`) |

El código ya usaba las dos antes, así que lo normal es que lleguen con tus librerías corporativas. Tu `pom` excluye `tools.jackson.core:jackson-core` de `mafim-u-digital-banking-legacy-mapper`, lo que indica que Jackson 3 llega por ahí.

## Lo que usa el código y ya estaba en tu `pom`

| Dependencia de tu `pom` | Quién la usa |
|---|---|
| `chnn-cop-lib-operation-db` | `CopOfferFulfillmentService`, `CopTimezoneLookupService` (`OfferDataClient`, `CopTimezoneLookupClient`) |
| `spring-boot-starter-web` | `UpdateOfferController`, `HeaderValidation`; anotaciones de Jackson 2 de los DTOs |
| `spring-boot-starter-validation` y `jakarta.validation-api` | Todos los DTOs y `DtoValidator` |
| `jackson-databind`, `jackson-core`, `jackson-datatype-jsr310` | Jackson 2 de Spring MVC |
| `lombok` 1.18.46 | casi todas las clases |
| `mafim-u-messaging-connector(-ems)`, `tibco-tibjms` | Conexión al EMS (`jmsConfig`, `EmsSender`) |
| `spring-boot-starter-test` | JUnit 5, Mockito, AssertJ, MockMvc, Logback (`ListAppender`) |

**Mi código no usa** Feign, Resilience4j, AspectJ, Actuator, JAXB, Spring Cloud Bootstrap ni DevTools; no las quité porque pueden usarlas tus clases.
**No se necesita `spring-kafka`:** solo lo usa `KafkaOfferPublisher`, que está fuera de `src` (`kafka-opcional/`).

## JaCoCo (90 %)

- Tu regla ya exige **90 % de líneas** (`BUNDLE`, `LINE`, `COVEREDRATIO`) en `verify`; la dejé igual.
- Dejé comentada la regla de **ramas** al 90 %: descoméntala si la quieres. Es más exigente.
- Excluidos: `UpdateOfferApplication`, `KafkaExecutorConfig`, `config/**`, `constant/**` y `dto/**`.
- `lombok.config` (`lombok.addLombokGeneratedAnnotation = true`) evita que se cuente el código que genera Lombok.
- `mvn clean install -DskipTests` no falla por cobertura.

## Observaciones de tu `pom` (no las cambié)

- Hay propiedades repetidas en `<properties>`; Maven toma la última: `sonar.coverage.exclusions` (la segunda excluye `model/**` y ya no `dto/**`), `jacoco.version`, `checkstyle.version` (queda `9.3`) y `sonar.java.coveragePlugin`.
- Las propiedades `digital-engineering-headers.version`, `digital-engineering-logging.version` y `mafim-u-digital-banking-actuator.version` no se usan en ninguna dependencia.
