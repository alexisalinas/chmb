package com.banamex.cops.update_offer.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Arma las claves a partir de los valores SIN modificar (como llegan en el request).
 * Según BW (DataFetch y el ejemplo del evento):
 *   offerKey  = off:mx:CAMPAÑA:OLA:CLIENTE[:CUENTA]         (D_OFFERPALETTE.EXTID$; la tarjeta NO va, igual que DataFetch)
 *   refId     = CAMPAÑA_OLA_CLIENTE[_CUENTA_TARJETA]        (RefID del evento: la cuenta y la tarjeta solo van juntas)
 *   waveKey   = wvch:OLA:CANAL                              (D_WAVECHINFO.EXTID$; el canal es el RequestingChannel)
 * La cuenta y la tarjeta se omiten si vienen vacías.
 */
@Component
@RequiredArgsConstructor
public class OfferKeyBuilder {

    private final OfferKafkaProps props;

    /**
     * Arma la clave de la oferta para la consulta ({@code D_OFFERPALETTE.EXTID$}):
     * {@code off:mx:campaña:ola:cliente[:cuenta]}. La cuenta se omite si viene vacía y la tarjeta no forma
     * parte de la clave (así lo arma el JDBC Query de {@code /BW/Kafka/DataFetch}).
     *
     * @param campaignId campaña
     * @param waveId     ola
     * @param customerNo cliente, tal como llega (sin rellenar con ceros)
     * @param accountNo  cuenta (opcional)
     * @return la clave de la oferta
     */
    public String offerKey(String campaignId, String waveId, String customerNo, String accountNo) {
        return props.getOfferPrefix() + join(props.getKeySeparator(), campaignId, waveId, customerNo, accountNo, null);
    }

    /**
     * Arma el {@code RefID} del evento, igual que {@code KafkaSenderDashboard} en BW: si la cuenta **y** la tarjeta
     * tienen valor, {@code campaña_ola_cliente_cuenta_tarjeta}; en cualquier otro caso (solo cuenta, solo tarjeta o
     * ninguna) solo {@code campaña_ola_cliente}. Va sin prefijo y con guion bajo.
     *
     * @return el identificador de referencia del evento
     */
    public String refId(String campaignId, String waveId, String customerNo, String accountNo, String cardNumber) {
        boolean cuentaYTarjeta = hasText(accountNo) && hasText(cardNumber);
        return cuentaYTarjeta
                ? join("_", campaignId, waveId, customerNo, accountNo, cardNumber)
                : join("_", campaignId, waveId, customerNo, null, null);
    }

    private static boolean hasText(String s) {
        return s != null && !s.isBlank();
    }

    /**
     * Arma la clave de la ola con su canal ({@code D_WAVECHINFO.EXTID$}).
     *
     * @param waveId  ola de la oferta
     * @param channel canal de la ola
     * @return la clave de la ola
     */
    public String waveKey(String waveId, String channel) {
        return props.getWavePrefix() + waveId + props.getKeySeparator() + channel;
    }

    /** Campaña, ola y cliente siempre van; cuenta y tarjeta solo si traen valor. */
    private static String join(String sep, String campaignId, String waveId, String customerNo,
                               String accountNo, String cardNumber) {
        StringBuilder sb = new StringBuilder();
        sb.append(campaignId).append(sep).append(waveId).append(sep).append(customerNo);
        if (!isBlank(accountNo)) sb.append(sep).append(accountNo);
        if (!isBlank(cardNumber)) sb.append(sep).append(cardNumber);
        return sb.toString();
    }

    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
