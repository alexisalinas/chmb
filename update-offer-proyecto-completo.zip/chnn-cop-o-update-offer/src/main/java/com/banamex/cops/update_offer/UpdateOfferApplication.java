package com.banamex.cops.update_offer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Arranque del microservicio {@code chnn-cop-o-update-offer}.
 * <p>
 * Solo escanea {@code com.banamex.cops.update_offer}: las clases de la librería {@code chnn-cop-lib-operation-db}
 * (paquete {@code com.banamex.cops.app}) las registra {@code OfferFulfillmentConfig} con la conexión del
 * {@code spring.datasource}.
 */
@SpringBootApplication(scanBasePackages = "com.banamex.cops.update_offer")
public class UpdateOfferApplication {

    public static void main(String[] args) {
        SpringApplication.run(UpdateOfferApplication.class, args);
    }
}
