package com.banamex.cops.update_offer.kafka;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Paso 0: evento de entrada (lo que arma KafkaSenderDashboard en BW). */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OfferInput {

    // header
    private String uuid;             // viene del header HTTP uuid
    private String esbUuid;          // ESBUUID: un GUID que se genera por evento; va como "sid"
    private String channel;          // RequestingChannel
    private String transactionTime;

    // body
    private String refId;         // RefID del evento: CampañaOlaClienteCuentaTarjeta separados por _
    private String offerKey;      // D_OFFERPALETTE.EXTID$ para la consulta: off:mx:campaña:ola:cliente[:cuenta] (sin tarjeta)
    private String campaignId;
    private String waveId;
    private String customerNo;       // tal como llega, sin ceros
    private String accountNo;
    private String cardNumber;
    private String offerStatus;
    private String actionId;         // no se llena en ninguna capa de BW
    private String responseTime;
    private String responseCode;     // respuesta de la llamada al EMS
    private String responseText;
}
