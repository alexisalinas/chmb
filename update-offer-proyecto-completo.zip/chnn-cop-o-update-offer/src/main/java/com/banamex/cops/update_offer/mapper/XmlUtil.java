package com.banamex.cops.update_offer.mapper;

/** Utilidades para escribir XML a mano (equivale al render-xml / serialización de BW). */
public final class XmlUtil {

    private XmlUtil() { }

    /**
     * Escapa los caracteres especiales de XML para usar el texto dentro de un elemento.
     *
     * @param s texto original (si es nulo, devuelve cadena vacía)
     * @return el texto escapado
     */
    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    /** &lt;name&gt;value&lt;/name&gt;. Omite el elemento si value es null. */
    static void tag(StringBuilder x, String indent, String name, String value) {
        if (value == null) return;
        x.append(indent).append('<').append(name).append('>').append(esc(value))
                .append("</").append(name).append(">\n");
    }

    /** Igual que tag, pero null o vacío se escribe como &lt;name/&gt; (como lo hace el log de BW). */
    static void tagOrEmpty(StringBuilder x, String indent, String name, String value) {
        if (value == null || value.isEmpty()) {
            x.append(indent).append('<').append(name).append("/>\n");
        } else {
            tag(x, indent, name, value);
        }
    }
}
