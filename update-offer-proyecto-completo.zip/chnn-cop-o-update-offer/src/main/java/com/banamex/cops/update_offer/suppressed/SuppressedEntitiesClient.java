package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;

/**
 * Equivale a la actividad {@code GetListOfSuppressedEntities} del proceso de BW: entrega la lista de entidades suprimidas.
 * La implementación que se usa es {@link DbSuppressedEntitiesClient} (carga la lista de {@code COP_SUPP_CHNL} y
 * {@code COP_SUPP_OPR}, como {@code /BW/StartUp/startUpSuppression}).
 */
public interface SuppressedEntitiesClient {

    /**
     * Devuelve la lista de entidades suprimidas.
     *
     * @param params parámetros de la petición (país, canal y operación)
     * @return la lista de entidades suprimidas
     */
    SuppressedEntitiesListRoot getListOfSuppressedEntities(StartRequestParams params);
}
