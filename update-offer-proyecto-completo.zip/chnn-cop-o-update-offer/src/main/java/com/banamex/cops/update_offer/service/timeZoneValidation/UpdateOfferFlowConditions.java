package com.banamex.cops.update_offer.service.timeZoneValidation;

/**
 * Condiciones de las transiciones de {@code OpUpdateOffer} que dependen de la zona horaria.
 * Son funciones puras: no leen configuración ni la base de datos.
 */
public final class UpdateOfferFlowConditions {

    private UpdateOfferFlowConditions() {
    }

    /**
     * Condición de la transición hacia {@code RequestTimeZoneValidation}: la global {@code TranslateTimeZone}
     * vale {@code true}, sin distinguir mayúsculas.
     *
     * @param translateTimeZone valor de {@code TranslateTimeZone}
     * @return {@code true} solo si el valor es la palabra {@code true}
     */
    public static boolean translateTimeZone(String translateTimeZone) {
        return "true".equalsIgnoreCase(translateTimeZone);
    }

    /**
     * Condición de la transición hacia {@code PerformSuppressionCheck}: el código de la validación de zona horaria
     * termina en {@code 0} (éxito) o es {@code COP_TZCOD_114} (no hay zona configurada). Con cualquier otro código,
     * nulo o vacío, el flujo se detiene y se responde con el código de la validación.
     *
     * @param tzResponseCode {@code ResponseCode} de la validación de zona horaria
     * @return {@code true} si el flujo continúa hacia la supresión
     */
    public static boolean continueToSuppression(String tzResponseCode) {
        if (tzResponseCode == null || tzResponseCode.isEmpty()) {
            return false;
        }
        return tzResponseCode.endsWith("0") || "COP_TZCOD_114".equals(tzResponseCode);
    }
}
