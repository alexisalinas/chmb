package com.banamex.cops.update_offer.service.impl;

import com.banamex.cops.update_offer.audit.AuditLogService;
import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionList;
import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionResult;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailOutput;
import com.banamex.cops.update_offer.dto.suppression.StartRequest;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationResult;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationStartDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.ValueItemDTO;
import com.banamex.cops.update_offer.kafka.KafkaSenderDashboard;
import com.banamex.cops.update_offer.kafka.OfferInput;
import com.banamex.cops.update_offer.mapper.UpdateOfferMapper;
import com.banamex.cops.update_offer.sender.EmsSender;
import com.banamex.cops.update_offer.sender.FulFillkafkaSender;
import com.banamex.cops.update_offer.service.UpdateOfferResponseFactory;
import com.banamex.cops.update_offer.service.timeZoneValidation.TimeZoneValidationService;
import com.banamex.cops.update_offer.suppressed.PerformSuppressionCheckService;
import com.banamex.cops.update_offer.testutil.TestData;
import com.banamex.cops.update_offer.validation.DtoValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias de {@code UpdateOfferServiceImpl}.
 * <p>
 * Casos cubiertos: flujo normal; supresión; zona horaria; Kafka (FulFillKafkaSender); validación de los DTOs que arma el service.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UpdateOfferServiceImplTest {

    private static final java.util.Map<String, String> PROPIEDADES =
            java.util.Map.of("_nm_", "UpdateOffer", "CampaignID", "CAMP001");

    @Mock EmsSender emsSender;
    @Mock UpdateOfferMapper updateOfferMapper;
    @Mock AuditLogService auditLogService;
    @Mock PerformSuppressionCheckService suppressionCheckService;
    @Mock TimeZoneValidationService timeZoneValidationService;
    @Mock KafkaSenderDashboard kafkaSenderDashboard;
    @Mock FulFillkafkaSender fulFillkafkaSender;
    @Mock DtoValidator dtoValidator;
    @Mock UpdateOfferResponseFactory responses;
    @InjectMocks UpdateOfferServiceImpl service;

    private final UpdateOfferHeaders headers = TestData.headers();
    private UpdateOfferResponse emsResponse;     // lo que contesta el JMS (solo alimenta a Kafka)
    private UpdateOfferResponse exito;           // lo que responde el micro
    private final OfferInput kafkaInput = new OfferInput();

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(service, "translateTimeZone", false);
        ReflectionTestUtils.setField(service, "tzSysMode", "RealTime");

        emsResponse = new UpdateOfferResponse();
        emsResponse.setCode("000");
        emsResponse.setDescription("OK");

        exito = new UpdateOfferResponse();
        exito.setCode("COP_UPDOF_0");
        exito.setDescription("Successfully update offer 2026/11/11 10:00:00");
        when(responses.success(any(UpdateOfferRequest.class), any())).thenReturn(exito);
        when(responses.error(anyString(), any(Throwable.class))).thenAnswer(inv -> {
            UpdateOfferResponse r = new UpdateOfferResponse();
            r.setCode("ERROR");
            Throwable causa = inv.getArgument(1);
            r.setDescription(inv.getArgument(0) + ": " + causa.getMessage());
            return r;
        });

        when(updateOfferMapper.toEmsXml(any(), any(), any(), any(), any())).thenReturn("<ems/>");
        when(updateOfferMapper.toEmsProperties(any(), any(), any(), any(), any())).thenReturn(PROPIEDADES);
        when(emsSender.send(eq("<ems/>"), any())).thenReturn("<reply/>");
        when(updateOfferMapper.toRestResponse("<reply/>")).thenReturn(emsResponse);
        when(suppressionCheckService.perform(any())).thenReturn(sinSupresion());
        when(fulFillkafkaSender.isEnabled()).thenReturn(true);
        when(kafkaSenderDashboard.build(any(), any(), any(), any())).thenReturn(kafkaInput);
    }

    private FilteredSuppressionList sinSupresion() {
        FilteredSuppressionList l = new FilteredSuppressionList();
        l.setResults(List.of());
        return l;
    }

    private FilteredSuppressionList conSupresion(String indicator) {
        OperationDetailOutput d = new OperationDetailOutput();
        d.setIndicator(indicator);
        d.setResponseCode("COP_OPSUP_001");
        d.setResponseText("The UpdateOffer operation is temporarily unavailable");
        FilteredSuppressionResult r = new FilteredSuppressionResult();
        r.setOperationDetails(List.of(d));
        FilteredSuppressionList l = new FilteredSuppressionList();
        l.setResults(List.of(r));
        return l;
    }

    // ------------------------------------------------------------ flujo normal

    @Test
    void flujoNormal_enviaAlEmsYDevuelveLaRespuestaDeExitoQueArmaElMicro() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        List<UpdateOfferResponse> out = service.updateOffer(List.of(TestData.request()), headers);

        // Then
        assertThat(out).containsExactly(exito);
        verify(emsSender).send("<ems/>");
    }

    @Test
    void flujoNormal_escribeLogDeRequestAntesYLogDeResponseDespues() {
        // Given
        List<UpdateOfferRequest> requests = List.of(TestData.request());

        // When
        service.updateOffer(requests, headers);

        // Then
        InOrder o = inOrder(auditLogService, emsSender);
        o.verify(auditLogService).logRequest(headers, requests);           // lo que recibe el micro
        o.verify(emsSender).send("<ems/>");
        o.verify(auditLogService).logResponse(headers, List.of(exito));   // lo que responde el micro
    }

    @Test
    void conVariasOfertas_elLogDeRequestYDeResponseSeEscribeUnaSolaVezPorLlamada() {
        // Given
        List<UpdateOfferRequest> requests = List.of(TestData.request(), TestData.request());

        // When
        List<UpdateOfferResponse> out = service.updateOffer(requests, headers);

        // Then
        verify(auditLogService, org.mockito.Mockito.times(1)).logRequest(headers, requests);
        verify(auditLogService, org.mockito.Mockito.times(1)).logResponse(headers, out);
        assertThat(out).hasSize(2);
    }

    @Test
    void sinZonaHoraria_noLlamaALaValidacionYPasaNullAlMapper() {
        // Given
        UpdateOfferRequest rq = TestData.request();

        // When
        service.updateOffer(List.of(rq), headers);

        // Then
        verifyNoInteractions(timeZoneValidationService);
        verify(updateOfferMapper).toEmsXml(eq(rq), any(LocalDateTime.class), eq("client-123"), org.mockito.ArgumentMatchers.isNull(), org.mockito.ArgumentMatchers.isNull());
    }

    @Test
    void variasPeticiones_devuelveUnaRespuestaPorCada() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        List<UpdateOfferResponse> out = service.updateOffer(
                List.of(TestData.request(), TestData.request()), headers);

        // Then
        assertThat(out).hasSize(2);
        verify(emsSender, org.mockito.Mockito.times(2)).send("<ems/>");
    }

    // ------------------------------------------------------------ supresión

    @Test
    void operacionSuprimida_respondeSinLlamarAlEms() {
        // Given
        when(suppressionCheckService.perform(any())).thenReturn(conSupresion("true"));

        // When
        List<UpdateOfferResponse> out = service.updateOffer(List.of(TestData.request()), headers);

        // Then
        assertThat(out.get(0).getCode()).isEqualTo("COP_OPSUP_001");
        assertThat(out.get(0).getDescription()).contains("temporarily unavailable");
        verifyNoInteractions(emsSender);
        verify(auditLogService).logResponse(eq(headers), org.mockito.ArgumentMatchers.<List<UpdateOfferResponse>>argThat(
                l -> l.size() == 1 && "COP_OPSUP_001".equals(l.get(0).getCode())));
    }

    @Test
    void indicadorFalse_noSuprime() {
        // Given
        when(suppressionCheckService.perform(any())).thenReturn(conSupresion("false"));

        // When
        List<UpdateOfferResponse> out = service.updateOffer(List.of(TestData.request()), headers);

        // Then
        assertThat(out.get(0)).isSameAs(exito);
    }

    @Test
    void laSupresionSeConsultaConCanalPaisYNombreDeOperacion() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        service.updateOffer(List.of(TestData.request()), headers);

        // Then
        ArgumentCaptor<StartRequest> c = ArgumentCaptor.forClass(StartRequest.class);
        verify(suppressionCheckService).perform(c.capture());
        assertThat(c.getValue().getRequestParams().getRequestingChannel()).isEqualTo("CAT");
        assertThat(c.getValue().getRequestParams().getCountryCode()).isEqualTo("MX");
        assertThat(c.getValue().getRequestParams().getCurrentOperationName()).isEqualTo("UpdateOffer");
    }

    @Test
    void supresionNulaOSinResultados_noSuprime() {
        // Given
        when(suppressionCheckService.perform(any())).thenReturn(null);

        // When / Then
        assertThat(service.updateOffer(List.of(TestData.request()), headers).get(0)).isSameAs(exito);

        FilteredSuppressionList sinLista = new FilteredSuppressionList();
        sinLista.setResults(null);
        when(suppressionCheckService.perform(any())).thenReturn(sinLista);
        assertThat(service.updateOffer(List.of(TestData.request()), headers).get(0)).isSameAs(exito);
    }

    // ------------------------------------------------------------ zona horaria

    private TimeZoneValidationResult validacion(String code, String text) {
        TimeZoneValidationResult v = new TimeZoneValidationResult();
        v.setResponseCode(code);
        v.setResponseText(text);
        v.setMapResult(new MapRequestResultDTO());
        return v;
    }

    @Test
    void zonaHorariaInvalida_respondeConElCodigoDeLaValidacionYNoLlamaAlEms() {
        // Given
        ReflectionTestUtils.setField(service, "translateTimeZone", true);
        when(timeZoneValidationService.validate(any(TimeZoneValidationStartDTO.class)))
                .thenReturn(validacion("COP_TZCOD_115", "Invalid TimeZone"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        assertThat(out.getCode()).isEqualTo("COP_TZCOD_115");
        assertThat(out.getDescription()).isEqualTo("Invalid TimeZone");
        assertThat(out.getContextType()).isNullOrEmpty();               // ControlField va vacío en BW (todas las ramas)
        verifyNoInteractions(emsSender, suppressionCheckService);
    }

    @Test
    void zonaHorariaCorrecta_pasaCodigoYResultadoAlMapper() {
        // Given
        ReflectionTestUtils.setField(service, "translateTimeZone", true);
        TimeZoneValidationResult v = validacion("COP_TZCOD_000", "Success");
        when(timeZoneValidationService.validate(any(TimeZoneValidationStartDTO.class))).thenReturn(v);
        UpdateOfferRequest rq = TestData.request();

        // When
        service.updateOffer(List.of(rq), headers);

        // Then
        verify(updateOfferMapper).toEmsXml(eq(rq), any(LocalDateTime.class), eq("client-123"), eq("COP_TZCOD_000"), eq(v.getMapResult()));
    }

    @Test
    void zonaHorariaNoConfigurada114_continuaConElFlujo() {
        // Given
        ReflectionTestUtils.setField(service, "translateTimeZone", true);
        when(timeZoneValidationService.validate(any(TimeZoneValidationStartDTO.class)))
                .thenReturn(validacion("COP_TZCOD_114", "TimeZone not configured"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        assertThat(out).isSameAs(exito);
        verify(emsSender).send("<ems/>");
    }

    @Test
    void zonaHoraria_enviaElNodoStartConFechaYAmbasHorasConSusNombres() {
        // Given
        ReflectionTestUtils.setField(service, "translateTimeZone", true);
        when(timeZoneValidationService.validate(any(TimeZoneValidationStartDTO.class)))
                .thenReturn(validacion("COP_TZCOD_000", "Success"));

        // When
        service.updateOffer(List.of(TestData.request()), headers);

        // Then
        ArgumentCaptor<TimeZoneValidationStartDTO> c = ArgumentCaptor.forClass(TimeZoneValidationStartDTO.class);
        verify(timeZoneValidationService).validate(c.capture());
        TimeZoneValidationStartDTO start = c.getValue();

        assertThat(start.getSystem()).isEqualTo(headers.getChannelId());     // System = ChannelId del GetContext
        assertThat(start.getSysMode()).isEqualTo("RealTime");
        assertThat(start.getType()).isEqualTo("Request");
        assertThat(start.getDateTime()).isEmpty();
        assertThat(start.getDate()).extracting(ValueItemDTO::getName, ValueItemDTO::getValue)
                .containsExactly(org.assertj.core.groups.Tuple.tuple("AppointmentDate", "2026-10-25"));
        assertThat(start.getTime()).extracting(ValueItemDTO::getName, ValueItemDTO::getValue)
                .containsExactly(
                        org.assertj.core.groups.Tuple.tuple("AppointmentStartTime", "10:30:00"),
                        org.assertj.core.groups.Tuple.tuple("AppointmentEndTime", "11:00:00"));
        verify(dtoValidator).validateOrThrow(start);
    }

    @Test
    void zonaHoraria_sinFechaNiHorasEnviaListasVacias() {
        // Given
        ReflectionTestUtils.setField(service, "translateTimeZone", true);
        when(timeZoneValidationService.validate(any(TimeZoneValidationStartDTO.class)))
                .thenReturn(validacion("COP_TZCOD_000", "Success"));

        // When
        service.updateOffer(List.of(TestData.minimalRequest()), headers);

        // Then
        ArgumentCaptor<TimeZoneValidationStartDTO> c = ArgumentCaptor.forClass(TimeZoneValidationStartDTO.class);
        verify(timeZoneValidationService).validate(c.capture());
        assertThat(c.getValue().getDate()).isEmpty();
        assertThat(c.getValue().getTime()).isEmpty();
    }

    @Test
    void errorDelEms_devuelveRespuestaERRORYAunAsiEscribeElLogDeRespuesta() {
        // Given
        when(emsSender.send(eq("<ems/>"), any())).thenThrow(new RuntimeException("Timeout esperando respuesta del EMS"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        assertThat(out.getCode()).isEqualTo("ERROR");
        assertThat(out.getDescription()).contains("Timeout esperando respuesta del EMS");
        verify(auditLogService).logResponse(eq(headers), org.mockito.ArgumentMatchers.<List<UpdateOfferResponse>>argThat(
                l -> l.size() == 1 && "ERROR".equals(l.get(0).getCode())));
    }

    @Test
    void siNoSePuedeLeerLaRespuestaDelEms_noEsError_yKafkaSeLlamaSinLaRespuesta() {
        // Given
        UpdateOfferRequest rq = TestData.request();
        when(updateOfferMapper.toRestResponse("<reply/>")).thenThrow(new IllegalStateException("respuesta ilegible"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(rq), headers).get(0);

        // Then
        assertThat(out).isSameAs(exito);
        verify(kafkaSenderDashboard).build(eq(rq), eq(headers), any(LocalDateTime.class), isNull());
    }

    @Test
    void siElJmsNoContesta_esExito_yKafkaSeLlamaSinLaRespuesta() {
        // Given
        UpdateOfferRequest rq = TestData.request();
        when(emsSender.send(eq("<ems/>"), any())).thenReturn(null);

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(rq), headers).get(0);

        // Then
        assertThat(out).isSameAs(exito);
        verify(updateOfferMapper, never()).toRestResponse(any());
        verify(kafkaSenderDashboard).build(eq(rq), eq(headers), any(LocalDateTime.class), isNull());
    }

    @Test
    void siElEmsContestaUnErrorDeNegocio_elMicroRespondeExito_yKafkaRecibeElCodigoDelEms() {
        // Given
        UpdateOfferRequest rq = TestData.request();
        emsResponse.setCode("COP_UPDOF_1");
        emsResponse.setDescription("campaña no existe");

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(rq), headers).get(0);

        // Then
        assertThat(out).isSameAs(exito);                                   // la respuesta del JMS no arma la del micro
        verify(kafkaSenderDashboard).build(eq(rq), eq(headers), any(LocalDateTime.class), eq(emsResponse));
    }

    @Test
    void siFallaElEnvioAlEms_respondeErrorIndicandoElPaso() {
        // Given
        when(emsSender.send(eq("<ems/>"), any())).thenThrow(new RuntimeException("sin conexión"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        verify(responses).error(eq("Envío al EMS"), any(Throwable.class));
        assertThat(out.getCode()).isEqualTo("ERROR");
        assertThat(out.getDescription()).contains("Envío al EMS").contains("sin conexión");
    }

    @Test
    void siFallaElArmadoDelXml_respondeErrorIndicandoElPaso() {
        // Given
        when(updateOfferMapper.toEmsXml(any(), any(), any(), any(), any())).thenThrow(new IllegalStateException("campo inválido"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        verify(responses).error(eq("Armado del XML para el EMS"), any(Throwable.class));
        assertThat(out.getDescription()).contains("campo inválido");
        verifyNoInteractions(emsSender);
    }

    @Test
    void siFallaLaSupresion_respondeErrorIndicandoElPaso() {
        // Given
        when(suppressionCheckService.perform(any())).thenThrow(new IllegalStateException("sin lista"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        verify(responses).error(eq("Validación de supresión"), any(Throwable.class));
        assertThat(out.getDescription()).contains("sin lista");
        verifyNoInteractions(emsSender);
    }

    @Test
    void siFallaLaZonaHoraria_respondeErrorIndicandoElPaso() {
        // Given
        ReflectionTestUtils.setField(service, "translateTimeZone", true);
        when(timeZoneValidationService.validate(any(TimeZoneValidationStartDTO.class)))
                .thenThrow(new IllegalStateException("BD no disponible"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        verify(responses).error(eq("Validación de zona horaria"), any(Throwable.class));
        assertThat(out.getDescription()).contains("BD no disponible");
        verifyNoInteractions(emsSender);
    }

    @Test
    void unaPeticionConErrorNoImpideProcesarLasDemas() {
        // Given
        UpdateOfferRequest mala = TestData.request();
        mala.setCampaignId("MALA");
        when(updateOfferMapper.toEmsXml(eq(mala), any(), any(), any(), any())).thenThrow(new RuntimeException("fallo"));

        // When
        List<UpdateOfferResponse> out = service.updateOffer(List.of(mala, TestData.request()), headers);

        // Then
        assertThat(out.get(0).getCode()).isEqualTo("ERROR");
        assertThat(out.get(1)).isSameAs(exito);
    }

    // ------------------------------------------------------------ Kafka (FulFillKafkaSender)

    @Test
    void exitoDelEms_encolaElEnvioAKafkaConLaRespuestaDelEms() {
        // Given
        UpdateOfferRequest rq = TestData.request();

        // When
        service.updateOffer(List.of(rq), headers);

        // Then
        verify(kafkaSenderDashboard).build(eq(rq), eq(headers), any(LocalDateTime.class), eq(emsResponse));
        verify(fulFillkafkaSender).sendAsync(kafkaInput);
    }

    @Test
    void kafkaDeshabilitado_noArmaNiEncolaNada_peroEscribeElResultado() {
        // Given
        when(fulFillkafkaSender.isEnabled()).thenReturn(false);
        when(responses.kafkaDisabledText()).thenReturn("Kafka desactivado (offer.kafka.enabled = false): no se envió nada 2026/11/11 10:30:45");
        var appender = escucharElLog();

        // When
        try {
            service.updateOffer(List.of(TestData.request()), headers);
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        verifyNoInteractions(kafkaSenderDashboard);
        verify(fulFillkafkaSender, never()).sendAsync(any());
        assertThat(appender.list).anyMatch(e -> e.getFormattedMessage()
                .startsWith("[KAFKA] Resultado: Kafka desactivado"));          // se ve en el log por qué no hay Kafka
    }

    @Test
    void operacionSuprimida_noEnviaAKafka() {
        // Given
        when(suppressionCheckService.perform(any())).thenReturn(conSupresion("true"));

        // When
        service.updateOffer(List.of(TestData.request()), headers);

        // Then
        verify(fulFillkafkaSender, never()).sendAsync(any());
    }

    @Test
    void zonaHorariaInvalida_noEnviaAKafka() {
        // Given
        ReflectionTestUtils.setField(service, "translateTimeZone", true);
        when(timeZoneValidationService.validate(any(TimeZoneValidationStartDTO.class)))
                .thenReturn(validacion("COP_TZCOD_115", "Invalid TimeZone"));

        // When
        service.updateOffer(List.of(TestData.request()), headers);

        // Then
        verify(fulFillkafkaSender, never()).sendAsync(any());
    }

    @Test
    void errorDelEms_noEnviaAKafka() {
        // Given
        when(emsSender.send(eq("<ems/>"), any())).thenThrow(new RuntimeException("timeout"));

        // When
        service.updateOffer(List.of(TestData.request()), headers);

        // Then
        verify(fulFillkafkaSender, never()).sendAsync(any());
    }

    @Test
    void fallaAlEncolarEnKafka_noAfectaLaRespuesta() {
        // Given
        org.mockito.Mockito.doThrow(new RuntimeException("cola llena")).when(fulFillkafkaSender).sendAsync(any());

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        assertThat(out).isSameAs(exito);
    }

    @Test
    void fallaAlArmarElEventoDeKafka_noAfectaLaRespuesta() {
        // Given
        when(kafkaSenderDashboard.build(any(), any(), any(), any())).thenThrow(new IllegalStateException("sin datos"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        assertThat(out).isSameAs(exito);
        verify(auditLogService).logResponse(eq(headers), anyList());
    }

    // ------------------------------------------------------------ validación de los DTOs que arma el service

    @Test
    void startDeZonaHorariaInvalido_respondeERRORYNoLlamaALaValidacion() {
        // Given
        ReflectionTestUtils.setField(service, "translateTimeZone", true);
        org.mockito.Mockito.doThrow(new IllegalArgumentException("Datos inválidos en TimeZoneValidationStartDTO: system"))
                .when(dtoValidator).validateOrThrow(any(TimeZoneValidationStartDTO.class));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        assertThat(out.getCode()).isEqualTo("ERROR");
        assertThat(out.getDescription()).contains("TimeZoneValidationStartDTO");
        verifyNoInteractions(timeZoneValidationService, emsSender);
    }

    @Test
    void startDeSupresionInvalido_respondeERRORYNoLlamaAlEms() {
        // Given
        org.mockito.Mockito.doThrow(new IllegalArgumentException("Datos inválidos en StartRequest: requestParams.countryCode"))
                .when(dtoValidator).validateOrThrow(any(StartRequest.class));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        assertThat(out.getCode()).isEqualTo("ERROR");
        assertThat(out.getDescription()).contains("countryCode");
        verifyNoInteractions(suppressionCheckService, emsSender);
    }

    @Test
    void validaElStartDeSupresionAntesDeConsultar() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        service.updateOffer(List.of(TestData.request()), headers);

        // Then
        ArgumentCaptor<StartRequest> c = ArgumentCaptor.forClass(StartRequest.class);
        verify(dtoValidator).validateOrThrow(c.capture());
        assertThat(c.getValue().getRequestParams().getCountryCode()).isEqualTo("MX");
    }

    @Test
    void laMismaHoraDeLaPeticionSePasaAlXmlDelEmsYAlEventoDeKafka() {
        // Given
        UpdateOfferRequest rq = TestData.request();

        // When
        service.updateOffer(List.of(rq), headers);

        // Then
        ArgumentCaptor<LocalDateTime> alXml = ArgumentCaptor.forClass(LocalDateTime.class);
        ArgumentCaptor<LocalDateTime> aKafka = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(updateOfferMapper).toEmsXml(eq(rq), alXml.capture(), any(), any(), any());
        verify(kafkaSenderDashboard).build(eq(rq), eq(headers), aKafka.capture(), any());
        assertThat(alXml.getValue()).isNotNull().isEqualTo(aKafka.getValue());
    }

    @Test
    void updatedBy_salDelHeaderClientId() {
        // Given
        UpdateOfferRequest rq = TestData.request();

        // When
        service.updateOffer(List.of(rq), headers);

        // Then
        verify(updateOfferMapper).toEmsXml(eq(rq), any(LocalDateTime.class), eq("client-123"), any(), any());
    }

    @Test
    void sinHeaderClientId_updatedByVaNulo() {
        // Given
        UpdateOfferRequest rq = TestData.request();
        UpdateOfferHeaders sinClientId = TestData.headers();
        sinClientId.getAll().remove("client_id");

        // When
        service.updateOffer(List.of(rq), sinClientId);

        // Then
        verify(updateOfferMapper).toEmsXml(eq(rq), any(LocalDateTime.class), org.mockito.ArgumentMatchers.isNull(), any(), any());
    }

    // ------------------------------------------------------------ AbInitioTest

    private ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> escucharElLog() {
        ch.qos.logback.classic.Logger logger =
                (ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger(UpdateOfferServiceImpl.class);
        ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender =
                new ch.qos.logback.core.read.ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        return appender;
    }

    private void dejarDeEscucharElLog(ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender) {
        ((ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger(UpdateOfferServiceImpl.class)).detachAppender(appender);
    }

    @Test
    void abInitioTestEnN_noAvisaNadaYSiguePorElJms() {
        // Given
        ReflectionTestUtils.setField(service, "abInitioTest", "N");
        var appender = escucharElLog();

        // When
        UpdateOfferResponse out;
        try {
            out = service.updateOffer(List.of(TestData.request()), headers).get(0);
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(out).isSameAs(exito);
        verify(emsSender).send("<ems/>");
        assertThat(appender.list).noneMatch(e -> e.getFormattedMessage().contains("AbInitioTest"));
    }

    @Test
    void abInitioTestEnY_avisaQueElCaminoNoEstaMigrado_ySiguePorElJms() {
        // Given
        ReflectionTestUtils.setField(service, "abInitioTest", "Y");
        var appender = escucharElLog();

        // When
        UpdateOfferResponse out;
        try {
            out = service.updateOffer(List.of(TestData.request()), headers).get(0);
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(out).isSameAs(exito);
        verify(emsSender).send("<ems/>");
        assertThat(appender.list).anyMatch(e -> e.getLevel() == ch.qos.logback.classic.Level.WARN
                && e.getFormattedMessage().contains("AbInitioTest = Y")
                && e.getFormattedMessage().contains("uuid-1"));
    }

    @Test
    void abInitioTest_comparaIgualQueBw_soloLaYMayusculaCuenta() {
        // Given
        ReflectionTestUtils.setField(service, "abInitioTest", "y");
        var appender = escucharElLog();

        // When
        try {
            service.updateOffer(List.of(TestData.request()), headers);
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list).noneMatch(e -> e.getFormattedMessage().contains("AbInitioTest"));
    }

    @Test
    void laRespuestaDeExitoSePideConLaOfertaQueSeProceso() {
        // Given
        UpdateOfferRequest rq = TestData.request();

        // When
        service.updateOffer(List.of(rq), headers);

        // Then
        verify(responses).success(eq(rq), any());      // el caso OfferStatus U y el origen (micro o ems) los decide la fábrica
    }

    // ------------------------------------------------------------ propiedades del mensaje al EMS (OtherProperties)

    @Test
    void alEms_vaElXmlYLasPropiedadesDelMensaje() {
        // Given
        UpdateOfferRequest rq = TestData.request();

        // When
        service.updateOffer(List.of(rq), headers);

        // Then
        verify(emsSender).send("<ems/>", PROPIEDADES);
        verify(updateOfferMapper).toEmsProperties(eq(rq), any(LocalDateTime.class), eq("client-123"), any(), any());
    }

    @Test
    void siFallaElArmadoDeLasPropiedades_respondeErrorIndicandoElPaso_yNoEnviaAlEms() {
        // Given
        when(updateOfferMapper.toEmsProperties(any(), any(), any(), any(), any()))
                .thenThrow(new IllegalStateException("campo inválido"));

        // When
        UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

        // Then
        verify(responses).error(eq("Armado de las propiedades del mensaje"), any(Throwable.class));
        assertThat(out.getDescription()).contains("campo inválido");
        verifyNoInteractions(emsSender);
    }

    @Test
    void laRespuestaDelEmsSePasaALaFabrica_paraQuePuedaDevolverlaSiSeConfiguraAsi() {
        // Given
        UpdateOfferRequest rq = TestData.request();

        // When
        service.updateOffer(List.of(rq), headers);

        // Then
        verify(responses).success(rq, emsResponse);
    }
}
