package com.banamex.cops.update_offer.sender;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.update_offer.kafka.KafkaMetrics;
import com.banamex.cops.update_offer.service.UpdateOfferResponseFactory;
import com.banamex.cops.update_offer.config.UpdateOfferResponseProperties;
import com.banamex.cops.update_offer.kafka.OfferDataClient;
import com.banamex.cops.update_offer.kafka.OfferInput;
import com.banamex.cops.update_offer.kafka.OfferKafkaProps;
import com.banamex.cops.update_offer.kafka.OfferKeyBuilder;
import com.banamex.cops.update_offer.kafka.OfferPublisher;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.slf4j.LoggerFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.core.task.TaskExecutor;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.test.util.ReflectionTestUtils;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias de {@code FulFillkafkaSender}.
 * <p>
 * Casos cubiertos: flujo completo; header (igual al ejemplo); body (igual al ejemplo); reglas de formato; descartes (no es una falla); reintentos y fallas; asíncrono; logs: lo que recibe y lo que envía.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class FulFillkafkaSenderTest {

    private static final String WAVE_KEY = "wvch:W1:CAT";
    private static final String OFFER_KEY = "off:mx:C1:W1:123:ACC:1234567812345678";
    private static final String REF_ID = "C1_W1_123_ACC_1234567812345678";
    private static final String OFFSET_MS = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}([+-]\\d{2}:\\d{2}|Z)";
    private static final String OFFSET_S = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}([+-]\\d{2}:\\d{2}|Z)";
    private static final Timestamp START = Timestamp.valueOf("2026-10-25 10:30:00");
    private static final Timestamp EXPIRY = Timestamp.valueOf("2026-12-31 00:00:00");
    private static final Timestamp CREATED = Timestamp.valueOf("2026-10-27 17:53:02");

    @Mock OfferDataClient dataClient;
    @Mock OfferPublisher publisher;
    @Mock TaskExecutor executor;

    private final JsonMapper mapper = JsonMapper.builder().build();
    private OfferKafkaProps props;
    private KafkaMetrics metrics;
    private FulFillkafkaSender sender;
    private ListAppender<ILoggingEvent> appender;
    private Logger logger;

    @BeforeEach
    void setUp() throws Exception {
        props = new OfferKafkaProps();
        props.setDelayMs(0);
        props.setMaxAttempts(2);
        props.setRetryBackoffMs(0);
        metrics = new KafkaMetrics();
        UpdateOfferResponseFactory responses = new UpdateOfferResponseFactory(new UpdateOfferResponseProperties());
        ReflectionTestUtils.setField(responses, "clock", Clock.fixed(Instant.parse("2026-11-11T16:30:45Z"), ZoneOffset.UTC));
        sender = new FulFillkafkaSender(props, new OfferKeyBuilder(props), dataClient, publisher, mapper, metrics, executor, responses);

        when(dataClient.find(eq(WAVE_KEY), eq(OFFER_KEY))).thenReturn(Optional.of(dbRow()));
        when(publisher.publish(anyString(), anyString())).thenReturn("id-1");

        logger = (Logger) LoggerFactory.getLogger(FulFillkafkaSender.class);
        appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
    }

    @AfterEach
    void tearDown() {
        logger.detachAppender(appender);
    }

    private List<String> mensajes() {
        return appender.list.stream().map(ILoggingEvent::getFormattedMessage).toList();
    }

    private OfferInput input() {
        return OfferInput.builder()
                .uuid("uuid-1").esbUuid("esb-1").channel("CAT")
                .transactionTime("2026-10-26T10:00:00.123")
                .refId(REF_ID).offerKey(OFFER_KEY)
                .campaignId("C1").waveId("W1").customerNo("123").accountNo("ACC")
                .cardNumber("1234567812345678").offerStatus("H")
                .actionId("PROCESSCALL_ON_AUTHENTICATION_SUCCESS_FULFILLMENT")
                .responseTime("2026-10-26T10:00:01.456-06:00")
                .responseCode("COP_UPDOF_0").responseText("Successfully update offer " + OFFER_KEY)
                .build();
    }

    private CopOfferFulfillment dbRow() {
        List<String> userFields = new ArrayList<>();
        for (int i = 1; i <= 100; i++) userFields.add(null);
        userFields.set(0, "ORO BANAMEX");     // USERFIELD_1
        userFields.set(4, "15000");           // USERFIELD_5
        return new CopOfferFulfillment("CAT1", "T", "R1", "motivo", "DISPONIBLE SPEI", "PDSPPEI", userFields,
                START, Timestamp.valueOf("2026-10-25 11:00:00"), EXPIRY, CREATED, "DISPONIBLE_SPEI", "F1", "0");
    }

    private String publicadoRaw() throws Exception {
        ArgumentCaptor<String> json = ArgumentCaptor.forClass(String.class);
        verify(publisher).publish(eq(REF_ID), json.capture());
        return json.getValue();
    }

    private JsonNode publicado() throws Exception {
        return mapper.readTree(publicadoRaw());
    }

    private static void enOrden(String raw, String... claves) {
        int anterior = -1;
        for (String k : claves) {
            int i = raw.indexOf("\"" + k + "\"");
            assertThat(i).as("falta " + k).isGreaterThanOrEqualTo(0);
            assertThat(i).as(k + " fuera de orden").isGreaterThan(anterior);
            anterior = i;
        }
    }

    // ------------------------------------------------------------ flujo completo

    @Test
    void flujoCompleto_consultaPorLaClaveDeLaOfertaYPublica() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        verify(dataClient).find(WAVE_KEY, OFFER_KEY);
        assertThat(publicado().has("event")).isTrue();
        assertThat(metrics.getSent()).isEqualTo(1);
    }

    // ------------------------------------------------------------ header (igual al ejemplo)

    @Test
    void header_llevaLosDatosYLasConstantesDelEjemplo() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        JsonNode h = publicado().get("event").get("header");

        assertThat(h.get("name").asText()).isEqualTo("Updateofferrequest");
        assertThat(h.get("version").asText()).isEqualTo("1.0");
        assertThat(h.get("producerCSI").asText()).isEqualTo("163621");
        assertThat(h.get("Channel").asText()).isEqualTo("CAT");
        assertThat(h.get("countryCode").asText()).isEqualTo("MX");
        assertThat(h.get("businessCode").asText()).isEqualTo("DM");
        assertThat(h.get("UUID").asText()).isEqualTo("uuid-1");
        assertThat(h.get("transactionTime").asText()).isEqualTo("2026-10-26T10:00:00.123");
    }

    @Test
    void sid_esElEsbUuidGenerado_noElUuidDelHeader() throws Exception {
        // Given
        // (sin precondiciones propias: input() trae uuid-1 y esbUuid esb-1)

        // When
        sender.process(input());

        // Then
        JsonNode h = publicado().get("event").get("header");
        assertThat(h.get("sid").asText()).isEqualTo("esb-1");
        assertThat(h.get("UUID").asText()).isEqualTo("uuid-1");
    }

    @Test
    void sid_sinEsbUuid_usaElUuid() throws Exception {
        // Given
        OfferInput in = input();
        in.setEsbUuid(null);

        // When
        sender.process(in);

        // Then
        assertThat(publicado().get("event").get("header").get("sid").asText()).isEqualTo("uuid-1");
    }

    @Test
    void header_mismoOrdenQueElEjemplo() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        enOrden(publicadoRaw(), "name", "version", "producerCSI", "Channel", "countryCode", "businessCode",
                "UUID", "sid", "transactionTime", "timeStamp");
    }

    @Test
    void timeStamp_esLaHoraActualConMilisegundosYOffset() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        assertThat(publicado().get("event").get("header").get("timeStamp").asText()).matches(OFFSET_MS);
    }

    @Test
    void timeStamp_usaLaZonaEcrmConfigurada() throws Exception {
        // Given
        org.springframework.test.util.ReflectionTestUtils.setField(sender, "ecrmTimeZone", "Pacific/Honolulu");   // -10:00 todo el año

        // When
        sender.process(input());

        // Then
        assertThat(publicado().get("event").get("header").get("timeStamp").asText()).endsWith("-10:00");
    }

    @Test
    void timeStamp_porDefectoUsaUsCentral() throws Exception {
        // Given
        // (sin precondiciones: la zona por defecto es la de las globales)

        // When
        sender.process(input());

        // Then
        assertThat(publicado().get("event").get("header").get("timeStamp").asText()).matches(".*(-05:00|-06:00)$");
    }

    @Test
    void transactionTimeVacio_seLlenaConLaHoraActualSinOffset() throws Exception {
        // Given
        OfferInput in = input();
        in.setTransactionTime("");

        // When
        sender.process(in);

        // Then
        assertThat(publicado().get("event").get("header").get("transactionTime").asText())
                .matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}");
    }

    // ------------------------------------------------------------ body (igual al ejemplo)

    @Test
    void body_llevaLosDatosDeLaEntradaYDeLaBD() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        JsonNode b = publicado().get("event").get("body");

        assertThat(b.get("RefID").asText()).isEqualTo(REF_ID);
        assertThat(b.get("CampaignID").asText()).isEqualTo("C1");
        assertThat(b.get("WaveID").asText()).isEqualTo("W1");
        assertThat(b.get("AccountNo").asText()).isEqualTo("ACC");
        assertThat(b.get("CardNumber").asText()).isEqualTo("1234567812345678");
        assertThat(b.get("OfferStatus").asText()).isEqualTo("H");
        assertThat(b.get("Action_ID").asText()).isEqualTo("PROCESSCALL_ON_AUTHENTICATION_SUCCESS_FULFILLMENT");
        assertThat(b.get("ResponseTime").asText()).isEqualTo("2026-10-26T10:00:01.456-06:00");
        assertThat(b.get("ResponseCode").asText()).isEqualTo("COP_UPDOF_0");
        assertThat(b.get("ResponseText").asText()).isEqualTo("Successfully update offer " + OFFER_KEY);

        assertThat(b.get("Product_Description").asText()).isEqualTo("DISPONIBLE SPEI");
        assertThat(b.get("FulfillmentID").asText()).isEqualTo("PDSPPEI");
        assertThat(b.get("PrdCode").asText()).isEqualTo("DISPONIBLE_SPEI");
        assertThat(b.get("Availability").asText()).isEqualTo("0");
    }

    @Test
    void body_mismoOrdenQueElEjemplo() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        enOrden(publicadoRaw(), "RefID", "CampaignID", "WaveID", "CustomerNo", "AccountNo", "CardNumber", "OfferStatus",
                "ID_ProductType", "CRP_Category_ID", "Product_Description", "Reason_Code", "Reason_Description",
                "Action_ID", "ResponseTime", "ResponseCode", "ResponseText", "FulfillmentID",
                "UserField1", "UserField5", "AppointmentDate", "AppointmentMinDur",
                "OfferExpiryDate", "OfferStartDate", "PrdCode", "PrdFamily", "Availability");
    }

    @Test
    void body_lasFechasDeLaBDSalenConOffsetYSinFracciones() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        JsonNode b = publicado().get("event").get("body");

        assertThat(b.get("OfferExpiryDate").asText()).matches(OFFSET_S).startsWith("2026-12-31T00:00:00");
        assertThat(b.get("OfferStartDate").asText()).matches(OFFSET_S).startsWith("2026-10-27T17:53:02");
    }

    @Test
    void body_llevaLosCamposDelEsquemaQueLlenaLaBD() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        JsonNode b = publicado().get("event").get("body");
        assertThat(b.get("ID_ProductType").asText()).isEqualTo("T");                 // PRDTYPE
        assertThat(b.get("CRP_Category_ID").asText()).isEqualTo("CAT1");             // CRPCATEGORYID
        assertThat(b.get("Reason_Code").asText()).isEqualTo("R1");                   // REASONCODE
        assertThat(b.get("Reason_Description").asText()).isEqualTo("motivo");        // REASONDESC
        assertThat(b.get("PrdFamily").asText()).isEqualTo("F1");                     // PRDFAMILY
        assertThat(b.get("AppointmentDate").asText()).matches(OFFSET_S).startsWith("2026-10-25T10:30:00");
    }

    @Test
    void appointmentMinDur_esLaDuracionDeLaCitaEnMinutos() throws Exception {
        // Given
        // (sin precondiciones propias: la cita de prueba va de 10:30 a 11:00)

        // When
        sender.process(input());

        // Then
        assertThat(publicado().get("event").get("body").get("AppointmentMinDur").asLong()).isEqualTo(30L);
    }

    @Test
    void appointmentMinutes_seOmiteSiFaltaUnaFechaOSiNoEsMayorQueCero() {
        // Given
        Timestamp inicio = Timestamp.valueOf("2026-10-25 10:30:00");

        // When / Then
        assertThat(FulFillkafkaSender.appointmentMinutes(inicio, Timestamp.valueOf("2026-10-25 11:00:00"))).isEqualTo(30L);
        assertThat(FulFillkafkaSender.appointmentMinutes(inicio, Timestamp.valueOf("2026-10-25 10:30:20"))).isNull();   // 20 s -> 0
        assertThat(FulFillkafkaSender.appointmentMinutes(inicio, inicio)).isNull();
        assertThat(FulFillkafkaSender.appointmentMinutes(inicio, Timestamp.valueOf("2026-10-25 10:00:00"))).isNull();   // negativo
        assertThat(FulFillkafkaSender.appointmentMinutes(null, inicio)).isNull();
        assertThat(FulFillkafkaSender.appointmentMinutes(inicio, null)).isNull();
    }

    @Test
    void body_noLlevaCamposConNombresQueNoSonDelEsquema() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        JsonNode b = publicado().get("event").get("body");
        for (String campo : List.of("ReasonCode", "ReasonDesc", "ProductType", "ProductFamily", "CategoryID",
                "AppointmentStartDate", "ProductCode", "ExpiryDate", "OfferCreationDate",
                "FulfillmentProcID", "ProductDescription")) {
            assertThat(b.has(campo)).as(campo).isFalse();
        }
    }

    @Test
    void siLaCitaNoTieneFechas_noSeEnvianAppointmentDateNiAppointmentMinDur() throws Exception {
        // Given
        CopOfferFulfillment sinCita = new CopOfferFulfillment("CAT1", "T", "R1", "motivo", "DISPONIBLE SPEI", "PDSPPEI",
                dbRow().userFields(), null, null, EXPIRY, CREATED, "DISPONIBLE_SPEI", "F1", "0");
        when(dataClient.find(eq(WAVE_KEY), eq(OFFER_KEY))).thenReturn(Optional.of(sinCita));

        // When
        sender.process(input());

        // Then
        JsonNode b = publicado().get("event").get("body");
        assertThat(b.has("AppointmentDate")).isFalse();
        assertThat(b.has("AppointmentMinDur")).isFalse();
    }

    @Test
    void actionId_seOmiteSiElRequestNoTraeOfferAction() throws Exception {
        // Given
        OfferInput in = input();
        in.setActionId(null);

        // When
        sender.process(in);

        // Then
        assertThat(publicado().get("event").get("body").has("Action_ID")).isFalse();
    }

    @Test
    void userFields_vienenDeLaBDYLosNulosSeOmiten() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        JsonNode b = publicado().get("event").get("body");

        assertThat(b.get("UserField1").asText()).isEqualTo("ORO BANAMEX");
        assertThat(b.get("UserField5").asText()).isEqualTo("15000");
        assertThat(b.has("UserField2")).isFalse();     // como UserField7 en el ejemplo
        assertThat(b.has("UserField100")).isFalse();
    }

    // ------------------------------------------------------------ reglas de formato

    @Test
    void customerNo_seRellenaConCerosA9DespuesDeLaConsulta() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        assertThat(publicado().get("event").get("body").get("CustomerNo").asText()).isEqualTo("000000123");
        verify(dataClient).find(WAVE_KEY, OFFER_KEY);        // la clave usó el valor SIN ceros
    }

    @Test
    void customerNoDe9OMasDigitos_noSeModifica() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(FulFillkafkaSender.padLeft("067799015", 9)).isEqualTo("067799015");
        assertThat(FulFillkafkaSender.padLeft("1234567890", 9)).isEqualTo("1234567890");
        assertThat(FulFillkafkaSender.padLeft(null, 9)).isNull();
    }

    @Test
    void maskCardNumber_dejaSoloLosUltimosCuatroDigitos() throws Exception {
        // Given
        props.setMaskCardNumber(true);

        // When
        sender.process(input());

        // Then
        assertThat(publicado().get("event").get("body").get("CardNumber").asText()).isEqualTo("************5678");
    }

    @Test
    void sinMascara_laTarjetaVaCompletaComoEnElEjemplo() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        assertThat(publicado().get("event").get("body").get("CardNumber").asText()).isEqualTo("1234567812345678");
    }

    @Test
    void mask_casosBorde() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(FulFillkafkaSender.mask("1234")).isEqualTo("1234");
        assertThat(FulFillkafkaSender.mask(null)).isNull();
        assertThat(FulFillkafkaSender.mask("123456")).isEqualTo("**3456");
    }

    @Test
    void iso_convierteTimestampASegundosConOffset() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(FulFillkafkaSender.iso(START)).matches(OFFSET_S).startsWith("2026-10-25T10:30:00");
        assertThat(FulFillkafkaSender.iso("2026-01-01")).isEqualTo("2026-01-01");
        assertThat(FulFillkafkaSender.iso(null)).isNull();
    }

    @Test
    void omitNullsFalso_losNulosSeEscribenComoNull() throws Exception {
        // Given
        props.setOmitNulls(false);
        OfferInput in = input();
        in.setActionId(null);

        // When
        sender.process(in);

        // Then
        JsonNode b = publicado().get("event").get("body");
        assertThat(b.has("Action_ID")).isTrue();
        assertThat(b.get("Action_ID").isNull()).isTrue();
        assertThat(b.has("UserField2")).isTrue();
    }

    // ------------------------------------------------------------ descartes (no es una falla)

    @Test
    void sinFilasEnLaBD_descartaYNoPublica() throws Exception {
        // Given
        when(dataClient.find(eq(WAVE_KEY), eq(OFFER_KEY))).thenReturn(Optional.empty());

        // When
        sender.process(input());

        // Then
        verifyNoInteractions(publisher);
        assertThat(metrics.getNoRows()).isEqualTo(1);
        assertThat(metrics.getFailed()).isZero();
        verify(dataClient, times(1)).find(eq(WAVE_KEY), eq(OFFER_KEY));   // sin filas NO se reintenta
    }

    @Test
    void camposObligatoriosFaltantes_descartaSinConsultarLaBD() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        for (String campo : new String[]{"refId", "offerKey", "campaignId", "waveId", "customerNo", "offerStatus"}) {
            OfferInput in = input();
            switch (campo) {
                case "refId" -> in.setRefId(null);
                case "offerKey" -> in.setOfferKey("");
                case "campaignId" -> in.setCampaignId("");
                case "waveId" -> in.setWaveId(" ");
                case "customerNo" -> in.setCustomerNo(null);
                default -> in.setOfferStatus("");
            }
            sender.process(in);
        }

        // Then
        verifyNoInteractions(dataClient, publisher);
        assertThat(metrics.getInvalid()).isEqualTo(6);
    }

    // ------------------------------------------------------------ reintentos y fallas

    @Test
    void fallaDeInfraestructuraEnLaBD_seReintentaYSiPersisteSeCuentaComoFallida() throws Exception {
        // Given
        when(dataClient.find(eq(WAVE_KEY), eq(OFFER_KEY))).thenThrow(new RuntimeException("db caída"));

        // When
        sender.process(input());

        // Then
        verify(dataClient, times(2)).find(eq(WAVE_KEY), eq(OFFER_KEY));
        verifyNoInteractions(publisher);
        assertThat(metrics.getFailed()).isEqualTo(1);
        assertThat(metrics.getSent()).isZero();
    }

    @Test
    void siElSegundoIntentoFunciona_publica() throws Exception {
        // Given
        when(dataClient.find(eq(WAVE_KEY), eq(OFFER_KEY)))
                .thenThrow(new RuntimeException("timeout"))
                .thenReturn(Optional.of(dbRow()));

        // When
        sender.process(input());

        // Then
        verify(dataClient, times(2)).find(eq(WAVE_KEY), eq(OFFER_KEY));
        verify(publisher).publish(anyString(), anyString());
        assertThat(metrics.getSent()).isEqualTo(1);
        assertThat(metrics.getFailed()).isZero();
    }

    @Test
    void fallaAlPublicar_seReintentaYSeCuentaComoFallida() throws Exception {
        // Given
        when(publisher.publish(anyString(), anyString())).thenThrow(new RuntimeException("cola caída"));

        // When
        sender.process(input());

        // Then
        verify(publisher, times(2)).publish(anyString(), anyString());
        assertThat(metrics.getFailed()).isEqualTo(1);
        assertThat(metrics.getSent()).isZero();
    }

    @Test
    void processNuncaLanzaExcepcion() {
        // Given
        when(dataClient.find(anyString(), anyString())).thenThrow(new IllegalStateException("inesperado"));

        // Then

        // When
        sender.process(input());     // no debe propagar
        assertThat(metrics.getFailed()).isEqualTo(1);
    }

    // ------------------------------------------------------------ asíncrono

    @Test
    void sendAsync_encolaElTrabajoEnElEjecutorYAlCorrerloSePublica() throws Exception {
        // Given
        doAnswer(inv -> {
            ((Runnable) inv.getArgument(0)).run();
            return null;
        }).when(executor).execute(any(Runnable.class));

        // When
        sender.sendAsync(input());

        // Then
        verify(executor).execute(any(Runnable.class));
        verify(publisher).publish(anyString(), anyString());
    }

    @Test
    void sendAsync_noEjecutaNadaEnElHiloLlamador() throws Exception {

        // Then
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.sendAsync(input());      // el ejecutor es un mock: no corre la tarea

        verify(executor).execute(any(Runnable.class));
        verify(publisher, never()).publish(anyString(), anyString());
    }

    @Test
    void sendAsync_conColaLlena_cuentaElRechazoYNoLanzaExcepcion() {
        // Given
        doThrow(new TaskRejectedException("cola llena")).when(executor).execute(any(Runnable.class));

        // When
        sender.sendAsync(input());

        // Then
        assertThat(metrics.getRejected()).isEqualTo(1);
    }

    @Test
    void isEnabled_reflejaLaConfiguracion() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(sender.isEnabled()).isFalse();
        props.setEnabled(true);
        assertThat(sender.isEnabled()).isTrue();
    }

    // ------------------------------------------------------------ Kafka va después del JMS y necesita sus dos valores

    @Test
    void sinResponseCodeDelJms_noConsultaNiPublica_yDiceQueFalloLaRespuestaDelJms() throws Exception {
        // Given
        OfferInput in = input();
        in.setResponseCode(null);

        // When
        sender.process(in);

        // Then
        verifyNoInteractions(dataClient);
        verify(publisher, never()).publish(anyString(), anyString());
        assertThat(mensajes().stream().filter(m -> m.startsWith("[KAFKA] Resultado:")).findFirst().orElseThrow())
                .contains("Falló en Respuesta del JMS").contains("ResponseCode y ResponseText");
        assertThat(indexStarting(mensajes(), "KAFKA-NO-JMS-RESPONSE")).isGreaterThanOrEqualTo(0);
    }

    @Test
    void sinResponseTextDelJms_tampocoSeEnvia() throws Exception {
        // Given
        OfferInput in = input();
        in.setResponseText("");

        // When
        sender.process(in);

        // Then
        verifyNoInteractions(dataClient);
        verify(publisher, never()).publish(anyString(), anyString());
    }

    @Test
    void conResponseCodeSoloConEspacios_cuentaComoSinRespuesta() throws Exception {
        // Given
        OfferInput in = input();
        in.setResponseCode("   ");

        // When
        sender.process(in);

        // Then
        verify(publisher, never()).publish(anyString(), anyString());
    }

    @Test
    void conLosDosValoresDelJms_consultaYPublica() throws Exception {
        // Given
        // (sin precondiciones propias: input() trae COP_UPDOF_0 y su texto)

        // When
        sender.process(input());

        // Then
        verify(dataClient).find(eq(WAVE_KEY), eq(OFFER_KEY));
        verify(publisher).publish(eq(REF_ID), anyString());
    }

    // ------------------------------------------------------------ log: resultado del envío a Kafka

    private String resultado() {
        return mensajes().stream().filter(m -> m.startsWith("[KAFKA] Resultado:")).findFirst().orElseThrow();
    }

    @Test
    void resultado_siSePublico_dicePublicadoConLaFechaDeLaZonaEcrm() {
        // Given
        props.setMode("jms");

        // When
        sender.process(input());

        // Then
        assertThat(resultado()).isEqualTo("[KAFKA] Resultado: Successfully send offer to Kafka 2026/11/11 10:30:45");
    }

    @Test
    void resultado_enDryRun_diceQueNoSePublico() {
        // Given
        props.setMode("dry-run");

        // When
        sender.process(input());

        // Then
        assertThat(resultado()).isEqualTo("[KAFKA] Resultado: Kafka en dry-run: el mensaje no se publicó 2026/11/11 10:30:45");
    }

    @Test
    void resultado_sinFilasEnLaBD_diceEnQuePasoFalloYLasClavesBuscadas() {
        // Given
        when(dataClient.find(eq(WAVE_KEY), eq(OFFER_KEY))).thenReturn(Optional.empty());

        // When
        sender.process(input());

        // Then
        assertThat(resultado()).startsWith("[KAFKA] Resultado: Error send offer to Kafka 2026/11/11 10:30:45. Falló en Consulta a la base de datos:")
                .contains("no se encontró la oferta").contains("waveKey=" + WAVE_KEY).contains("offerKey=" + OFFER_KEY);
        verify(publisher, never()).publish(anyString(), anyString());
    }

    @Test
    void resultado_siFallaLaConsulta_diceElPasoYLaCausa() throws Exception {
        // Given
        when(dataClient.find(eq(WAVE_KEY), eq(OFFER_KEY))).thenThrow(new IllegalStateException("ORA-00904"));

        // When
        sender.process(input());

        // Then
        assertThat(resultado()).contains("Falló en Consulta a la base de datos: ORA-00904");
    }

    @Test
    void resultado_siFallaLaPublicacion_diceElPasoYLaCausa() throws Exception {
        // Given
        when(publisher.publish(anyString(), anyString())).thenThrow(new IllegalStateException("sin conexión al broker"));

        // When
        sender.process(input());

        // Then
        assertThat(resultado()).contains("Error send offer to Kafka 2026/11/11 10:30:45")
                .contains("Falló en Publicación en la cola de Kafka: sin conexión al broker");
    }

    @Test
    void resultado_conEntradaInvalida_diceQueFaltanCampos() {
        // Given
        OfferInput in = input();
        in.setOfferStatus("");

        // When
        sender.process(in);

        // Then
        assertThat(resultado()).contains("Falló en Validación del evento").contains("faltan campos obligatorios");
    }

    @Test
    void resultado_conColaLlena_diceQueNoSeEnvio() {
        // Given
        doThrow(new TaskRejectedException("cola llena")).when(executor).execute(any(Runnable.class));

        // When
        sender.sendAsync(input());

        // Then
        assertThat(resultado()).contains("Falló en Cola de envío llena");
    }

    @Test
    void resultado_siSeInterrumpe_diceQueSeInterrumpio() {
        // Given
        props.setDelayMs(1);
        Thread.currentThread().interrupt();

        // When
        try {
            sender.process(input());
        } finally {
            Thread.interrupted();            // limpia la marca para no afectar otras pruebas
        }

        // Then
        assertThat(resultado()).contains("Falló en Espera previa a la consulta").contains("interrumpió");
    }

    @Test
    void resultado_seEscribeUnaSolaVezPorEnvio() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        assertThat(mensajes().stream().filter(m -> m.startsWith("[KAFKA] Resultado:")).count()).isEqualTo(1);
    }

    // ------------------------------------------------------------ logs: solo lo que se le va a enviar a Kafka

    @Test
    void registraElMensajeQueSeLeVaAEnviar_conLaTarjetaEnmascarada() throws Exception {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        String envia = mensajes().stream().filter(m -> m.startsWith("[KAFKA] Envía:")).findFirst().orElseThrow();
        assertThat(envia).contains("\"name\":\"Updateofferrequest\"", "\"RefID\":\"" + REF_ID + "\"");
        assertThat(envia).contains("\"CardNumber\":\"************5678\"").doesNotContain("1234567812345678");
        assertThat(publicadoRaw()).contains("\"CardNumber\":\"1234567812345678\"");   // lo publicado sí va completo
    }

    @Test
    void noRegistraLoQueRecibe_soloLoQueSeVaAEnviar() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        assertThat(indexStarting(mensajes(), "[KAFKA] Recibe:")).isEqualTo(-1);
        assertThat(indexStarting(mensajes(), "[KAFKA] Envía:")).isGreaterThanOrEqualTo(0);
    }

    @Test
    void conEntradaInvalida_noEnviaYRegistraElError() {
        // Given
        OfferInput in = input();
        in.setOfferStatus("");

        // When
        sender.process(in);

        // Then
        assertThat(indexStarting(mensajes(), "[KAFKA] Envía:")).isEqualTo(-1);
        assertThat(indexStarting(mensajes(), "KAFKA-INVALID")).isGreaterThanOrEqualTo(0);
    }

    @Test
    void sinFilasEnLaBD_noEnvia() {
        // Given
        when(dataClient.find(eq(WAVE_KEY), eq(OFFER_KEY))).thenReturn(Optional.empty());

        // When
        sender.process(input());

        // Then
        assertThat(indexStarting(mensajes(), "[KAFKA] Envía:")).isEqualTo(-1);
    }

    @Test
    void yaNoEscribeLaLineaKafkaSent() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        sender.process(input());

        // Then
        assertThat(mensajes()).noneMatch(m -> m.contains("KAFKA-SENT"));
    }

    @Test
    void maskCardInJson_casosBorde() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(FulFillkafkaSender.maskCardInJson("{\"CardNumber\":\"1234567812345678\",\"x\":1}"))
                .isEqualTo("{\"CardNumber\":\"************5678\",\"x\":1}");
        assertThat(FulFillkafkaSender.maskCardInJson("{\"CardNumber\" : \"1234\"}")).isEqualTo("{\"CardNumber\" : \"1234\"}");
        assertThat(FulFillkafkaSender.maskCardInJson("{\"a\":1}")).isEqualTo("{\"a\":1}");
    }

    private static int indexStarting(List<String> messages, String prefix) {
        for (int i = 0; i < messages.size(); i++) {
            if (messages.get(i).startsWith(prefix)) return i;
        }
        return -1;
    }
}
