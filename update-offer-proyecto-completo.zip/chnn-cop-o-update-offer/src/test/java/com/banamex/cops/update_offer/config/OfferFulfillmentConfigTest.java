package com.banamex.cops.update_offer.config;

import com.banamex.cops.app.repository.CopOfferFulfillmentRepository;
import com.banamex.cops.app.repository.CopSuppressionRepository;
import com.banamex.cops.app.repository.CopTimezoneLookupRepository;
import com.banamex.cops.app.service.CopOfferFulfillmentService;
import com.banamex.cops.app.service.CopSuppressionService;
import com.banamex.cops.app.service.CopTimezoneLookupService;
import com.banamex.cops.update_offer.kafka.OfferDataClient;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias de {@code OfferFulfillmentConfig}.
 * <p>
 * Casos cubiertos: que registre el repositorio y el servicio de la consulta de la librería; que
 * {@code OfferDataClient} los encuentre; que no duplique beans que ya existan; y que falle con claridad
 * si no hay conexión a la base de datos.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class OfferFulfillmentConfigTest {

    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withUserConfiguration(OfferFulfillmentConfig.class);

    @Test
    void conUnaConexionJdbc_registraElRepositorioYElServicioDeLaConsulta() {
        // Given
        ApplicationContextRunner conJdbc = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conJdbc.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(ctx).hasSingleBean(CopOfferFulfillmentRepository.class);
            assertThat(ctx).hasSingleBean(CopOfferFulfillmentService.class);
        });
    }

    @Test
    void conUnaConexionJdbc_registraTambienLasConsultasDeSupresion() {
        // Given
        ApplicationContextRunner conJdbc = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conJdbc.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(ctx).hasSingleBean(CopSuppressionRepository.class);
            assertThat(ctx).hasSingleBean(CopSuppressionService.class);
        });
    }

    @Test
    void elClienteDeDatosEncuentraElServicioRegistrado_yNoLanzaErrorDeDisponibilidad() {
        // Given
        NamedParameterJdbcTemplate jdbc = mock(NamedParameterJdbcTemplate.class);
        when(jdbc.getJdbcOperations()).thenReturn(mock(JdbcOperations.class));
        ApplicationContextRunner conCliente = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> jdbc)
                .withBean(OfferDataClient.class);

        // When / Then
        conCliente.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            // el JdbcTemplate simulado no devuelve filas: lo que importa es que el servicio exista y no haya excepción
            assertThat(ctx.getBean(OfferDataClient.class).find("wvch:W1:CAT", "off:mx:C1:W1:123")).isEmpty();
        });
    }

    @Test
    void siYaExisteUnServicioDeLaConsulta_noSeRegistraOtro() {
        // Given
        ApplicationContextRunner conServicioPropio = new ApplicationContextRunner()
                .withUserConfiguration(ServicioPropio.class, OfferFulfillmentConfig.class)
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conServicioPropio.run(ctx -> {
            assertThat(ctx).hasSingleBean(CopOfferFulfillmentService.class);
            assertThat(ctx.getBean(CopOfferFulfillmentService.class)).isSameAs(ServicioPropio.SERVICIO);
        });
    }

    @Test
    void sinConexionJdbc_elContextoFallaPorqueNoHayNamedParameterJdbcTemplate() {
        // Given
        // (sin precondiciones: no se agrega ninguna conexión a la base de datos)

        // When / Then
        runner.run(ctx -> assertThat(ctx).hasFailed());
    }

    /** Simula una librería que ya registró su propio servicio de la consulta. */
    @Configuration
    static class ServicioPropio {

        static final CopOfferFulfillmentService SERVICIO = mock(CopOfferFulfillmentService.class);

        @Bean
        CopOfferFulfillmentService servicioPropio() {
            return SERVICIO;
        }
    }

    @Test
    void conUnaConexionJdbc_registraTambienElLookupDeZonaHoraria() {
        // Given
        ApplicationContextRunner conJdbc = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conJdbc.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(ctx).hasSingleBean(CopTimezoneLookupRepository.class);
            assertThat(ctx).hasSingleBean(CopTimezoneLookupService.class);
        });
    }
}
