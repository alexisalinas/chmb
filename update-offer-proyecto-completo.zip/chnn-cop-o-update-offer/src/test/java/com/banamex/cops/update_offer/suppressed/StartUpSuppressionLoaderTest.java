package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailsDTO;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntityDTO;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias de {@code StartUpSuppressionLoader}.
 * <p>
 * Casos cubiertos: los cuatro caminos del {@code Choose} del {@code SetVariable} de BW (N y N; Y y Y; Y y N; otro);
 * copia de los campos del canal; el filtro por canal; la bandera de cada detalle; listas nulas y vacías.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class StartUpSuppressionLoaderTest {

    private final StartUpSuppressionLoader loader = new StartUpSuppressionLoader();

    private static CopSuppressionChannel canal(String canal, String supresion, String operacion) {
        return new CopSuppressionChannel("MX", "RT", canal, supresion, operacion, "ECRM");
    }

    private static CopSuppressionOperation op(String nombre, String bandera, String canal) {
        return new CopSuppressionOperation(nombre, bandera, canal);
    }

    private SuppressedEntityDTO unica(SuppressedEntitiesListRoot r) {
        assertThat(r.getSuppressedEntities()).hasSize(1);
        return r.getSuppressedEntities().get(0);
    }

    // ------------------------------------------------------------ N y N

    @Test
    void supresionNyOperacionN_laEntidadVaSinDetalles() {
        // Given
        List<CopSuppressionOperation> ops = List.of(op("UpdateOffer", "Y", "CAT"));

        // When
        SuppressedEntityDTO e = unica(loader.build(List.of(canal("CAT", "N", "N")), ops));

        // Then
        assertThat(e.getOperationDetails()).isEmpty();
    }

    // ------------------------------------------------------------ Y y Y

    @Test
    void supresionYyOperacionY_soloLasOperacionesDeEseCanal_conLaBanderaFijaEnY() {
        // Given
        List<CopSuppressionOperation> ops = List.of(
                op("UpdateOffer", "N", "CAT"),            // su propia bandera es N, pero sale como "Y"
                op("GetOfferList", "Y", "CAT"),
                op("UpdateOffer", "Y", "WEB"));           // de otro canal: no va

        // When
        SuppressedEntityDTO e = unica(loader.build(List.of(canal("CAT", "Y", "Y")), ops));

        // Then
        assertThat(e.getOperationDetails()).extracting(OperationDetailsDTO::getOperationName)
                .containsExactly("UpdateOffer", "GetOfferList");
        assertThat(e.getOperationDetails()).extracting(OperationDetailsDTO::getOperationFlag).containsOnly("Y");
        assertThat(e.getOperationDetails()).extracting(OperationDetailsDTO::getReqChannel).containsOnly("CAT");
    }

    @Test
    void supresionYyOperacionY_unaOperacionSinCanalNoSeIncluye() {
        // Given
        List<CopSuppressionOperation> ops = List.of(op("UpdateOffer", "Y", null));

        // When
        SuppressedEntityDTO e = unica(loader.build(List.of(canal("CAT", "Y", "Y")), ops));

        // Then
        assertThat(e.getOperationDetails()).isEmpty();
    }

    // ------------------------------------------------------------ Y y N

    @Test
    void supresionYyOperacionN_todasLasOperaciones_conSuPropiaBandera() {
        // Given
        List<CopSuppressionOperation> ops = List.of(
                op("UpdateOffer", "Y", "CAT"),
                op("GetOfferList", "N", "WEB"));

        // When
        SuppressedEntityDTO e = unica(loader.build(List.of(canal("CAT", "Y", "N")), ops));

        // Then
        assertThat(e.getOperationDetails()).hasSize(2);
        assertThat(e.getOperationDetails().get(0).getOperationFlag()).isEqualTo("Y");
        assertThat(e.getOperationDetails().get(1).getOperationFlag()).isEqualTo("N");
        assertThat(e.getOperationDetails().get(1).getReqChannel()).isEqualTo("WEB");      // no se filtra por canal
    }

    // ------------------------------------------------------------ Otherwise

    @Test
    void supresionNyOperacionY_esElOtherwise_sinDetalles() {
        // Given
        List<CopSuppressionOperation> ops = List.of(op("UpdateOffer", "Y", "CAT"));

        // When
        SuppressedEntityDTO e = unica(loader.build(List.of(canal("CAT", "N", "Y")), ops));

        // Then
        assertThat(e.getOperationDetails()).isEmpty();
    }

    @Test
    void banderasNulasOConOtroValor_caenEnElOtherwise_comoEnXPath() {
        // Given
        List<CopSuppressionOperation> ops = List.of(op("UpdateOffer", "Y", "CAT"));
        List<CopSuppressionChannel> canales = List.of(
                new CopSuppressionChannel("MX", "RT", "CAT", null, null, "ECRM"),
                new CopSuppressionChannel("MX", "RT", "CAT", "y", "Y", "ECRM"));      // la "y" minúscula no es "Y"

        // When
        SuppressedEntitiesListRoot r = loader.build(canales, ops);

        // Then
        assertThat(r.getSuppressedEntities()).allSatisfy(e -> assertThat(e.getOperationDetails()).isEmpty());
    }

    // ------------------------------------------------------------ campos de la entidad

    @Test
    void copiaLosCamposDelCanal_yElModoSaleDeReqMode() {
        // Given
        CopSuppressionChannel c = new CopSuppressionChannel("MX", "RT", "CAT", "Y", "N", "ECRM");

        // When
        SuppressedEntityDTO e = unica(loader.build(List.of(c), List.of()));

        // Then
        assertThat(e.getCountryCode()).isEqualTo("MX");
        assertThat(e.getMode()).isEqualTo("RT");                  // REQMODE
        assertThat(e.getChannelId()).isEqualTo("CAT");
        assertThat(e.getSuppressionFlag()).isEqualTo("Y");
        assertThat(e.getOperationFlag()).isEqualTo("N");
        assertThat(e.getSourceSystem()).isEqualTo("ECRM");
    }

    @Test
    void elPaisPuedeSerNulo() {
        // Given
        CopSuppressionChannel c = new CopSuppressionChannel(null, "RT", "CAT", "N", "N", "ECRM");

        // When
        SuppressedEntityDTO e = unica(loader.build(List.of(c), List.of()));

        // Then
        assertThat(e.getCountryCode()).isNull();                  // CountryCode es opcional
    }

    @Test
    void unaEntidadPorCanal_enElMismoOrden() {
        // Given
        List<CopSuppressionChannel> canales = List.of(canal("CAT", "N", "N"), canal("WEB", "Y", "N"), canal("IVR", "N", "Y"));

        // When
        SuppressedEntitiesListRoot r = loader.build(canales, List.of());

        // Then
        assertThat(r.getSuppressedEntities()).extracting(SuppressedEntityDTO::getChannelId).containsExactly("CAT", "WEB", "IVR");
    }

    // ------------------------------------------------------------ listas vacías o nulas

    @Test
    void sinCanales_laListaVaVacia() {
        // Given
        // (sin precondiciones propias)

        // When / Then
        assertThat(loader.build(List.of(), List.of(op("UpdateOffer", "Y", "CAT"))).getSuppressedEntities()).isEmpty();
        assertThat(loader.build(null, null).getSuppressedEntities()).isEmpty();
    }

    @Test
    void sinOperaciones_lasEntidadesVanSinDetalles() {
        // Given
        List<CopSuppressionChannel> canales = List.of(canal("CAT", "Y", "Y"), canal("WEB", "Y", "N"));

        // When
        SuppressedEntitiesListRoot r = loader.build(canales, null);

        // Then
        assertThat(r.getSuppressedEntities()).allSatisfy(e -> assertThat(e.getOperationDetails()).isEmpty());
    }
}
