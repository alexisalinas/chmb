package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.service.CopSuppressionService;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias de {@code DbSuppressedEntitiesClient}.
 * <p>
 * Casos cubiertos: la lista se carga la primera vez y se queda en memoria (la "variable compartida"); timeout y
 * filas máximas que se piden; una carga fallida no se guarda y se reintenta; {@code reload()}; servicio no disponible.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class DbSuppressedEntitiesClientTest {

    @Mock CopSuppressionService service;
    @Mock ObjectProvider<CopSuppressionService> provider;

    private DbSuppressedEntitiesClient client;

    @BeforeEach
    void setUp() {
        when(provider.orderedStream()).thenAnswer(inv -> Stream.of(service));
        client = new DbSuppressedEntitiesClient(provider, new StartUpSuppressionLoader());
        when(service.findAllChannels(anyInt(), anyInt()))
                .thenReturn(List.of(new CopSuppressionChannel("MX", "RT", "CAT", "Y", "N", "ECRM")));
        when(service.findAllOperations(anyInt(), anyInt()))
                .thenReturn(List.of(new CopSuppressionOperation("UpdateOffer", "Y", "CAT")));
    }

    @Test
    void laPrimeraVezCargaLaListaDeLaBaseYLaArmaConLasBanderas() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        SuppressedEntitiesListRoot r = client.getListOfSuppressedEntities(null);

        // Then
        assertThat(r.getSuppressedEntities()).hasSize(1);
        assertThat(r.getSuppressedEntities().get(0).getChannelId()).isEqualTo("CAT");
        assertThat(r.getSuppressedEntities().get(0).getOperationDetails()).hasSize(1);   // Y y N: todas las operaciones
    }

    @Test
    void laListaSeQuedaEnMemoria_noSeVuelveAConsultarLaBase() {
        // Given
        SuppressedEntitiesListRoot primera = client.getListOfSuppressedEntities(null);

        // When
        SuppressedEntitiesListRoot segunda = client.getListOfSuppressedEntities(null);

        // Then
        assertThat(segunda).isSameAs(primera);
        verify(service, times(1)).findAllChannels(anyInt(), anyInt());
        verify(service, times(1)).findAllOperations(anyInt(), anyInt());
    }

    @Test
    void pideLasConsultasConElTimeoutYLasFilasMaximasConfigurados() {
        // Given
        ReflectionTestUtils.setField(client, "queryTimeoutSeconds", 12);
        ReflectionTestUtils.setField(client, "maxRows", 300);

        // When
        client.getListOfSuppressedEntities(null);

        // Then
        verify(service).findAllChannels(12, 300);
        verify(service).findAllOperations(12, 300);
    }

    @Test
    void porDefectoElTimeoutEs30SegundosYSinLimiteDeFilas() {
        // Given
        // (sin precondiciones propias: valores por defecto)

        // When
        client.getListOfSuppressedEntities(null);

        // Then
        verify(service).findAllChannels(30, 0);
        verify(service).findAllOperations(30, 0);
    }

    @Test
    void siLaCargaFalla_elErrorSube_noSeGuardaNada_yLaSiguienteVezSeReintenta() {
        // Given
        when(service.findAllChannels(anyInt(), anyInt()))
                .thenThrow(new IllegalStateException("ORA-00942"))
                .thenReturn(List.of(new CopSuppressionChannel("MX", "RT", "CAT", "N", "N", "ECRM")));

        // When / Then
        assertThatThrownBy(() -> client.getListOfSuppressedEntities(null))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("ORA-00942");
        assertThat(client.getListOfSuppressedEntities(null).getSuppressedEntities()).hasSize(1);
        verify(service, times(2)).findAllChannels(anyInt(), anyInt());
    }

    @Test
    void reload_vuelveACargarYReemplazaLaListaEnMemoria() {
        // Given
        SuppressedEntitiesListRoot vieja = client.getListOfSuppressedEntities(null);
        when(service.findAllChannels(anyInt(), anyInt())).thenReturn(List.of(
                new CopSuppressionChannel("MX", "RT", "CAT", "N", "N", "ECRM"),
                new CopSuppressionChannel("MX", "RT", "WEB", "N", "N", "ECRM")));

        // When
        SuppressedEntitiesListRoot nueva = client.reload();

        // Then
        assertThat(nueva).isNotSameAs(vieja);
        assertThat(nueva.getSuppressedEntities()).hasSize(2);
        assertThat(client.getListOfSuppressedEntities(null)).isSameAs(nueva);
    }

    @Test
    void sinElServicioDeLaLibreria_lanzaUnErrorClaro_yNoConsultaNada() {
        // Given
        when(provider.orderedStream()).thenAnswer(inv -> Stream.empty());

        // When / Then
        assertThatThrownBy(() -> client.getListOfSuppressedEntities(null))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("CopSuppressionService no está disponible")
                .hasMessageContaining("OfferFulfillmentConfig");
        verify(service, never()).findAllChannels(anyInt(), anyInt());
    }

    @Test
    void ignoraLosParametrosDeLaPeticion_laListaEsLaMismaParaTodas() {
        // Given
        SuppressedEntitiesListRoot a = client.getListOfSuppressedEntities(null);

        // When
        SuppressedEntitiesListRoot b = client.getListOfSuppressedEntities(new com.banamex.cops.update_offer.dto.suppression.StartRequestParams());

        // Then
        assertThat(b).isSameAs(a);
    }

    @Test
    void noEsPrimary_paraNoChocarConOtrasImplementaciones() {
        // Given
        // (sin precondiciones propias)

        // When / Then
        assertThat(DbSuppressedEntitiesClient.class.isAnnotationPresent(org.springframework.context.annotation.Primary.class)).isFalse();
    }
}
