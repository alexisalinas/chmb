package com.banamex.cops.update_offer.sender;

import jakarta.jms.BytesMessage;
import jakarta.jms.DeliveryMode;
import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import jakarta.jms.MapMessage;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageProducer;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TemporaryQueue;
import jakarta.jms.TextMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.SessionCallback;
import org.springframework.test.util.ReflectionTestUtils;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias de {@code EmsSender}.
 * <p>
 * Casos cubiertos: dry-run; envío normal; errores; tipos de respuesta; cola; causa real del error.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class EmsSenderTest {

    @Mock JmsTemplate jmsTemplate;

    private EmsSender sender;
    private Session session;
    private TemporaryQueue replyQueue;
    private MessageProducer producer;
    private MessageConsumer consumer;
    private TextMessage sent;

    @BeforeEach
    @SuppressWarnings("unchecked")
    void setUp() throws Exception {
        sender = new EmsSender(jmsTemplate);
        ReflectionTestUtils.setField(sender, "queueName", "cola.test");
        ReflectionTestUtils.setField(sender, "timeoutSeconds", 1L);
        ReflectionTestUtils.setField(sender, "timeToLiveMs", 0L);
        ReflectionTestUtils.setField(sender, "dryRun", false);

        session = mock(Session.class);
        replyQueue = mock(TemporaryQueue.class);
        Queue queue = mock(Queue.class);
        producer = mock(MessageProducer.class);
        consumer = mock(MessageConsumer.class);
        sent = mock(TextMessage.class);

        when(session.createTemporaryQueue()).thenReturn(replyQueue);
        when(session.createQueue("cola.test")).thenReturn(queue);
        when(session.createProducer(queue)).thenReturn(producer);
        when(session.createConsumer(replyQueue)).thenReturn(consumer);
        when(session.createTextMessage(anyString())).thenReturn(sent);

        when(jmsTemplate.execute(ArgumentMatchers.<SessionCallback<String>>any(), eq(true)))
                .thenAnswer(inv -> ((SessionCallback<String>) inv.getArgument(0)).doInJms(session));
    }

    private TextMessage textReply(String text) throws JMSException {
        TextMessage reply = mock(TextMessage.class);
        when(reply.getText()).thenReturn(text);
        when(reply.getPropertyNames()).thenAnswer(i -> Collections.enumeration(List.of()));
        when(consumer.receive(anyLong())).thenReturn(reply);
        return reply;
    }

    // ------------------------------------------------------------ propiedades del mensaje (OtherProperties)

    private static Map<String, String> propiedades() {
        Map<String, String> p = new LinkedHashMap<>();
        p.put("_nm_", "UpdateOffer");
        p.put("_ns_", "www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer");
        p.put("CampaignID", "CAMP001");
        p.put("UserField3", "");
        p.put("SinValor", null);
        return p;
    }

    @Test
    void conFormatoBoth_enviaElXmlEnElCuerpoYLosCamposComoPropiedadesDelMensaje() throws Exception {
        // Given
        ReflectionTestUtils.setField(sender, "messageFormat", "both");

        // When
        sender.send("<Envelope/>", propiedades());

        // Then
        verify(session).createTextMessage("<Envelope/>");
        verify(sent).setStringProperty("_nm_", "UpdateOffer");
        verify(sent).setStringProperty("_ns_", "www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer");
        verify(sent).setStringProperty("CampaignID", "CAMP001");
        verify(sent).setStringProperty("UserField3", "");              // un valor vacío también va
        verify(sent, never()).setStringProperty(eq("SinValor"), any());  // un valor nulo no
    }

    @Test
    void porDefecto_soloVanLasPropiedades_yElCuerpoVaVacio() throws Exception {
        // Given
        // (formato por defecto: properties, como el Input del JMS Queue Requestor de BW)

        // When
        sender.send("<Envelope/>", propiedades());

        // Then
        verify(session).createTextMessage("");
        verify(sent).setStringProperty("_nm_", "UpdateOffer");
        verify(sent).setStringProperty("CampaignID", "CAMP001");
    }

    @Test
    void conFormatoProperties_peroSinPropiedades_elCuerpoLlevaElXml_paraNoMandarUnMensajeVacio() throws Exception {
        // Given
        ReflectionTestUtils.setField(sender, "messageFormat", "properties");

        // When
        sender.send("<Envelope/>", Map.of());

        // Then
        verify(session).createTextMessage("<Envelope/>");
    }

    @Test
    void conFormatoProperties_elCuerpoVaVacio_yLasPropiedadesVanIgual() throws Exception {
        // Given
        ReflectionTestUtils.setField(sender, "messageFormat", "properties");

        // When
        sender.send("<Envelope/>", propiedades());

        // Then
        verify(session).createTextMessage("");
        verify(sent).setStringProperty("CampaignID", "CAMP001");
    }

    @Test
    void conFormatoXml_noPoneNingunaPropiedad() throws Exception {
        // Given
        ReflectionTestUtils.setField(sender, "messageFormat", "xml");

        // When
        sender.send("<Envelope/>", propiedades());

        // Then
        verify(session).createTextMessage("<Envelope/>");
        verify(sent, never()).setStringProperty(anyString(), any());
    }

    @Test
    void elFormatoNoDistingueMayusculas() throws Exception {
        // Given
        ReflectionTestUtils.setField(sender, "messageFormat", "PROPERTIES");

        // When
        sender.send("<Envelope/>", propiedades());

        // Then
        verify(session).createTextMessage("");
    }

    @Test
    void sinPropiedades_elEnvioDeSoloXmlSigueIgual() throws Exception {
        // Given
        // (sin precondiciones propias)

        // When
        sender.send("<Envelope/>");

        // Then
        verify(session).createTextMessage("<Envelope/>");
        verify(sent, never()).setStringProperty(anyString(), any());
    }

    @Test
    void elLogMuestraLasPropiedades_conLaTarjetaEnmascarada() {
        // Given
        ReflectionTestUtils.setField(sender, "dryRun", true);
        var appender = escucharElLog();
        Map<String, String> p = propiedades();
        p.put("CardNO", "1234567812345678");

        // When
        try {
            sender.send("<Envelope><CardNO>1234567812345678</CardNO></Envelope>", p);
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        String log = appender.list.get(0).getFormattedMessage();
        assertThat(log).contains("Propiedades del mensaje (OtherProperties):", "_nm_=UpdateOffer", "CampaignID=CAMP001",
                "CardNO=************5678");
        assertThat(log).doesNotContain("1234567812345678");
    }

    @Test
    void conFormatoProperties_elLogDiceQueElCuerpoVaVacio() {
        // Given
        ReflectionTestUtils.setField(sender, "dryRun", true);
        ReflectionTestUtils.setField(sender, "messageFormat", "properties");
        var appender = escucharElLog();

        // When
        try {
            sender.send("<Envelope/>", propiedades());
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list.get(0).getFormattedMessage()).contains("(cuerpo vacío)").doesNotContain("<Envelope/>");
    }

    @Test
    void conFormatoXml_elLogNoMuestraPropiedades() {
        // Given
        ReflectionTestUtils.setField(sender, "dryRun", true);
        ReflectionTestUtils.setField(sender, "messageFormat", "xml");
        var appender = escucharElLog();

        // When
        try {
            sender.send("<Envelope/>", propiedades());
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list.get(0).getFormattedMessage()).doesNotContain("Propiedades del mensaje");
    }

    @Test
    void describeProperties_sinPropiedades_devuelveVacio() {
        // Given
        // (sin precondiciones propias)

        // When / Then
        assertThat(EmsSender.describeProperties(null)).isEmpty();
        assertThat(EmsSender.describeProperties(Map.of())).isEmpty();
    }

    private ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> escucharElLog() {
        ch.qos.logback.classic.Logger logger = (ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger(EmsSender.class);
        ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender =
                new ch.qos.logback.core.read.ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        return appender;
    }

    private void dejarDeEscucharElLog(ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender) {
        ((ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger(EmsSender.class)).detachAppender(appender);
    }

    // ------------------------------------------------------------ dry-run

    @Test
    void dryRun_noTocaElEmsYDevuelveUnaRespuestaSimulada() {
        // Given
        ReflectionTestUtils.setField(sender, "dryRun", true);

        // When
        String reply = sender.send("<Envelope/>");

        // Then
        assertThat(reply).contains("<Code>DRY-RUN</Code>", "dry-run");
        verifyNoInteractions(jmsTemplate);
    }

    // ------------------------------------------------------------ envío normal

    @Test
    void envia_elXmlComoTextMessageConReplyToYDevuelveLaRespuesta() throws Exception {
        // Given
        textReply("<Response><Code>000</Code></Response>");

        // When
        String reply = sender.send("<Envelope/>");

        // Then
        assertThat(reply).isEqualTo("<Response><Code>000</Code></Response>");
        verify(session).createTextMessage("<Envelope/>");
        verify(sent).setJMSReplyTo(replyQueue);
        verify(producer).setDeliveryMode(DeliveryMode.NON_PERSISTENT);
        verify(producer).send(sent);
    }

    @Test
    void siempreBorraLaColaTemporalDeRespuesta() throws Exception {
        // Given
        textReply("<ok/>");

        // When
        sender.send("<Envelope/>");

        // Then
        verify(replyQueue).delete();
    }

    @Test
    void esperaLaRespuestaElTiempoConfigurado() throws Exception {
        // Given
        textReply("<ok/>");

        // When
        sender.send("<Envelope/>");

        // Then
        verify(consumer).receive(1000L);
    }

    @Test
    void conTimeToLive_loAplicaAlProductor() throws Exception {
        // Given
        ReflectionTestUtils.setField(sender, "timeToLiveMs", 5000L);
        textReply("<ok/>");

        // When
        sender.send("<Envelope/>");

        // Then
        verify(producer).setTimeToLive(5000L);
    }

    @Test
    void sinTimeToLive_noLoAplica() throws Exception {
        // Given
        textReply("<ok/>");

        // When
        sender.send("<Envelope/>");

        // Then
        verify(producer, never()).setTimeToLive(anyLong());
    }

    // ------------------------------------------------------------ errores

    @Test
    void sinRespuestaEnElTiempoConfigurado_devuelveNullYBorraLaCola() throws Exception {
        // Given
        when(consumer.receive(anyLong())).thenReturn(null);

        // When
        String reply = sender.send("<Envelope/>");

        // Then
        assertThat(reply).isNull();                    // el JMS puede no contestar: no es un error
        verify(producer).send(sent);                   // el mensaje sí se envió
        verify(replyQueue).delete();
    }

    @Test
    void conTimeoutCero_enviaSinEsperarRespuestaNiCrearLaColaTemporal() throws Exception {
        // Given
        ReflectionTestUtils.setField(sender, "timeoutSeconds", 0L);

        // When
        String reply = sender.send("<Envelope/>");

        // Then
        assertThat(reply).isNull();
        verify(producer).send(sent);
        verify(session, never()).createTemporaryQueue();
        verify(session, never()).createConsumer(any(Destination.class));
        verify(sent, never()).setJMSReplyTo(any());
    }

    @Test
    void falloAlEnviar_seEnvuelveEnRuntimeException() throws Exception {
        // Given
        doAnswer(inv -> { throw new JMSException("broker caído"); }).when(producer).send(any(Message.class));
        textReply("<ok/>");

        // When / Then
        assertThatThrownBy(() -> sender.send("<Envelope/>"))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("broker caído");
    }

    // ------------------------------------------------------------ tipos de respuesta

    @Test
    void respuestaConCuerpoVacioYPropiedades_seArmaDesdeLasPropiedades() throws Exception {
        // Given
        TextMessage reply = mock(TextMessage.class);
        when(reply.getText()).thenReturn("");
        when(reply.getPropertyNames()).thenAnswer(i -> Collections.enumeration(List.of("Code", "Description")));
        when(reply.getObjectProperty("Code")).thenReturn("000");
        when(reply.getObjectProperty("Description")).thenReturn("OK");
        when(consumer.receive(anyLong())).thenReturn(reply);

        // When / Then
        assertThat(sender.send("<Envelope/>"))
                .isEqualTo("<Response><Code>000</Code><Description>OK</Description></Response>");
    }

    @Test
    void respuestaMapMessage_seConvierteAXml() throws Exception {
        // Given
        MapMessage reply = mock(MapMessage.class);
        when(reply.getPropertyNames()).thenAnswer(i -> Collections.enumeration(List.of()));
        when(reply.getMapNames()).thenAnswer(i -> Collections.enumeration(List.of("Code")));
        when(reply.getObject("Code")).thenReturn("000");
        when(consumer.receive(anyLong())).thenReturn(reply);

        // When / Then
        assertThat(sender.send("<Envelope/>")).isEqualTo("<Response><Code>000</Code></Response>");
    }

    @Test
    void respuestaBytesMessage_seLeeComoUtf8() throws Exception {
        // Given
        byte[] data = "<Response><Code>5</Code></Response>".getBytes(StandardCharsets.UTF_8);
        BytesMessage reply = mock(BytesMessage.class);
        when(reply.getPropertyNames()).thenAnswer(i -> Collections.enumeration(List.of()));
        when(reply.getBodyLength()).thenReturn((long) data.length);
        doAnswer(inv -> {
            byte[] target = inv.getArgument(0);
            System.arraycopy(data, 0, target, 0, data.length);
            return data.length;
        }).when(reply).readBytes(any(byte[].class));
        when(consumer.receive(anyLong())).thenReturn(reply);

        // When / Then
        assertThat(sender.send("<Envelope/>")).isEqualTo("<Response><Code>5</Code></Response>");
    }

    // ------------------------------------------------------------ cola

    @Test
    void envia_aLaColaConfigurada() throws Exception {
        // Given
        textReply("<ok/>");

        // When
        sender.send("<Envelope/>");

        // Then
        verify(session).createQueue("cola.test");
    }

    // ------------------------------------------------------------ causa real del error

    @Test
    void rootCause_devuelveLaCausaMasProfunda() {
        // Given
        Exception e = new RuntimeException("Uncategorized exception occurred during JMS processing",
                new IllegalStateException("capa intermedia",
                        new java.net.ConnectException("Connection refused")));

        // When / Then
        assertThat(EmsSender.rootCause(e)).isEqualTo("ConnectException: Connection refused");
    }

    @Test
    void causeChain_listaTodasLasCausasEnUnaLinea() {
        // Given
        Exception e = new RuntimeException("A", new IllegalStateException("B", new java.io.IOException("C")));

        // When / Then
        assertThat(EmsSender.causeChain(e))
                .isEqualTo("RuntimeException: A <- IllegalStateException: B <- IOException: C");
    }

    @Test
    void sinCausa_rootCauseEsElPropioError() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(EmsSender.rootCause(new IllegalStateException("solo"))).isEqualTo("IllegalStateException: solo");
    }

    @Test
    void laRespuestaDelErrorIncluyeLaCausaRealYNoSoloElMensajeGenerico() {
        // Given
        when(jmsTemplate.execute(any(org.springframework.jms.core.SessionCallback.class), anyBoolean()))
                .thenThrow(new org.springframework.jms.UncategorizedJmsException(
                        "Uncategorized exception occurred during JMS processing",
                        new javax.net.ssl.SSLHandshakeException("PKIX path building failed")));

        // When / Then
        assertThatThrownBy(() -> sender.send("<Envelope/>"))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Error enviando al EMS")
                .hasMessageContaining("SSLHandshakeException: PKIX path building failed");
    }
}
