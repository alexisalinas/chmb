package com.banamex.cops.update_offer.kafka;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias de los valores por defecto de {@code OfferKafkaProps}.
 * <p>
 * Casos cubiertos: lo que pasa si el yml no trae el bloque {@code offer.kafka}: Kafka activo (como la global
 * {@code isKafkaOn_1 = true} de BW), en modo {@code dry-run}, con el mensaje en JSON y el nombre de evento de BW.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class OfferKafkaPropsTest {

    @Test
    void sinConfiguracion_kafkaEstaActivoPeroEnDryRun() {
        // Given
        OfferKafkaProps props = new OfferKafkaProps();

        // When / Then
        assertThat(props.isEnabled()).isTrue();             // BW: isKafkaOn_1 = true
        assertThat(props.getMode()).isEqualTo("dry-run");   // no publica nada hasta que se pase a jms
    }

    @Test
    void sinConfiguracion_elMensajeALaColaEsElJsonTodoJunto() {
        // Given
        OfferKafkaProps props = new OfferKafkaProps();

        // When / Then
        assertThat(props.getMessageFormat()).isEqualTo("json");
    }

    @Test
    void sinConfiguracion_elEventoSeLlamaUpdateofferrequest() {
        // Given
        OfferKafkaProps props = new OfferKafkaProps();

        // When / Then
        assertThat(props.getEventName()).isEqualTo("Updateofferrequest");
    }
}
