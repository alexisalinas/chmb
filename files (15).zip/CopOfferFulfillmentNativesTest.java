package com.banamex.cops.app.natives;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CopOfferFulfillmentNativesTest {

    private final String sql = CopOfferFulfillmentNatives.FIND_BY_WAVE_KEY_AND_OFFER_KEY;

    @Test
    void traeLas100ColumnasDeUserField() {
        assertThat(sql.split("OFFPAL\\.USERFIELD_", -1).length - 1).isEqualTo(100);
        assertThat(sql).contains("OFFPAL.USERFIELD_1,", "OFFPAL.USERFIELD_100");
    }

    @Test
    void usaLasTablasYLasUnionesDelModelo() {
        assertThat(sql).contains("D_OFFERPALETTE OFFPAL", "D_CAMPAIGN CAMP", "D_PRODUCT PRD", "D_WAVECHINFO WAVCH",
                "OFFPAL.campaignid = CAMP.cmpid", "CAMP.PRDCODE = PRD.PRDCODE");
    }

    @Test
    void soloSeleccionaColumnas_sinCalculosNiFunciones() {
        assertThat(sql).doesNotContain("to_char", "TO_CHAR", "* 1440", "AS APPTENDTIMEDUR");
        assertThat(sql).contains("OFFPAL.APPTSTARTDATE_TM, OFFPAL.APPTENDDATE_TM");
    }

    @Test
    void tieneDosParametrosPosicionalesEnElOrdenWaveKeyYOfferKey() {
        assertThat(sql.chars().filter(c -> c == '?').count()).isEqualTo(2);
        assertThat(sql).endsWith("WAVCH.EXTID$ = ? AND OFFPAL.EXTID$ = ?");
    }

    @Test
    void traeLasColumnasDeProductoYFechas() {
        assertThat(sql).contains("WAVCH.CRPCATEGORYID", "CAMP.PRDTYPE", "OFFPAL.REASONCODE", "OFFPAL.REASONDESC",
                "PRD.DESCRIPTION", "CAMP.FULFILLMENTPROCID", "OFFPAL.EXPIRYDATE_TM",
                "OFFPAL.OFFERCREATIONDATE_TM", "PRD.PRDCODE", "PRD.PRDFAMILY", "OFFPAL.AVAILABILITY");
    }
}
