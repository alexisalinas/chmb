package com.banamex.cops.app.service.impl;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.app.repository.CopOfferFulfillmentRepository;
import com.banamex.cops.app.service.CopOfferFulfillmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CopOfferFulfillmentServiceImpl implements CopOfferFulfillmentService {

    private final CopOfferFulfillmentRepository repository;

    @Override
    public List<CopOfferFulfillment> findByWaveKeyAndOfferKey(String waveKey, String offerKey) {
        return repository.findByWaveKeyAndOfferKey(waveKey, offerKey);
    }
}
