# Variables globales de BW que usa el código

Dónde leer el valor real en TIBCO Designer: pestaña vertical **Global Variables** (barra izquierda, la misma que se ve en tus capturas) y abre los grupos `COP > Logging / Padding / TimeZone / DateTime / Suppression / Kafka / Connections`.
Estado: **Valor real pendiente** = hoy el yml trae un valor de relleno; hay que poner el que muestra BW.

## 1. Globales que ya se usan

| # | Variable global de BW | Dónde se usa en BW | Propiedad en el yml | Valor hoy | Clase Java | Estado |
|---|---|---|---|---|---|---|
| 1 | `COP/Logging/AuditPointsEnabled` | Transición `Check Audit Enabled` de LogRequest/LogResponse: `substring(valor,1,1)="1"` | `audit.enabled` | `true` | `AuditLogService` | Valor real pendiente. BW compara el **primer carácter con "1"**; aquí es un booleano |
| 2 | `ApplicationName` y `Application_CSI_ID` | Map Data: `ApplicationID = concat(ApplicationName,"_",Application_CSI_ID)` | `audit.application-id` | `cop_163621` | `AuditLogService` | Valor real pendiente (mayúsculas y minúsculas) |
| 3 | `ComponentName` | Map Data: `ComponentName` | `audit.component-name` | `COPS` | `AuditLogService` | Valor real pendiente |
| 4 | `COP/Connections/OnlineJMSConnection/JMSExpiration` | JMS Queue Requestor: `JMSExpiration` | `update-offer.ems.time-to-live-ms` | `0` (sin expiración) | `EmsSender` | Valor real pendiente (milisegundos) |
| 5 | `COP/Connections/OnlineJMSConnection/RequestTimeout_Category1` | JMS Queue Requestor: `requestTimeout` | `update-offer.ems.timeout-seconds` | `30` | `EmsSender` | Valor real pendiente. **Ojo con la unidad:** BW usa milisegundos, el yml usa segundos |
| 6 | `COP/Padding/CustomerPadding` | `CustomerNO` (Choose): `"true"` o `"false"` | `update-offer.jms-requestor.customer-padding` | `true` | `OfferEventMapper` | Valor real pendiente |
| 7 | `COP/Padding/CustomerNo` | `tib:pad-front(CustomerNo, **este valor**, PadCharacter)` = longitud | `update-offer.jms-requestor.customer-padding-length` | `10` | `OfferEventMapper` | Valor real pendiente |
| 8 | `COP/Padding/PadCharacter` | `tib:pad-front(..., **este valor**)` = carácter de relleno | `update-offer.jms-requestor.customer-padding-char` | `"0"` | `OfferEventMapper` | Valor real pendiente |
| 9 | `COP/TimeZone/TranslateTimeZone` | Transición hacia `RequestTimeZoneValidation` y condición `and` de `ApptDate`, `ApptStartTime`, `ApptEndTime`, `UpdateTime`: `lower-case(x)="true"` | `update-offer.timezone.translate-time-zone` | `false` | `UpdateOfferServiceImpl`, `OfferEventMapper` | Valor real pendiente |
| 10 | `COP/TimeZone/ECRMTimeZone` | `getTZOffset(...)` y `tib:translate-timezone(current-dateTime(), ...)` | `update-offer.timezone.ecrm-time-zone` | `America/Mexico_City` | `TimeZoneMapRequest`, `OfferEventMapper` | Valor real pendiente (¿nombre de zona u offset?) |
| 11 | `COP/TimeZone/TimeZoneDateTimeFormat` | `getConvertedDateTime(...)` (rama Response) | `update-offer.timezone.time-zone-date-time-format` | `yyyy-MM-dd'T'HH:mm:ssZ` | `TimeZoneMapRequest` | Valor real pendiente |
| 12 | `COP/DateTime/BETimeFormat` | MapRequest, hora en Request (formato del backend) | `update-offer.timezone.be-time-format` | `HH:mm:ss` | `TimeZoneMapRequest` | Valor real pendiente |
| 13 | `COP/DateTime/BEDateTimeFormat` | MapRequest, fecha-hora en Request | `update-offer.timezone.be-date-time-format` | `yyyy-MM-dd'T'HH:mm:ssXXX` | `TimeZoneMapRequest` | Valor real pendiente |
| 14 | `COP/Suppression/CheckForSuppression` | Transición `Yes` de PerformSuppressionCheck: `= "Y"` | `cop.suppression.check-for-suppression` | `Y` | `PerformSuppressionCheckService` | Valor real pendiente |
| 15 | `COP/Kafka/EHKafkaUpdate_Delay` | Espera de FulFillKafkaSender (milisegundos) | `offer.kafka.delay-ms` | `200` | `FulFillkafkaSender` | Valor real pendiente |

## 2. Globales cuyo nombre aún no conocemos

| # | Qué es | Dónde está en BW | Propiedad en el yml | Estado |
|---|---|---|---|---|
| 16 | Condición de la transición hacia `KafkaSenderDashboard` | `OpUpdateOffer`: doble clic en la flecha que entra a esa actividad (lleva `$_globalVariables/...`) | `offer.kafka.enabled` (hoy `false`) | **Falta el nombre y el valor** |
| 17 | Condición de la transición hacia `AB-KafkaSender...` | Igual: la otra flecha (ver nota en `pendientes-y-suposiciones.md`) | no existe | **Falta** |
| 18 | Constantes del header del evento de Kafka (`name`, `version`, `producerCSI`, `countryCode`, `businessCode`) | Mapper de `KafkaSenderDashboard` > Input | `offer.kafka.event-name`, `event-version`, `producer-csi`, `country-code`, `business-code` | Falta confirmar si son globales o literales |

## 3. Globales que **no** se usan en el código

| Variable | Motivo |
|---|---|
| `GlobalVariables/Sector` (en `destinationQueue = concat(Sector, '.', ...)`) | Indicaste que el destino es solo la cola: `citi.gsg.la.cop_163621.MX_card.offer.update` (`update-offer.ems.queue`) |
| `COP/DateTime/BEDateFormat` | La fecha del Request solo se reformatea con `DateFormat`; no se necesita |
| `update-offer.logging.*` (`audit-points-enabled`, `application-name`, ...) | Eran de `LogRequestService`, que se reemplazó por `AuditLogService`. Se pueden borrar del yml |

## 4. Valores fijos del código que en BW **no** son variables globales

| Valor | Origen en BW | Dónde está en el código |
|---|---|---|
| `UpdateOffer` | `_nm_` (nombre del evento) | `update-offer.ems.body-element` |
| `1.0` | Literal del mapper: `ServiceVersion` | `audit.service-version` |
| `v3_0_0_0` | `tib:substring-after-last(namespace-uri(RqBody), "/")` del request | `audit.request-service-name` (supuesto) |
| `Offer` | Nombre de servicio del log de respuesta | `audit.response-service-name` (supuesto) |
| `MX` | `CountryCode` = `DestCountryCode` del RqHeader | `audit.country-code` (hoy fijo; debería salir del header `countryCode`) |
