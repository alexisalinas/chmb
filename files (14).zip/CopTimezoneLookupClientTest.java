package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.app.model.CopTimezoneLookup;
import com.banamex.cops.app.service.CopTimezoneLookupService;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CopTimezoneLookupClientTest {

    @Mock ObjectProvider<CopTimezoneLookupService> provider;
    @Mock CopTimezoneLookupService lookupService;
    @InjectMocks CopTimezoneLookupClient client;

    @Test
    void convierteLasFilasDeLaBDAlDto() {
        when(provider.getIfAvailable()).thenReturn(lookupService);
        when(lookupService.findBySystemNameAndModeAndOperationType("COPS", "RT", "Request")).thenReturn(List.of(
                new CopTimezoneLookup("COPS", "RT", "America/Bogota", "Request", "-05:00",
                        "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd", "HH:mm:ss")));

        List<TzLookUpDTO> r = client.find("COPS", "RT", "Request");

        assertThat(r).hasSize(1);
        TzLookUpDTO d = r.get(0);
        assertThat(d.getSystemName()).isEqualTo("COPS");
        assertThat(d.getMode()).isEqualTo("RT");
        assertThat(d.getTimeZone()).isEqualTo("America/Bogota");
        assertThat(d.getType()).isEqualTo("Request");           // tzOperationType
        assertThat(d.getTimeOffset()).isEqualTo("-05:00");
        assertThat(d.getDateTimeFormat()).isEqualTo("yyyy-MM-dd'T'HH:mm:ssZ");
        assertThat(d.getDateFormat()).isEqualTo("yyyy-MM-dd");
        assertThat(d.getTimeFormat()).isEqualTo("HH:mm:ss");
    }

    @Test
    void sinFilasDevuelveListaVacia() {
        when(provider.getIfAvailable()).thenReturn(lookupService);
        when(lookupService.findBySystemNameAndModeAndOperationType("COPS", "RT", "Request")).thenReturn(List.of());
        assertThat(client.find("COPS", "RT", "Request")).isEmpty();
    }

    @Test
    void sinLibreriaOSinBD_devuelveListaVaciaYNoLanzaExcepcion() {
        when(provider.getIfAvailable()).thenReturn(null);
        assertThat(client.find("COPS", "RT", "Request")).isEmpty();
        verify(provider).getIfAvailable();
    }

    @Test
    void losNulosDeLaBDSeConvierteEnCadenaVaciaPorqueLosCamposSonObligatorios() {
        when(provider.getIfAvailable()).thenReturn(lookupService);
        when(lookupService.findBySystemNameAndModeAndOperationType("COPS", "RT", "Request")).thenReturn(List.of(
                new CopTimezoneLookup("COPS", "RT", null, "Request", null, null, "yyyy-MM-dd", null)));

        TzLookUpDTO d = client.find("COPS", "RT", "Request").get(0);

        assertThat(d.getTimeZone()).isEmpty();
        assertThat(d.getTimeOffset()).isEmpty();
        assertThat(d.getDateTimeFormat()).isEmpty();
        assertThat(d.getTimeFormat()).isEmpty();
        assertThat(d.getDateFormat()).isEqualTo("yyyy-MM-dd");
        assertThat(d.getSystemName()).isEqualTo("COPS");
    }
}
