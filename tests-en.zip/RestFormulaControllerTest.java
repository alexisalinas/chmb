package com.banamex.app.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.banamex.app.model.EvaluateFormulaRequest;
import com.banamex.app.model.EvaluateFormulaResponse;
import com.banamex.app.model.SearchEvaluateFormulaRequest;
import com.banamex.app.service.EvaluateFormulaService;

/**
 * Unit tests for {@link RestFormulaController}.
 */
@ExtendWith(MockitoExtension.class)
class RestFormulaControllerTest {

    /**
     * Mock of the evaluation service.
     */
    @Mock
    private EvaluateFormulaService service;

    /**
     * Controller under test.
     */
    @InjectMocks
    private RestFormulaController controller;

    /**
     * Wraps the request in a {@link SearchEvaluateFormulaRequest}.
     *
     * @param inner inner request.
     * @return the wrapper request.
     */
    private SearchEvaluateFormulaRequest wrap(final EvaluateFormulaRequest inner) {
        SearchEvaluateFormulaRequest search = new SearchEvaluateFormulaRequest();
        search.setEvaluateFormulaRequest(inner);
        return search;
    }

    /**
     * Builds a request with the ATM channel.
     *
     * @param formula formula to evaluate.
     * @return the built request.
     */
    private EvaluateFormulaRequest request(final String formula) {
        EvaluateFormulaRequest request = new EvaluateFormulaRequest();
        request.setChannelCode("ATM");
        request.setEvaluationResult(formula);
        return request;
    }

    /**
     * Verifies that a valid request returns 200 with the ACCEPTED code.
     *
     * @throws Exception if the evaluation fails.
     */
    @Test
    void evaluateReturns200WithAcceptedCode() throws Exception {
        // Given
        EvaluateFormulaRequest req = request("$$1$$");
        EvaluateFormulaResponse serviceResponse = new EvaluateFormulaResponse();
        serviceResponse.setValue("1.0");
        when(service.invoke(req)).thenReturn(serviceResponse);

        // When
        ResponseEntity<?> result = controller.evaluate(wrap(req));

        // Then
        assertEquals(HttpStatus.OK, result.getStatusCode());
        EvaluateFormulaResponse body = (EvaluateFormulaResponse) result.getBody();
        assertSame(serviceResponse, body);
        assertEquals(HttpStatus.ACCEPTED.toString(), body.getCode());
    }

    /**
     * Verifies that a null request returns 400 without calling the service.
     *
     * @throws Exception if the evaluation fails.
     */
    @Test
    void nullRequestReturns400() throws Exception {
        // Given
        SearchEvaluateFormulaRequest search = wrap(null);

        // When
        ResponseEntity<?> result = controller.evaluate(search);

        // Then
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertNull(result.getBody());
        verify(service, never()).invoke(any());
    }

    /**
     * Verifies that a null formula returns 400 without calling the service.
     *
     * @throws Exception if the evaluation fails.
     */
    @Test
    void nullFormulaReturns400() throws Exception {
        // Given
        SearchEvaluateFormulaRequest search = wrap(request(null));

        // When
        ResponseEntity<?> result = controller.evaluate(search);

        // Then
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        verify(service, never()).invoke(any());
    }

    /**
     * Verifies that the service exception is propagated.
     *
     * @throws Exception if the mock setup fails.
     */
    @Test
    void propagatesServiceException() throws Exception {
        // Given
        EvaluateFormulaRequest req = request("bad");
        when(service.invoke(req)).thenThrow(new IllegalStateException("boom"));

        // When / Then
        assertThrows(IllegalStateException.class,
                () -> controller.evaluate(wrap(req)));
    }
}
