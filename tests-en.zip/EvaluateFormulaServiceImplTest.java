package com.banamex.app.service.impl;

import static com.banamex.app.constant.Constants.EVALUATE_SUCCESS_MSG;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.banamex.app.exception.BadRequestException;
import com.banamex.app.model.EvaluateFormulaRequest;
import com.banamex.app.model.EvaluateFormulaResponse;
import com.banamex.app.task.EvaluateFormulaTask;

/**
 * Unit tests for {@link EvaluateFormulaServiceImpl}.
 */
@ExtendWith(MockitoExtension.class)
class EvaluateFormulaServiceImplTest {

    /**
     * Mock of the task that evaluates the formula.
     */
    @Mock
    private EvaluateFormulaTask task;

    /**
     * Service under test.
     */
    @InjectMocks
    private EvaluateFormulaServiceImpl service;

    /**
     * Builds an evaluation request.
     *
     * @param channel request channel.
     * @param formula formula to evaluate.
     * @return the built request.
     */
    private EvaluateFormulaRequest request(final String channel,
                                           final String formula) {
        EvaluateFormulaRequest request = new EvaluateFormulaRequest();
        request.setChannelCode(channel);
        request.setEvaluationResult(formula);
        return request;
    }

    /**
     * Verifies that the response contains the value and the success description.
     *
     * @throws Exception if the invocation fails.
     */
    @Test
    void invokeReturnsValueAndDescription() throws Exception {
        // Given
        EvaluateFormulaRequest request = request("ATM", "$$1$$");
        when(task.invoke("ATM", "$$1$$")).thenReturn("1.0");

        // When
        EvaluateFormulaResponse response = service.invoke(request);

        // Then
        assertEquals("1.0", response.getValue());
        assertEquals(EVALUATE_SUCCESS_MSG, response.getDescription());
        verify(task).invoke("ATM", "$$1$$");
    }

    /**
     * Verifies that the task exception is propagated.
     *
     * @throws Exception if the mock setup fails.
     */
    @Test
    void invokePropagatesTaskException() throws Exception {
        // Given
        EvaluateFormulaRequest request = request("WEB", "bad");
        BadRequestException ex = new BadRequestException(
                null, "400 BAD_REQUEST", "Error Level: 3", "boom");
        when(task.invoke("WEB", "bad")).thenThrow(ex);

        // When
        BadRequestException thrown = assertThrows(BadRequestException.class,
                () -> service.invoke(request));

        // Then
        assertSame(ex, thrown);
    }
}
