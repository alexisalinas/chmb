package com.banamex.cops.app.service.impl;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.app.repository.CopOfferFulfillmentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias de {@code CopOfferFulfillmentServiceImpl}.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
@ExtendWith(MockitoExtension.class)
class CopOfferFulfillmentServiceImplTest {

    @Mock CopOfferFulfillmentRepository repository;
    @InjectMocks CopOfferFulfillmentServiceImpl service;

    @Test
    void delegaEnElRepositorioConLasDosClaves() {
        // Given
        CopOfferFulfillment fila = new CopOfferFulfillment("C", "T", "R", "D", "P", "F", List.of(),
                null, null, null, null, "PC", "PF", "Y");
        when(repository.findByWaveKeyAndOfferKey("wvch:W1:CAT", "off:mx:C1:W1:123")).thenReturn(List.of(fila));

        // When / Then
        assertThat(service.findByWaveKeyAndOfferKey("wvch:W1:CAT", "off:mx:C1:W1:123")).containsExactly(fila);
        verify(repository).findByWaveKeyAndOfferKey("wvch:W1:CAT", "off:mx:C1:W1:123");
    }

    @Test
    void sinFilasDevuelveListaVacia() {
        // Given
        when(repository.findByWaveKeyAndOfferKey("a", "b")).thenReturn(List.of());

        // When / Then
        assertThat(service.findByWaveKeyAndOfferKey("a", "b")).isEmpty();
    }
}
