package com.banamex.cops.app.repository;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.app.natives.CopOfferFulfillmentNatives;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

/**
 * Ejecuta el query nativo de los datos de cumplimiento de una oferta.
 * Usa JDBC (como CopTimezoneLookupRepository); la sentencia lleva timeout de 10 s y máximo de 100 filas.
 * Solo lee columnas y las entrega como vienen.
 */
@Repository
@RequiredArgsConstructor
public class CopOfferFulfillmentRepository {

    static final int QUERY_TIMEOUT_SECONDS = 10;
    static final int MAX_ROWS = 100;

    private static final RowMapper<CopOfferFulfillment> ROW_MAPPER = (rs, rowNum) -> {
        List<String> userFields = new ArrayList<>(100);
        for (int i = 1; i <= 100; i++) {
            userFields.add(rs.getString("USERFIELD_" + i));
        }
        return new CopOfferFulfillment(
                rs.getString("CRPCATEGORYID"),
                rs.getString("PRDTYPE"),
                rs.getString("REASONCODE"),
                rs.getString("REASONDESC"),
                rs.getString("DESCRIPTION"),
                rs.getString("FULFILLMENTPROCID"),
                userFields,
                rs.getTimestamp("APPTSTARTDATE_TM"),
                rs.getTimestamp("APPTENDDATE_TM"),
                rs.getTimestamp("EXPIRYDATE_TM"),
                rs.getTimestamp("OFFERCREATIONDATE_TM"),
                rs.getString("PRDCODE"),
                rs.getString("PRDFAMILY"),
                rs.getString("AVAILABILITY"));
    };

    private final NamedParameterJdbcTemplate jdbc;

    /**
     * Consulta los datos de cumplimiento de una oferta por la clave de la ola y la clave de la oferta.
     * La sentencia lleva un timeout de 10 segundos y un máximo de 100 filas.
     *
     * @param waveKey  clave de la ola con canal (WAVCH.EXTID$)
     * @param offerKey clave de la oferta (OFFPAL.EXTID$)
     * @return las filas encontradas, o una lista vacía si no hay ninguna
     */
    public List<CopOfferFulfillment> findByWaveKeyAndOfferKey(String waveKey, String offerKey) {
        return jdbc.getJdbcOperations().query(con -> {
            PreparedStatement ps = con.prepareStatement(CopOfferFulfillmentNatives.FIND_BY_WAVE_KEY_AND_OFFER_KEY);
            ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
            ps.setMaxRows(MAX_ROWS);
            ps.setString(1, waveKey);
            ps.setString(2, offerKey);
            return ps;
        }, ROW_MAPPER);
    }
}
