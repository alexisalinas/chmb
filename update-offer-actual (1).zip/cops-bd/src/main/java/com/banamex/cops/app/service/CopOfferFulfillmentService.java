package com.banamex.cops.app.service;

import com.banamex.cops.app.model.CopOfferFulfillment;

import java.util.List;

/**
 * Servicio de consulta de los datos de cumplimiento (fulfillment) de una oferta.
 * Solo expone la consulta: las reglas se aplican en el microservicio que lo usa.
 */
public interface CopOfferFulfillmentService {

    /**
     * Datos de cumplimiento de una oferta (consulta de solo lectura).
     * No hay llave primaria garantizada, así que puede devolver más de una fila.
     *
     * @param waveKey  WAVCH.EXTID$ (clave de la ola con canal)
     * @param offerKey OFFPAL.EXTID$ (clave de la oferta)
     */
    List<CopOfferFulfillment> findByWaveKeyAndOfferKey(String waveKey, String offerKey);
}
