package com.banamex.cops.app.model;

import java.sql.Timestamp;
import java.util.List;

/**
 * Datos de cumplimiento (fulfillment) de una oferta: una fila de la consulta que une
 * D_OFFERPALETTE (oferta), D_CAMPAIGN (campaña), D_PRODUCT (producto) y D_WAVECHINFO (ola y canal).
 *
 * Es el resultado crudo de la consulta: no lleva reglas ni transformaciones.
 * userFields trae los 100 USERFIELD_n en orden (índice 0 = USERFIELD_1, índice 99 = USERFIELD_100).
 */
public record CopOfferFulfillment(
        String crpCategoryId,
        String prdType,
        String reasonCode,
        String reasonDesc,
        String prdDescription,
        String fulfillmentProcId,
        List<String> userFields,
        Timestamp apptStartDate,
        Timestamp apptEndDate,
        Timestamp expiryDate,
        Timestamp offerCreationDate,
        String prdCode,
        String prdFamily,
        String availability) {
}
