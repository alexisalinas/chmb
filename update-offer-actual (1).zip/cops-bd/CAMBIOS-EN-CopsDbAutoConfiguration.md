# Cambios en `CopsDbAutoConfiguration` (com.banamex.cops.app.autoconfigure)

La clase registra los beans con `@Import({...})`. Agrega **dos clases** a esa lista (junto a
`CopTimezoneLookupRepository.class` y `CopTimezoneLookupServiceImpl.class`):

```java
import com.banamex.cops.app.repository.CopOfferFulfillmentRepository;
import com.banamex.cops.app.service.impl.CopOfferFulfillmentServiceImpl;

@AutoConfiguration
@EntityScan(basePackages = "com.banamex.cops.app.entity")
@EnableJpaRepositories(basePackages = "com.banamex.cops.app.repository")
@Import({
    CopOfferQuery.class,
    ...
    CopTimezoneLookupRepository.class,
    CopOfferFulfillmentRepository.class,      // <-- NUEVO
    ...
    CopTimezoneLookupServiceImpl.class,
    CopOfferFulfillmentServiceImpl.class,     // <-- NUEVO
    ...
})
```

Qué lleva la librería (solo la consulta): `CopOfferFulfillment` (modelo), `CopOfferFulfillmentNatives` (SQL),
`CopOfferFulfillmentRepository` (JDBC, timeout 10 s y 100 filas), `CopOfferFulfillmentService` y su `Impl`
(solo delega). Las reglas (claves, relleno, fechas, minutos, formato del JSON) están en el microservicio.

Notas:
- `CopOfferFulfillmentRepository` NO es un repositorio de Spring Data (no extiende `JpaRepository`), igual que
  `CopTimezoneLookupRepository`; por eso `@EnableJpaRepositories` no lo toca y hay que importarlo explícitamente.
- Después hay que **recompilar e instalar la librería** (`mvn clean install`) y refrescar la dependencia en el
  microservicio (Maven > Update Project, con Force Update).
