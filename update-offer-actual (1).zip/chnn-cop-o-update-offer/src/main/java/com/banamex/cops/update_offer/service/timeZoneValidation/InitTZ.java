package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.TzFormatsDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Equivalente al Assign "InitTZ" de BW/Common/TimeZoneValidation.
 * Devuelve vacío cuando no hay coincidencia (rama "Otherwise" -> LookupTZ).
 */
@Component
public class InitTZ {

    /**
     * Busca en la lista de zonas horarias la que corresponde al sistema, modo y tipo, y arma los formatos.
     *
     * @param system  sistema
     * @param sysMode modo del sistema
     * @param type    tipo de operación (Request o Response)
     * @param lookUp  zonas horarias disponibles
     * @return los formatos de la zona, o vacío si no hay coincidencia
     */
    public Optional<TzFormatsDTO> execute(String system, String sysMode, String type, List<TzLookUpDTO> lookUp) {
        if (lookUp == null) {
            return Optional.empty();
        }
        return lookUp.stream()
                .filter(l -> Objects.equals(system, l.getSystemName())
                        && Objects.equals(sysMode, l.getMode())
                        && Objects.equals(type, l.getType()))
                .findFirst()
                .map(l -> {
                    TzFormatsDTO f = new TzFormatsDTO();
                    f.setTimeZoneOffset(l.getTimeOffset());
                    f.setDateFormat(l.getDateFormat());
                    f.setTimeFormat(l.getTimeFormat());
                    f.setDateTimeFormat(l.getDateTimeFormat());
                    f.setTimeZone(l.getTimeZone());
                    return f;
                });
    }
}
