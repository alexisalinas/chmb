package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.log.header.ClientDetailsDTO;
import com.banamex.cops.update_offer.dto.log.header.RqHeaderDTO;
import com.banamex.cops.update_offer.validation.DtoValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Arma el RqHeader (equivale al GetContext de BW) SOLO con los headers del swagger:
 *
 *  UUID ................................. header uuid (no se genera)
 *  ESBUUID .............................. uuid + yyyyMMddHHmmss (se genera aquí)
 *  DateAndTimeStamp ..................... la hora actual
 *  ClientDetails/ChannelID .............. header ChannelId
 *  ClientDetails/SrcCountryCode y Dest .. header countryCode
 *  ClientDetails/SessionLanguageCode .... header Accept-Language (opcional)
 *  ClientDetails/Org, OrgUnit, TerminalID, UserID y RqHeader/Version ... valores del yml (update-offer.header.*),
 *      porque el swagger no trae headers para ellos
 *
 * Los demás headers que lleguen (Org, UserID, ...) NO alimentan el RqHeader: solo se ven en el log del request.
 * Al final valida el RqHeaderDTO con las reglas del esquema; si falta algo responde con InvalidRqHeaderException (400).
 */
@Component
public class RqHeaderFactory {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private final DtoValidator validator;

    @Value("${update-offer.header.version:}")
    private String version;

    @Value("${update-offer.header.org:}")
    private String org;

    @Value("${update-offer.header.org-unit:}")
    private String orgUnit;

    @Value("${update-offer.header.terminal-id:}")
    private String terminalId;

    @Value("${update-offer.header.user-id:}")
    private String userId;

    /**
     * Crea la fábrica.
     *
     * @param validator validador que aplica las reglas obligatorio / opcional del RqHeader
     */
    public RqHeaderFactory(DtoValidator validator) {
        this.validator = validator;
    }

    /**
     * Arma y valida el RqHeader con los headers del swagger y los valores del yml.
     *
     * @param h headers recibidos en la petición
     * @return el RqHeader válido
     * @throws InvalidRqHeaderException si falta el uuid o un valor obligatorio del RqHeader o del ClientDetails
     */
    public RqHeaderDTO create(UpdateOfferHeaders h) {
        if (!hasText(h.getUuid())) {
            throw new InvalidRqHeaderException("El header uuid es obligatorio: el UUID no se genera, viene en el header");
        }
        LocalDateTime now = LocalDateTime.now();

        RqHeaderDTO header = RqHeaderDTO.builder()
                .dateTimeStamp(now)
                .uuid(h.getUuid())
                .esbUuid(h.getUuid() + now.format(TS))
                .version(hasText(version) ? version : null)
                .clientDetails(ClientDetailsDTO.builder()
                        .org(org)
                        .orgUnit(orgUnit)
                        .channelID(h.getChannelId())
                        .terminalID(terminalId)
                        .userID(userId)
                        .srcCountryCode(h.getCountryCode())
                        .destCountryCode(h.getCountryCode())
                        .sessionLanguageCode(language(h.getAcceptLanguage()))
                        .build())
                .build();
        try {
            validator.validateOrThrow(header);
        } catch (IllegalArgumentException e) {
            throw new InvalidRqHeaderException(e.getMessage());
        }
        return header;
    }

    /** "es-MX,es;q=0.9" -> "ES"; null si no llega Accept-Language. */
    private String language(String acceptLanguage) {
        if (!hasText(acceptLanguage)) return null;
        String first = acceptLanguage.split("[,;]")[0].trim();
        String lang = first.split("-")[0].trim();
        return lang.isEmpty() ? null : lang.toUpperCase();
    }

    private static boolean hasText(String s) { return s != null && !s.trim().isEmpty(); }
}
