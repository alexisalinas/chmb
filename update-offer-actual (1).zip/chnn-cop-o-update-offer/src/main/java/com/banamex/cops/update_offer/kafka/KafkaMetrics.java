package com.banamex.cops.update_offer.kafka;

import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicLong;

/** Contadores simples del flujo (enviados, descartados, fallidos). */
@Component
public class KafkaMetrics {

    private final AtomicLong sent = new AtomicLong();
    private final AtomicLong noRows = new AtomicLong();
    private final AtomicLong invalid = new AtomicLong();
    private final AtomicLong failed = new AtomicLong();
    private final AtomicLong rejected = new AtomicLong();

    /** Suma un envío publicado. */
    public void incSent() { sent.incrementAndGet(); }
    /** Suma una oferta que no se encontró en la base de datos. */
    public void incNoRows() { noRows.incrementAndGet(); }
    /** Suma una entrada descartada por faltarle datos obligatorios. */
    public void incInvalid() { invalid.incrementAndGet(); }
    /** Suma un envío que falló después de los reintentos. */
    public void incFailed() { failed.incrementAndGet(); }
    /** Suma un envío rechazado porque la cola del ejecutor estaba llena. */
    public void incRejected() { rejected.incrementAndGet(); }

    /** @return el total de envíos publicados. */
    public long getSent() { return sent.get(); }
    /** @return el total de ofertas no encontradas. */
    public long getNoRows() { return noRows.get(); }
    /** @return el total de entradas descartadas. */
    public long getInvalid() { return invalid.get(); }
    /** @return el total de envíos fallidos. */
    public long getFailed() { return failed.get(); }
    /** @return el total de envíos rechazados. */
    public long getRejected() { return rejected.get(); }
}
