package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationResult;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationStartDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzFormatsDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.ValueItemDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * /BW/Common/TimeZoneValidation:
 * GetVariable (cache) -> InitTZ -> (si no existe) LookupTZ -> SetVariable (cache) -> MapRequest.
 *
 * Códigos de respuesta (SUPUESTOS, ajustar a los reales):
 *  - COP_TZCOD_000: validación correcta
 *  - COP_TZCOD_114: no hay configuración de zona horaria (el flujo principal igual continúa)
 *  - invalid-code : alguna fecha/hora no es válida (el flujo se detiene)
 */
@Service
@RequiredArgsConstructor
public class TimeZoneValidationService {

    /** Código de resultado cuando la validación de zona horaria fue correcta (supuesto, por confirmar). */
    public static final String OK = "COP_TZCOD_000";
    /** Código de resultado cuando el sistema, modo y tipo no tienen zona horaria configurada. */
    public static final String NOT_CONFIGURED = "COP_TZCOD_114";
    private static final String INVALID_STATUS = "Invalid TimeZone";

    private final InitTZ initTZ;
    private final TimeZoneLookupClient lookupClient;
    private final TimeZoneMapRequest mapRequest;

    @Value("${update-offer.timezone.invalid-code:COP_TZCOD_101}")
    private String invalidCode;

    /** Equivale a la variable compartida LookUp. */
    private final List<TzLookUpDTO> cache = new CopyOnWriteArrayList<>();

    /** Igual que validate(...), recibiendo el nodo Start completo de BW (System, SysMode, Type, Date*, Time*, DateTime*). */
    public TimeZoneValidationResult validate(TimeZoneValidationStartDTO start) {
        return validate(start.getSystem(), start.getSysMode(), start.getType(),
                start.getDate(), start.getTime(), start.getDateTime());
    }

    /**
     * Valida la zona horaria: obtiene o carga los formatos del sistema (con caché) y convierte las fechas y horas.
     *
     * @param system    sistema
     * @param sysMode   modo del sistema
     * @param type      {@code Request} o {@code Response}
     * @param dates     fechas a procesar
     * @param times     horas a procesar
     * @param dateTimes fechas-horas a procesar
     * @return el código y texto del resultado, los formatos y los valores convertidos
     */
    public TimeZoneValidationResult validate(String system, String sysMode, String type,
                                             List<ValueItemDTO> dates, List<ValueItemDTO> times,
                                             List<ValueItemDTO> dateTimes) {
        Optional<TzFormatsDTO> formats = initTZ.execute(system, sysMode, type, cache);

        if (formats.isEmpty()) {                                   // Otherwise -> LookupTZ
            List<TzLookUpDTO> found = lookupClient.find(system, sysMode, type);
            if (found != null && !found.isEmpty()) {               // exists -> SetTZ + SetVariable
                cache.addAll(found);
                formats = initTZ.execute(system, sysMode, type, found);
            }
        }

        if (formats.isEmpty()) {
            return result(NOT_CONFIGURED, "TimeZone not configured", emptyFormats(), new MapRequestResultDTO());
        }

        MapRequestResultDTO map = mapRequest.map(type, formats.get(), dates, times, dateTimes);
        boolean invalid = map.getDateGrp().stream().anyMatch(g -> INVALID_STATUS.equals(g.getDateStatus()))
                || map.getTimeGrp().stream().anyMatch(g -> INVALID_STATUS.equals(g.getTimeStatus()))
                || map.getDateTimeGrp().stream().anyMatch(g -> INVALID_STATUS.equals(g.getDateTimeStatus()));

        return result(invalid ? invalidCode : OK, invalid ? INVALID_STATUS : "Success", formats.get(), map);
    }

    /** Formats sin configuración: los cinco campos son obligatorios en el esquema, así que van vacíos (no nulos). */
    private TzFormatsDTO emptyFormats() {
        TzFormatsDTO f = new TzFormatsDTO();
        f.setTimeZoneOffset("");
        f.setDateFormat("");
        f.setTimeFormat("");
        f.setDateTimeFormat("");
        f.setTimeZone("");
        return f;
    }

    /** Se arma con setters (sin builder) para no depender de @Builder en los DTOs. */
    private TimeZoneValidationResult result(String code, String text, TzFormatsDTO formats, MapRequestResultDTO map) {
        TimeZoneValidationResult r = new TimeZoneValidationResult();
        r.setResponseCode(code);
        r.setResponseText(text);
        r.setFormats(formats);
        r.setMapResult(map);
        return r;
    }
}
