package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.ControlFieldDTO;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Respuesta del EMS -> UpdateOfferResponse (REST).
 * Equivale al "Parse JSON" + mapper "RsUpdateOffer" de BW. Acepta XML o JSON.
 *
 * La respuesta se lee buscando cada campo por su nombre de elemento en cualquier parte del documento:
 * no depende de rutas, prefijos ni namespaces. Nombres que trae la respuesta real del EMS (según el log de BW): ResponseCode (code), ResponseText (description)
 * y ControlField repetido (contextType). También se aceptan los nombres del contrato nuevo y otros antiguos de BW.
 */
@Component
@RequiredArgsConstructor
public class UpdateOfferResponseXmlMapper {

    private final JsonMapper jsonMapper;

    // =====================================================================
    //  EMS -> REST
    // =====================================================================
    /**
     * Convierte la respuesta del EMS (XML o JSON) en una sola respuesta REST.
     *
     * @param reply cuerpo de la respuesta del EMS
     * @return la respuesta REST con código, descripción y campos de control
     * @throws IllegalStateException si la respuesta está vacía o no se puede leer
     */
    public UpdateOfferResponse fromReply(String reply) {
        if (reply == null || reply.isBlank()) {
            throw new IllegalStateException("Respuesta vacía del EMS");
        }
        return reply.trim().startsWith("{") ? fromJson(reply) : fromXml(reply);
    }

    /**
     * Una respuesta por oferta: cuando el mensaje al EMS lleva varias ofertas, el EMS contesta con un
     * UpdateOfferRes por cada una (en el mismo orden). Si la respuesta no trae UpdateOfferRes, se lee como
     * una sola respuesta (fromReply). Una respuesta JSON se trata como una sola.
     */
    public List<UpdateOfferResponse> fromReplies(String reply) {
        if (reply == null || reply.isBlank()) {
            throw new IllegalStateException("Respuesta vacía del EMS");
        }
        if (reply.trim().startsWith("{")) {
            return List.of(fromJson(reply));
        }
        try {
            Document doc = parse(reply);
            List<Element> items = elements(doc, "UpdateOfferRes");
            if (items.isEmpty()) {
                return List.of(fromNode(doc));
            }
            List<UpdateOfferResponse> out = new ArrayList<>();
            for (Element item : items) {
                out.add(fromNode(item));
            }
            return out;
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo leer la respuesta XML del EMS: " + e.getMessage(), e);
        }
    }

    private UpdateOfferResponse fromXml(String xml) {
        try {
            return fromNode(parse(xml));
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo leer la respuesta XML del EMS: " + e.getMessage(), e);
        }
    }

    /** Lee los campos de un documento completo o de un solo UpdateOfferRes. */
    private UpdateOfferResponse fromNode(Node root) {
        List<ControlFieldDTO> controlFields = new ArrayList<>();
        for (Element e : elements(root, "ControlField")) {
            controlFields.add(ControlFieldDTO.builder().contextType(e.getTextContent()).build());
        }
        return build(
                xmlFirst(root, "Code", "ResponseCode", "ReturnCode"),
                xmlFirst(root, "Description", "ResponseText", "Message"),
                xmlFirst(root, "CustomerReferenceNumber", "ReferenceContacto", "ContactReference"),
                xmlFirst(root, "StartDate"),
                xmlFirst(root, "EndDate"),
                xmlFirst(root, "SurveyModeCode", "ModeCmp"),
                controlFields);
    }

    private UpdateOfferResponse fromJson(String json) {
        try {
            JsonNode root = jsonMapper.readTree(json);
            return build(
                    jsonFirst(root, "code", "responseCode", "returnCode"),
                    jsonFirst(root, "description", "responseText", "message"),
                    jsonFirst(root, "customerReferenceNumber", "referenceContacto", "contactReference"),
                    jsonFirst(root, "startDate"),
                    jsonFirst(root, "endDate"),
                    jsonFirst(root, "surveyModeCode", "modeCmp"),
                    List.of());
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo leer la respuesta JSON del EMS: " + e.getMessage(), e);
        }
    }

    private UpdateOfferResponse build(String code, String description, String reference, String start,
                                      String end, String surveyMode, List<ControlFieldDTO> controlFields) {
        return UpdateOfferResponse.builder()
                .code(code != null ? code : "ERROR")
                .description(description != null ? description : "Respuesta del EMS sin descripción")
                .customerReferenceNumber(reference)
                .startDate(start)
                .endDate(end)
                .surveyModeCode(surveyMode)
                .contextType(controlFields.isEmpty() ? null : controlFields)
                .build();
    }

    // =====================================================================
    //  helpers XML / JSON
    // =====================================================================
    private Document parse(String xml) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        f.setXIncludeAware(false);
        f.setExpandEntityReferences(false);
        return f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
    }

    private String xmlFirst(Node root, String... names) {
        for (String name : names) {
            List<Element> found = elements(root, name);
            if (!found.isEmpty()) {
                String t = found.get(0).getTextContent();
                if (t != null && !t.trim().isEmpty()) return t.trim();
            }
        }
        return null;
    }

    private List<Element> elements(Node root, String localName) {
        List<Element> out = new ArrayList<>();
        NodeList all = root instanceof Document d ? d.getElementsByTagName("*") : ((Element) root).getElementsByTagName("*");
        for (int i = 0; i < all.getLength(); i++) {
            Element e = (Element) all.item(i);
            String ln = e.getLocalName() != null ? e.getLocalName() : e.getTagName();
            if (ln.equalsIgnoreCase(localName)) out.add(e);
        }
        return out;
    }

    /** Busca recursivamente el primer valor simple cuyo nombre coincida (sin importar mayúsculas). */
    private String jsonFirst(JsonNode root, String... names) {
        for (String name : names) {
            AtomicReference<String> found = new AtomicReference<>();
            search(root, name, found);
            if (found.get() != null) return found.get();
        }
        return null;
    }

    private void search(JsonNode n, String name, AtomicReference<String> found) {
        if (found.get() != null || n == null) return;
        if (n.isObject()) {
            n.properties().forEach(e -> {
                if (found.get() != null) return;
                if (e.getKey().equalsIgnoreCase(name) && e.getValue().isValueNode() && !e.getValue().isNull()) {
                    found.set(e.getValue().asText());
                } else {
                    search(e.getValue(), name, found);
                }
            });
        } else if (n.isArray()) {
            n.forEach(c -> search(c, name, found));
        }
    }
}
