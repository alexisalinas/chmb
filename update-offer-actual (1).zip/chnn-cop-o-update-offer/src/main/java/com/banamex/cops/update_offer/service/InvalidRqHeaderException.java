package com.banamex.cops.update_offer.service;

/**
 * Los headers HTTP no permiten armar un RqHeader válido (falta el uuid o un campo obligatorio del
 * RqHeader / ClientDetails). El controller la responde con 400 y un ErrorResponse.
 */
public class InvalidRqHeaderException extends IllegalArgumentException {

    /**
     * Crea la excepción con el detalle de lo que falta o es inválido.
     *
     * @param message detalle que se devuelve en el 400
     */
    public InvalidRqHeaderException(String message) {
        super(message);
    }
}
