package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.log.header.ClientDetailsDTO;
import com.banamex.cops.update_offer.dto.log.header.RqHeaderDTO;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;

import static com.banamex.cops.update_offer.mapper.XmlUtil.tag;

/**
 * RqHeaderDTO -> XML del RqHeader (sin prefijos ni URLs).
 * Equivale al nodo RqHeader que BW recibía en GetContext y copiaba al mensaje al EMS.
 */
@Component
public class RqHeaderXmlMapper {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");

    /** RqHeader en elementos simples. Omite lo que viene null. */
    public String toEnvelopeHeader(RqHeaderDTO h, String indent) {
        StringBuilder x = new StringBuilder();
        String i1 = indent + "   ";
        String i2 = i1 + "   ";
        x.append(indent).append("<RqHeader>\n");
        tag(x, i1, "DateAndTimeStamp", h.getDateTimeStamp() == null ? null : h.getDateTimeStamp().format(TS));
        tag(x, i1, "UUID", h.getUuid());
        tag(x, i1, "ESBUUID", h.getEsbUuid());
        tag(x, i1, "Version", h.getVersion());
        ClientDetailsDTO c = h.getClientDetails();
        if (c != null) {
            x.append(i1).append("<ClientDetails>\n");
            tag(x, i2, "Org", c.getOrg());
            tag(x, i2, "OrgUnit", c.getOrgUnit());
            tag(x, i2, "ChannelID", c.getChannelID());
            tag(x, i2, "TerminalID", c.getTerminalID());
            tag(x, i2, "ClientIPAddress", c.getClientIPAddress());
            tag(x, i2, "UserID", c.getUserID());
            tag(x, i2, "SrcCountryCode", c.getSrcCountryCode());
            tag(x, i2, "DestCountryCode", c.getDestCountryCode());
            tag(x, i2, "UserDomicileBranchCode", c.getUserDomicileBranchCode());
            tag(x, i2, "UserDomicileResponsibilityCentre", c.getUserDomicileResponsibilityCentre());
            tag(x, i2, "ProcessingBranchCode", c.getProcessingBranchCode());
            tag(x, i2, "ProcessingResponsibilityCentre", c.getProcessingResponsibilityCentre());
            tag(x, i2, "UserGroup", c.getUserGroup());
            tag(x, i2, "SessionLanguageCode", c.getSessionLanguageCode());
            x.append(i1).append("</ClientDetails>\n");
        }
        x.append(indent).append("</RqHeader>\n");
        return x.toString();
    }

}
