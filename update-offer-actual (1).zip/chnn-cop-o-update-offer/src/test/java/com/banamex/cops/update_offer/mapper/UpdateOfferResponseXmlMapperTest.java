package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.ControlFieldDTO;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.testutil.TestData;
import com.banamex.cops.update_offer.testutil.XmlTestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Pruebas unitarias de {@code UpdateOfferResponseXmlMapper}.
 * <p>
 * Casos cubiertos: XML; JSON; XML del log de respuesta; respuesta real del EMS (según el log de BW); una respuesta por oferta (UpdateOfferRes repetido).
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class UpdateOfferResponseXmlMapperTest {

    private UpdateOfferResponseXmlMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new UpdateOfferResponseXmlMapper(JsonMapper.builder().build());
    }

    // ------------------------------------------------------------ XML

    @Test
    void xml_conNombresNuevos() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply(
                "<Response><Code>000</Code><Description>OK</Description>"
              + "<CustomerReferenceNumber>REF1</CustomerReferenceNumber><StartDate>2026-10-01</StartDate>"
              + "<EndDate>2026-10-31</EndDate><SurveyModeCode>M1</SurveyModeCode></Response>");

        // Then
        assertThat(r.getCode()).isEqualTo("000");
        assertThat(r.getDescription()).isEqualTo("OK");
        assertThat(r.getCustomerReferenceNumber()).isEqualTo("REF1");
        assertThat(r.getStartDate()).isEqualTo("2026-10-01");
        assertThat(r.getEndDate()).isEqualTo("2026-10-31");
        assertThat(r.getSurveyModeCode()).isEqualTo("M1");
    }

    @Test
    void xml_conNombresAntiguosDeBW() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply(
                "<Rs><ReferenceContacto>R9</ReferenceContacto><ModeCmp>MC</ModeCmp>"
              + "<Code>0</Code><Description>ok</Description></Rs>");

        // Then
        assertThat(r.getCustomerReferenceNumber()).isEqualTo("R9");
        assertThat(r.getSurveyModeCode()).isEqualTo("MC");
    }

    @Test
    void xml_conPrefijosDeNamespaceSeEncuentraIgual() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply(
                "<a:Rs xmlns:a=\"urn:x\"><a:Code>7</a:Code><a:Description>desc</a:Description></a:Rs>");

        // Then
        assertThat(r.getCode()).isEqualTo("7");
        assertThat(r.getDescription()).isEqualTo("desc");
    }

    @Test
    void xml_controlFieldSeConvierteAContextType() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply(
                "<Rs><Code>0</Code><Description>d</Description><ControlField>c1</ControlField><ControlField>c2</ControlField></Rs>");

        // Then
        assertThat(r.getContextType()).extracting(ControlFieldDTO::getContextType).containsExactly("c1", "c2");
    }

    @Test
    void xml_sinCodeNiDescription_usaValoresPorDefecto() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply("<Rs><Otra>x</Otra></Rs>");

        // Then
        assertThat(r.getCode()).isEqualTo("ERROR");
        assertThat(r.getDescription()).isNotBlank();
        assertThat(r.getContextType()).isNull();
    }

    @Test
    void xml_mal_formado_lanzaIllegalState() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThatThrownBy(() -> mapper.fromReply("<Rs><Code>0</Rs>"))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    void xml_conDoctype_seRechaza() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThatThrownBy(() -> mapper.fromReply("<!DOCTYPE a [<!ENTITY x \"y\">]><a><Code>&x;</Code></a>"))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    void respuestaVaciaONula_lanzaIllegalState() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThatThrownBy(() -> mapper.fromReply(null)).isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> mapper.fromReply("  ")).isInstanceOf(IllegalStateException.class);
    }

    // ------------------------------------------------------------ JSON

    @Test
    void json_conNombresNuevosYAntiguos() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply(
                "{\"code\":\"000\",\"description\":\"OK\",\"referenceContacto\":\"R1\",\"modeCmp\":\"M\"}");

        // Then
        assertThat(r.getCode()).isEqualTo("000");
        assertThat(r.getDescription()).isEqualTo("OK");
        assertThat(r.getCustomerReferenceNumber()).isEqualTo("R1");
        assertThat(r.getSurveyModeCode()).isEqualTo("M");
    }

    @Test
    void json_anidadoSeBuscaRecursivamente() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply("{\"response\":{\"data\":{\"Code\":\"5\",\"Description\":\"anidado\"}}}");

        // Then
        assertThat(r.getCode()).isEqualTo("5");
        assertThat(r.getDescription()).isEqualTo("anidado");
    }

    @Test
    void json_conArreglo() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply("{\"items\":[{\"code\":\"9\",\"description\":\"d\"}]}");

        // Then
        assertThat(r.getCode()).isEqualTo("9");
    }

    @Test
    void json_sinCode_usaError() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply("{\"x\":1}");

        // Then
        assertThat(r.getCode()).isEqualTo("ERROR");
    }

    @Test
    void json_invalido_lanzaIllegalState() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThatThrownBy(() -> mapper.fromReply("{no es json")).isInstanceOf(IllegalStateException.class);
    }

    // ------------------------------------------------------------ XML del log de respuesta

    // ------------------------------------------------------------ respuesta real del EMS (según el log de BW)

    private static final String RESPUESTA_REAL =
            "<ns0:UpdateOfferRs xmlns:ns0=\"urn:services\">"
          + "<ns1:ResponseCode xmlns:ns1=\"urn:types\">COP_UPDOF_0</ns1:ResponseCode>"
          + "<ns1:ResponseText xmlns:ns1=\"urn:types\">Successfully update offer off:mx:RETAILRS25:RH52KYVD39:116740699</ns1:ResponseText>"
          + "<ns1:ControlField xmlns:ns1=\"urn:types\">2</ns1:ControlField>"
          + "<ns1:ControlField xmlns:ns1=\"urn:types\">881362001797184</ns1:ControlField>"
          + "</ns0:UpdateOfferRs>";

    @Test
    void respuestaReal_seLeeResponseCodeResponseTextYLosDosControlField() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply(RESPUESTA_REAL);

        // Then
        assertThat(r.getCode()).isEqualTo("COP_UPDOF_0");
        assertThat(r.getDescription()).isEqualTo("Successfully update offer off:mx:RETAILRS25:RH52KYVD39:116740699");
        assertThat(r.getContextType()).extracting(ControlFieldDTO::getContextType).containsExactly("2", "881362001797184");
    }

    @Test
    void respuestaReal_conElSegundoControlFieldVacio_loConservaComoCadenaVacia() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = mapper.fromReply(
                "<UpdateOfferRs><ResponseCode>COP_UPDOF_0</ResponseCode><ResponseText>ok</ResponseText>"
              + "<ControlField>3</ControlField><ControlField/></UpdateOfferRs>");

        // Then
        assertThat(r.getContextType()).extracting(ControlFieldDTO::getContextType).containsExactly("3", "");
    }

    @Test
    void xml_encuentraLosCamposSinImportarLaRutaNiLaProfundidad() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse plano = mapper.fromReply("<Rs><Code>7</Code><Description>desc</Description></Rs>");
        UpdateOfferResponse profundo = mapper.fromReply(
                "<a><b><c><d><Code>7</Code><Description>desc</Description></d></c></b></a>");
        UpdateOfferResponse conOtroNombreDeRaiz = mapper.fromReply(
                "<Cualquiera><Header/><Body><X><Code>7</Code><Description>desc</Description></X></Body></Cualquiera>");

        // Then
        for (UpdateOfferResponse r : List.of(plano, profundo, conOtroNombreDeRaiz)) {
            assertThat(r.getCode()).isEqualTo("7");
            assertThat(r.getDescription()).isEqualTo("desc");
        }
    }

    // ------------------------------------------------------------ una respuesta por oferta (UpdateOfferRes repetido)

    private static final String LOTE =
            "<ActivityOutputBody>"
          + "<UpdateOfferRes><ResponseCode>COP_UPDOF_0</ResponseCode>"
          + "<ResponseText>Successfully update offer off:mx:C1:W1:111</ResponseText>"
          + "<ControlField>5</ControlField><ControlField>8813625550465000</ControlField></UpdateOfferRes>"
          + "<UpdateOfferRes><ResponseCode>COP_UPDOF_5</ResponseCode>"
          + "<ResponseText>Campaign not found</ResponseText></UpdateOfferRes>"
          + "</ActivityOutputBody>";

    @Test
    void lote_devuelveUnaRespuestaPorCadaUpdateOfferResEnElMismoOrden() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        List<UpdateOfferResponse> r = mapper.fromReplies(LOTE);

        // Then
        assertThat(r).hasSize(2);
        assertThat(r.get(0).getCode()).isEqualTo("COP_UPDOF_0");
        assertThat(r.get(0).getDescription()).isEqualTo("Successfully update offer off:mx:C1:W1:111");
        assertThat(r.get(1).getCode()).isEqualTo("COP_UPDOF_5");
        assertThat(r.get(1).getDescription()).isEqualTo("Campaign not found");
    }

    @Test
    void lote_loCamposDeUnaRespuestaNoSeMezclanConLosDeOtra() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        List<UpdateOfferResponse> r = mapper.fromReplies(LOTE);

        // Then
        assertThat(r.get(0).getContextType()).extracting(ControlFieldDTO::getContextType)
                .containsExactly("5", "8813625550465000");
        assertThat(r.get(1).getContextType()).isNull();
    }

    @Test
    void lote_conPrefijosYNamespacesTambienSeSeparaPorUpdateOfferRes() {
        // Given
        String xml = "<ns:ActivityOutputBody xmlns:ns=\"urn:a\">"
                + "<p:UpdateOfferRes xmlns:p=\"urn:b\"><p:ResponseCode>A</p:ResponseCode><p:ResponseText>uno</p:ResponseText></p:UpdateOfferRes>"
                + "<p:UpdateOfferRes xmlns:p=\"urn:b\"><p:ResponseCode>B</p:ResponseCode><p:ResponseText>dos</p:ResponseText></p:UpdateOfferRes>"
                + "</ns:ActivityOutputBody>";

        // When / Then
        assertThat(mapper.fromReplies(xml)).extracting(UpdateOfferResponse::getCode).containsExactly("A", "B");
    }

    @Test
    void unSoloUpdateOfferRes_devuelveUnaRespuesta() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        List<UpdateOfferResponse> r = mapper.fromReplies(
                "<UpdateOfferRes><ResponseCode>COP_UPDOF_0</ResponseCode><ResponseText>ok</ResponseText></UpdateOfferRes>");

        // Then
        assertThat(r).hasSize(1);
        assertThat(r.get(0).getCode()).isEqualTo("COP_UPDOF_0");
    }

    @Test
    void sinUpdateOfferRes_seLeeComoUnaSolaRespuesta() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        List<UpdateOfferResponse> r = mapper.fromReplies(RESPUESTA_REAL);

        // Then
        assertThat(r).hasSize(1);
        assertThat(r.get(0).getCode()).isEqualTo("COP_UPDOF_0");
        assertThat(r.get(0).getContextType()).hasSize(2);
    }

    @Test
    void respuestaJson_seTrataComoUna() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        List<UpdateOfferResponse> r = mapper.fromReplies("{\"code\":\"COP_UPDOF_0\",\"description\":\"ok\"}");

        // Then
        assertThat(r).hasSize(1);
        assertThat(r.get(0).getCode()).isEqualTo("COP_UPDOF_0");
    }

    @Test
    void respuestaVaciaOMalFormada_lanzaIllegalState() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        org.assertj.core.api.Assertions.assertThatThrownBy(() -> mapper.fromReplies(" "))
                .isInstanceOf(IllegalStateException.class);
        org.assertj.core.api.Assertions.assertThatThrownBy(() -> mapper.fromReplies("<UpdateOfferRes>"))
                .isInstanceOf(IllegalStateException.class);
    }
}
