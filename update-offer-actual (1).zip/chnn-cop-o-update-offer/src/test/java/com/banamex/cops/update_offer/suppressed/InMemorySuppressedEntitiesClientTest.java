package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/** Borra este archivo si borraste InMemorySuppressedEntitiesClient (te quedas con SharedVariable...). */
class InMemorySuppressedEntitiesClientTest {

    private final InMemorySuppressedEntitiesClient client = new InMemorySuppressedEntitiesClient();

    @Test
    void alInicioLaListaEstaVacia() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(client.getListOfSuppressedEntities(null).getSuppressedEntities()).isEmpty();
    }

    @Test
    void refreshReemplazaLaLista() {
        // Given
        SuppressedEntitiesListRoot nueva = new SuppressedEntitiesListRoot();

        // When
        client.refresh(nueva);

        // Then
        assertThat(client.getListOfSuppressedEntities(null)).isSameAs(nueva);
    }

    @Test
    void refreshConNullDejaUnaListaVaciaEnLugarDeNull() {
        // Given
        // (sin precondiciones)

        // When
        client.refresh(null);

        // Then
        assertThat(client.getListOfSuppressedEntities(null)).isNotNull();
        assertThat(client.getListOfSuppressedEntities(null).getSuppressedEntities()).isEmpty();
    }
}
