package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.log.header.ClientDetailsDTO;
import com.banamex.cops.update_offer.dto.log.header.RqHeaderDTO;
import com.banamex.cops.update_offer.testutil.TestData;
import com.banamex.cops.update_offer.validation.DtoValidator;
import jakarta.validation.Validation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.TreeMap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Pruebas unitarias de {@code RqHeaderFactory}.
 * <p>
 * Casos cubiertos: uuid; lo que sale de los headers del swagger; lo que sale del yml (el swagger no trae headers); ESBUUID y fecha (se generan); validación del esquema.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class RqHeaderFactoryTest {

    private RqHeaderFactory factory;

    @BeforeEach
    void setUp() {
        factory = new RqHeaderFactory(new DtoValidator(Validation.buildDefaultValidatorFactory().getValidator()));
        ReflectionTestUtils.setField(factory, "version", "3.0");
        ReflectionTestUtils.setField(factory, "org", "Banamex");
        ReflectionTestUtils.setField(factory, "orgUnit", "COPS");
        ReflectionTestUtils.setField(factory, "terminalId", "1");
        ReflectionTestUtils.setField(factory, "userId", "ATM");
    }

    private UpdateOfferHeaders swagger() {
        return UpdateOfferHeaders.builder().uuid("uuid-1").channelId("CAT").countryCode("MX")
                .businessCode("COP").sid("sid-1").host("api.test").acceptLanguage("es-MX").build();
    }

    // ------------------------------------------------------------ uuid

    @Test
    void sinUuid_lanzaInvalidRqHeaderException() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThatThrownBy(() -> factory.create(new UpdateOfferHeaders()))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("uuid");
    }

    @Test
    void uuidEnBlanco_tambienSeRechaza() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThatThrownBy(() -> factory.create(UpdateOfferHeaders.builder().uuid("  ").build()))
                .isInstanceOf(InvalidRqHeaderException.class);
    }

    @Test
    void elUuidSeToma_delHeader_yNoSeGenera() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.create(swagger()).getUuid()).isEqualTo("uuid-1");
    }

    // ------------------------------------------------------------ lo que sale de los headers del swagger

    @Test
    void channelId_vieneDelHeaderChannelId() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.create(swagger()).getClientDetails().getChannelID()).isEqualTo("CAT");
    }

    @Test
    void ambosPaises_vienenDelHeaderCountryCode() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        ClientDetailsDTO c = factory.create(swagger()).getClientDetails();

        // Then
        assertThat(c.getSrcCountryCode()).isEqualTo("MX");
        assertThat(c.getDestCountryCode()).isEqualTo("MX");
    }

    @Test
    void idioma_seDerivaDeAcceptLanguage() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.create(swagger()).getClientDetails().getSessionLanguageCode()).isEqualTo("ES");

        UpdateOfferHeaders h = swagger();
        h.setAcceptLanguage("en-US,en;q=0.9");
        assertThat(factory.create(h).getClientDetails().getSessionLanguageCode()).isEqualTo("EN");
    }

    @Test
    void sinAcceptLanguage_elIdiomaQuedaNulo() {
        // Given
        UpdateOfferHeaders h = swagger();
        h.setAcceptLanguage(null);

        // When / Then
        assertThat(factory.create(h).getClientDetails().getSessionLanguageCode()).isNull();
    }

    // ------------------------------------------------------------ lo que sale del yml (el swagger no trae headers)

    @Test
    void orgOrgUnitTerminalIdUserIdYVersion_vienenDelYml() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        RqHeaderDTO h = factory.create(swagger());

        // Then
        assertThat(h.getClientDetails().getOrg()).isEqualTo("Banamex");
        assertThat(h.getClientDetails().getOrgUnit()).isEqualTo("COPS");
        assertThat(h.getClientDetails().getTerminalID()).isEqualTo("1");
        assertThat(h.getClientDetails().getUserID()).isEqualTo("ATM");
        assertThat(h.getVersion()).isEqualTo("3.0");
    }

    @Test
    void losOtrosHeadersQueLleguen_noAlimentanElRqHeader() {
        // Given
        Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        all.put("Org", "Citi");
        all.put("OrgUnit", "Otra");
        all.put("TerminalID", "9999");
        all.put("UserID", "MV00928");
        all.put("Version", "9.9");
        all.put("ESBUUID", "otro-esb");
        all.put("DateAndTimeStamp", "2020-01-01T00:00:00");
        UpdateOfferHeaders h = swagger();
        h.setAll(all);

        // When
        RqHeaderDTO rq = factory.create(h);

        // Then
        assertThat(rq.getClientDetails().getOrg()).isEqualTo("Banamex");
        assertThat(rq.getClientDetails().getOrgUnit()).isEqualTo("COPS");
        assertThat(rq.getClientDetails().getTerminalID()).isEqualTo("1");
        assertThat(rq.getClientDetails().getUserID()).isEqualTo("ATM");
        assertThat(rq.getVersion()).isEqualTo("3.0");
        assertThat(rq.getEsbUuid()).startsWith("uuid-1").isNotEqualTo("otro-esb");
        assertThat(rq.getDateTimeStamp().getYear()).isNotEqualTo(2020);
    }

    @Test
    void sinVersionEnElYml_elVersionQuedaNulo() {
        // Given
        ReflectionTestUtils.setField(factory, "version", "");

        // When / Then
        assertThat(factory.create(swagger()).getVersion()).isNull();
    }

    @Test
    void losOpcionalesDeClientDetailsQueElSwaggerNoTrae_quedanNulos() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        ClientDetailsDTO c = factory.create(swagger()).getClientDetails();

        // Then
        assertThat(c.getClientIPAddress()).isNull();
        assertThat(c.getUserDomicileBranchCode()).isNull();
        assertThat(c.getUserDomicileResponsibilityCentre()).isNull();
        assertThat(c.getProcessingBranchCode()).isNull();
        assertThat(c.getProcessingResponsibilityCentre()).isNull();
        assertThat(c.getUserGroup()).isNull();
    }

    // ------------------------------------------------------------ ESBUUID y fecha (se generan)

    @Test
    void esbUuid_seGeneraComoUuidMasFecha() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.create(swagger()).getEsbUuid()).matches("uuid-1\\d{14}");
    }

    @Test
    void fecha_esLaHoraActual() {
        // Given
        LocalDateTime antes = LocalDateTime.now().minusSeconds(1);

        // When
        LocalDateTime fecha = factory.create(swagger()).getDateTimeStamp();

        // Then
        assertThat(fecha).isAfterOrEqualTo(antes).isBeforeOrEqualTo(LocalDateTime.now().plusSeconds(1));
    }

    // ------------------------------------------------------------ validación del esquema

    @Test
    void sinChannelIdNiCountryCode_seRechazaConElDetalle() {
        // Given
        UpdateOfferHeaders h = UpdateOfferHeaders.builder().uuid("uuid-1").build();

        // When / Then
        assertThatThrownBy(() -> factory.create(h))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("clientDetails.channelID")
                .hasMessageContaining("clientDetails.srcCountryCode")
                .hasMessageContaining("clientDetails.destCountryCode");
    }

    @Test
    void siFaltaUnValorObligatorioDelYml_seRechazaNombrandoCual() {
        // Given
        ReflectionTestUtils.setField(factory, "org", "");
        ReflectionTestUtils.setField(factory, "terminalId", " ");

        // When / Then
        assertThatThrownBy(() -> factory.create(swagger()))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("RqHeaderDTO")
                .hasMessageContaining("clientDetails.org")
                .hasMessageContaining("clientDetails.terminalID");
    }

    @Test
    void userIdVacioEnElYml_esValido_porqueElElementoSoloDebeExistir() {
        // Given
        ReflectionTestUtils.setField(factory, "userId", "");

        // When / Then
        assertThat(factory.create(swagger()).getClientDetails().getUserID()).isEmpty();
    }

    @Test
    void conLosHeadersDeLaLlamadaDePrueba_noFalla() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        RqHeaderDTO h = factory.create(TestData.headers());

        // Then
        assertThat(h.getUuid()).isEqualTo("uuid-1");
        assertThat(h.getClientDetails().getChannelID()).isEqualTo("CAT");
        assertThat(h.getClientDetails().getSessionLanguageCode()).isEqualTo("ES");
    }
}
