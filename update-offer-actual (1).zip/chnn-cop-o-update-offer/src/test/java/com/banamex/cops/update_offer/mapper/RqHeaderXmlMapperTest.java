package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.log.header.RqHeaderDTO;
import com.banamex.cops.update_offer.testutil.TestData;
import com.banamex.cops.update_offer.testutil.XmlTestUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias de {@code RqHeaderXmlMapper}.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class RqHeaderXmlMapperTest {

    private final RqHeaderXmlMapper mapper = new RqHeaderXmlMapper();

    @Test
    void envelopeHeader_traeLosDatosYNoTieneUrls() {
        // Given
        // (sin precondiciones)

        // When
        String xml = mapper.toEnvelopeHeader(TestData.rqHeader(), "");

        // Then
        assertThat(xml).contains("<RqHeader>", "</RqHeader>",
                "<DateAndTimeStamp>2026-10-26T10:54:55.852</DateAndTimeStamp>",
                "<UUID>uuid-1</UUID>", "<ESBUUID>uuid-120261026105455</ESBUUID>", "<Version>3.0</Version>",
                "<Org>Banamex</Org>", "<ChannelID>CAT</ChannelID>", "<UserID>ATM</UserID>",
                "<SrcCountryCode>MX</SrcCountryCode>", "<SessionLanguageCode>ES</SessionLanguageCode>");
        assertThat(XmlTestUtil.hasUrls(xml)).isFalse();
        XmlTestUtil.parse(xml);
    }

    @Test
    void envelopeHeader_omiteLosOpcionalesNulos() {
        // Given
        // (sin precondiciones)

        // When
        String xml = mapper.toEnvelopeHeader(TestData.rqHeader(), "");

        // Then
        assertThat(xml).doesNotContain("ClientIPAddress", "UserGroup", "UserDomicileBranchCode");
    }

    @Test
    void envelopeHeader_sinClientDetailsNoEscribeEseNodo() {
        // Given
        RqHeaderDTO h = TestData.rqHeader();
        h.setClientDetails(null);

        // When
        String xml = mapper.toEnvelopeHeader(h, "");

        // Then
        assertThat(xml).doesNotContain("ClientDetails");
        XmlTestUtil.parse(xml);
    }

}
