# Variables globales de BW que usa el código (con los valores reales)

Valores tomados de tu archivo `VARIABLES GLOBALES.txt`. Ya están en `update-offer.yml`.

## 1. Globales usadas y aplicadas

| # | Variable global de BW | Valor en BW | Propiedad en el yml | Clase Java | Notas |
|---|---|---|---|---|---|
| 1 | `AuditPointsEnabled` | `1001` | `audit.points-enabled: "1001"` | `AuditLogService` | Es una **cadena de banderas**, no un booleano. **Posición 1** = log del request (`substring(x,1,1)="1"`); **posición 4** = log de la respuesta (`substring(x,4,1)="1"`). Con `1001` se registran los dos. Las posiciones 2 y 3 no las usa este micro (otros procesos pueden usarlas) |
| 2 | `ApplicationName` | `cop` | *(ya no se usa)* | — | Ya no va en el log ni arma la cola (la cola es fija) |
| 3 | `Application_CSI_ID` | `163621` | *(ya no se usa)* | — | Ya no va en el log ni arma la cola (la cola es fija) |
| 4 | `ComponentName` | `COPS` | *(ya no se usa)* | — | El log ya no lleva el header de BW (`ComponentName`) |
| 5 | `RequestTimeout_Category1` | `7` | `update-offer.ems.timeout-seconds: 7` | `EmsSender` | Segundos |
| 6 | `JMSExpiration` | `30` | `update-offer.ems.time-to-live-ms: 0` | `EmsSender` | **No lo apliqué:** en BW el campo va en milisegundos, y 30 ms haría expirar el mensaje antes de llegar. Ver pendiente 1 |
| 7 | `PadCharacter` | `0` | `update-offer.jms-requestor.customer-padding-char: "0"` | `OfferEventMapper` | |
| 8 | `TranslateTimeZone` | `false` | `update-offer.timezone.translate-time-zone: false` | `UpdateOfferServiceImpl`, `OfferEventMapper` | |
| 9 | `ECRMTimeZone` | `US/Central` | `update-offer.timezone.ecrm-time-zone: US/Central` | `TimeZoneMapRequest`, `OfferEventMapper` | Antes tenía `America/Mexico_City`. Ver pendiente 2 |
| 10 | `TimeZoneDateTimeFormat` | `yyyy-MM-dd'T'HH:mm:ssZ` | `update-offer.timezone.time-zone-date-time-format` | `TimeZoneMapRequest` | |
| 11 | `BETimeFormat` | `HH:mm:ss` | `update-offer.timezone.be-time-format` | `TimeZoneMapRequest` | |
| 12 | `BEDateTimeFormat` | `yyyy-MM-dd HH:mm:ss` | `update-offer.timezone.be-date-time-format` | `TimeZoneMapRequest` | Antes tenía un formato con `T` y offset |
| 13 | `CheckForSuppression` | `N` | `cop.suppression.check-for-suppression: "N"` | `PerformSuppressionCheckService` | Con `N` no se consulta la supresión |
| 14 | `EHKafkaUpdate_Delay` | `200` | `offer.kafka.delay-ms: 200` | `FulFillkafkaSender` | Milisegundos |
| 15 | `isKafkaOn_1` | `true` | `offer.kafka.enabled: true` | `UpdateOfferServiceImpl` | Condición de la transición hacia Kafka. Con `mode: dry-run` solo escribe el JSON en el log |
| 16 | `COP/Padding/CustomerPadding` | `false` | `update-offer.jms-requestor.customer-padding: false` | `OfferEventMapper` | **No se rellena** `CustomerNO`: va como llega |
| 17 | `COP/Padding/CustomerNo` | `19` | `update-offer.jms-requestor.customer-padding-length: 19` | `OfferEventMapper` | Longitud del `pad-front`; solo aplica si el relleno está activo |

## 2. La cola del EMS

Las globales `sector`, `Business`, `Región`, `ApplicationName`, `Application_CSI_ID`, `BankCardEnv` y `UpdateOffer` forman en BW el `destinationQueue` con un `concat`. El micro **no arma la cola**: usa una sola, fija, que es el resultado de ese `concat` en tu broker:

`update-offer.ems.queue: citi.gcg.la.cop_163621.mx_card.offer.update`

La misma cola alimenta la configuración de la librería EMS (`queues-config`). Esas siete globales ya no se usan en el código.

## 3. Globales del código que **no** vienen en tu lista

| Variable | Dónde se usa | Valor actual | Qué hacer |
|---|---|---|---|
| `COP/Connections/JSON/updateoffer` | `SetContext` y camino REST/JSON del backend | **`Y` (valor confirmado). El micro no hace ese camino.** Ver `pendientes-y-suposiciones.md`, sección D3 | Pasar la configuración de `Invoke-REST` |
| `AbInitioTest` | Mapper final de `OpUpdateOffer`: si es `Y`, la respuesta sale de AbInitio | No se usa (AbInitio no se migró) | Pasar su valor |
| `COP/ParametricConfiguration/CounterOfferAvailUpdate` | Mapper final de `OpUpdateOffer`, junto con `OfferStatus = "U"` | **`Y` (valor confirmado).** No se usa todavía (Caso 2 sin migrar) | Ver sección D2 |

## 4. No se usan en el código

| Variable | Motivo |
|---|---|
| `BEDateFormat` (`yyyy-MM-dd`) | La fecha del Request solo se reformatea con `DateFormat`; no se necesita |
| `update-offer.logging.*` del yml | Era de `LogRequestService`; se reemplazó por `AuditLogService` |

## 5. Valores fijos del código que no son globales

| Valor | Origen en BW | Propiedad |
|---|---|---|
| `UpdateOffer` | `_nm_` (nombre del evento) | `update-offer.ems.body-element` |
| `Fulfillrequest`, `1.0`, `163621`, `MX`, `DM` | Constantes del header del evento de Kafka (tomadas del ejemplo) | `offer.kafka.event-name`, `event-version`, `producer-csi`, `country-code`, `business-code` |
