-- ============================================================================
-- Cómo encontrar una campaña / oferta REAL para probar el micro contra el EMS.
-- Corre cada bloque por separado en tu cliente SQL con la conexión UAT del yml.
-- Los nombres de tablas y columnas salen de la consulta de Kafka (D_CAMPAIGN, D_OFFERPALETTE,
-- D_WAVECHINFO, D_PRODUCT): si alguno marca ORA-00942 o ORA-00904, usa los bloques 1 y 2 para ver los reales.
-- Si las tablas están en otro esquema, antepón el dueño (ESQUEMA.D_CAMPAIGN).
-- ============================================================================

-- 1) ¿En qué esquema están las tablas?
SELECT owner, table_name
  FROM all_tables
 WHERE table_name IN ('D_CAMPAIGN', 'D_OFFERPALETTE', 'D_WAVECHINFO', 'D_PRODUCT');

-- 2) ¿Cómo se llaman las columnas de campañas? (por si cambia algún nombre)
SELECT column_name, data_type
  FROM all_tab_columns
 WHERE table_name = 'D_CAMPAIGN'
 ORDER BY column_id;

-- 3) Campañas que existen. CMPID es el valor que va en "campaignId" del request.
SELECT cmpid FROM D_CAMPAIGN WHERE ROWNUM <= 30;

-- 3b) Buscar una campaña por parte del nombre
SELECT cmpid FROM D_CAMPAIGN WHERE UPPER(cmpid) LIKE '%SPEI%';

-- 4) Ofertas reales más recientes, ya separadas en los datos que pide el request.
--    EXTID$ = off:mx:CAMPAÑA:OLA:CLIENTE[:CUENTA[:TARJETA]]
SELECT *
  FROM (SELECT EXTID$,
               REGEXP_SUBSTR(EXTID$, '[^:]+', 1, 3) AS campaign_id,
               REGEXP_SUBSTR(EXTID$, '[^:]+', 1, 4) AS wave_id,
               REGEXP_SUBSTR(EXTID$, '[^:]+', 1, 5) AS customer_id,
               REGEXP_SUBSTR(EXTID$, '[^:]+', 1, 6) AS account_number,
               REGEXP_SUBSTR(EXTID$, '[^:]+', 1, 7) AS card_number,
               OFFERCREATIONDATE_TM
          FROM D_OFFERPALETTE
         ORDER BY OFFERCREATIONDATE_TM DESC)
 WHERE ROWNUM <= 10;

-- 5) Ofertas de una campaña concreta (cambia el nombre)
SELECT EXTID$ FROM D_OFFERPALETTE WHERE campaignid = 'DIS_SPEI I 26 INC' AND ROWNUM <= 10;

-- 6) Ofertas del log de BW que te pasaron: ¿existen en este ambiente?
SELECT EXTID$
  FROM D_OFFERPALETTE
 WHERE EXTID$ IN ('off:mx:TOP UP SUCCANDIGI:GSA3FADLQR:000601149',
                  'off:mx:3 CLICKS 2:GIBP4Q63CV:000601149',
                  'off:mx:RETAILRS25:RH52KYVD39:116740699',
                  'off:mx:PAYPIL2026:II8E98ULMK:116764778',
                  'off:mx:OFERTA 5 PIN II:R2IALSY655:157729190',
                  'off:mx:INCLINIVR:O2GZYDHD9L:116727374');

-- 7) Olas y canales (para elegir un "channelCode" que corresponda a la ola)
SELECT EXTID$ FROM D_WAVECHINFO WHERE ROWNUM <= 20;

-- 8) Comprobar que UNA oferta concreta existe (pega el EXTID$ completo)
SELECT COUNT(*) AS existe FROM D_OFFERPALETTE WHERE EXTID$ = 'off:mx:CAMPAÑA:OLA:CLIENTE';
