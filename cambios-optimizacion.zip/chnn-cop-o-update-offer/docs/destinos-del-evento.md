# Destinos del evento (Kafka y EMS alterno)

El micro arma el evento (JSON) una vez y lo manda a cada destino activo. Cada destino se prende y apaga en el yml.

| Destino | Interruptor | Conexión | Cola |
|---|---|---|---|
| Kafka (bridge) | `offer.kafka.bridge-enabled` (hoy `false`) | `updateOfferJmsTemplate` (el EMS de siempre) | `offer.kafka.queue` |
| EMS alterno | `offer.alternate-ems.enabled` (hoy `true`) | `alternateEmsJmsTemplate` (plataforma `banamex-cops-alterno`) | `offer.alternate-ems.queue` |

- `offer.kafka.enabled: false` apaga el evento completo. `offer.kafka.mode: dry-run` solo escribe en el log, en todos los destinos.
- Si un destino falla, el otro se envía igual. La respuesta del micro no cambia.
- Logs: `[EMS-ALTERNO] Envía` / `[EMS-ALTERNO] Resultado: …`, `[KAFKA] Resultado: …`; con los dos activos, `[KAFKA+EMS-ALTERNO] Envía`.

## Cola y conexión del EMS alterno

La cola es `citi.gcg.la.cop_163621.mx_dm.raw.cops-offer-fulfillment-req` (en minúsculas: el EMS distingue mayúsculas). Kafka usa la misma: **no prendas los dos destinos a la vez**, o el evento llega dos veces a esa cola.

La conexión usa la misma URL, usuario, contraseña y certificado que la principal (los toma con `${...}` de la conexión principal y de `broker-config`).

## El evento no depende de la respuesta del EMS

El evento se arma y se envía aunque el EMS no conteste o falle. Si el EMS contestó, `ResponseCode` y `ResponseText` van en el evento; si no, esos dos campos no aparecen.

Si la consulta a la base no trae la oferta, el evento se envía igual con los campos de la base vacíos (`offer.kafka.send-without-db-rows: true`). Con `false`, no se envía y el log dice `KAFKA-NO-ROWS`.

## Bean `alternateEmsJmsTemplate`

Lo crea `JmsConfig` (`alternateEmsConnectionFactory` y `alternateEmsJmsTemplate`), solo si `offer.alternate-ems.enabled` es `true`. Busca en el yml la conexión cuyo `jmsTemplateName` es `alternateEmsJmsTemplate` y se crea hasta el primer envío: si faltan datos del EMS alterno, la app arranca igual.
