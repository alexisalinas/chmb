package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.mapper.XmlUtil;
import jakarta.jms.DeliveryMode;
import jakarta.jms.MessageProducer;
import jakarta.jms.TextMessage;
import org.springframework.jms.core.JmsTemplate;

import java.util.function.Supplier;

/** Deja el evento en una cola JMS: la del bridge de Kafka o la del EMS alterno. */
public class JmsOfferPublisher implements OfferPublisher {

    private final Supplier<JmsTemplate> jms;
    private final String queue;
    private final String messageFormat;
    private final long timeToLiveMs;

    /** El JmsTemplate se pide al publicar, así la conexión solo se crea si el destino se usa. */
    public JmsOfferPublisher(Supplier<JmsTemplate> jms, String queue, String messageFormat, long timeToLiveMs) {
        this.jms = jms;
        this.queue = queue;
        this.messageFormat = messageFormat;
        this.timeToLiveMs = timeToLiveMs;
    }

    /** Envía el JSON tal cual o dentro de {@code <root><RefId/><jsonString/></root>} (formato envelope). */
    @Override
    public String publish(String refId, String json) throws Exception {
        if (queue == null || queue.isBlank()) {
            throw new IllegalStateException("no hay cola configurada para este destino");
        }
        String body = "envelope".equalsIgnoreCase(messageFormat)
                ? "<root><RefId>" + XmlUtil.esc(refId) + "</RefId><jsonString>" + XmlUtil.esc(json) + "</jsonString></root>"
                : json;
        return jms.get().execute(session -> {
            try (MessageProducer producer = session.createProducer(session.createQueue(queue))) {
                TextMessage message = session.createTextMessage(body);
                message.setJMSCorrelationID(refId);
                message.setStringProperty("RefId", refId);
                producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
                if (timeToLiveMs > 0) {
                    producer.setTimeToLive(timeToLiveMs);
                }
                producer.send(message);
                return message.getJMSMessageID();
            }
        }, true);
    }
}
