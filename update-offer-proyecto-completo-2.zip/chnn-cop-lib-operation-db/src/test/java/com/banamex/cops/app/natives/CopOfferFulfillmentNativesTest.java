package com.banamex.cops.app.natives;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code CopOfferFulfillmentNatives}. */
class CopOfferFulfillmentNativesTest {

    private final String sql = CopOfferFulfillmentNatives.FIND_BY_WAVE_KEY_AND_OFFER_KEY;

    @Test
    void traeLas100ColumnasDeUserField() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(sql.split("D_OFFERPALETTE\\.USERFIELD_", -1).length - 1).isEqualTo(100);
        assertThat(sql).contains("D_OFFERPALETTE.USERFIELD_1,", "D_OFFERPALETTE.USERFIELD_100");
    }

    @Test
    void usaLasTablasYLasUnionesDelModelo() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(sql).contains("FROM D_OFFERPALETTE, D_CAMPAIGN, D_PRODUCT, D_WAVECHINFO",
                "D_OFFERPALETTE.CAMPAIGNID = D_CAMPAIGN.CMPID", "D_CAMPAIGN.PRDCODE = D_PRODUCT.PRDCODE");
    }

    @Test
    void soloSeleccionaColumnas_sinCalculosNiFunciones() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(sql).doesNotContain("to_char", "TO_CHAR", "* 1440", "AS APPTENDTIMEDUR");
        assertThat(sql).contains("D_OFFERPALETTE.APPTSTARTDATE_TM, D_OFFERPALETTE.APPTENDDATE_TM");
    }

    @Test
    void tieneDosParametrosPosicionalesEnElOrdenWaveKeyYOfferKey() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(sql.chars().filter(c -> c == '?').count()).isEqualTo(2);
        assertThat(sql).endsWith("D_WAVECHINFO.EXTID$ = ? AND D_OFFERPALETTE.EXTID$ = ?");
    }

    @Test
    void traeLasColumnasDeProductoYFechas() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(sql).contains("D_WAVECHINFO.CRPCATEGORYID", "D_CAMPAIGN.PRDTYPE", "D_OFFERPALETTE.REASONCODE",
                "D_OFFERPALETTE.REASONDESC", "D_PRODUCT.DESCRIPTION", "D_CAMPAIGN.FULFILLMENTPROCID",
                "D_OFFERPALETTE.EXPIRYDATE_TM", "D_OFFERPALETTE.OFFERCREATIONDATE_TM", "D_PRODUCT.PRDCODE",
                "D_PRODUCT.PRDFAMILY", "D_OFFERPALETTE.AVAILABILITY");
    }
}
