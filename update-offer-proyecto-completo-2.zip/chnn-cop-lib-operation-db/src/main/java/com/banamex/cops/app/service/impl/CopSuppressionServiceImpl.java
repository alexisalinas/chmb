package com.banamex.cops.app.service.impl;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.repository.CopSuppressionRepository;
import com.banamex.cops.app.service.CopSuppressionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Implementación de {@link CopSuppressionService}: delega las consultas en el repositorio. */
@Service
@RequiredArgsConstructor
public class CopSuppressionServiceImpl implements CopSuppressionService {

    private final CopSuppressionRepository repository;

    /** {@inheritDoc} */
    @Override
    public List<CopSuppressionChannel> findAllChannels(int timeoutSeconds, int maxRows) {
        return repository.findAllChannels(timeoutSeconds, maxRows);
    }

    /** {@inheritDoc} */
    @Override
    public List<CopSuppressionOperation> findAllOperations(int timeoutSeconds, int maxRows) {
        return repository.findAllOperations(timeoutSeconds, maxRows);
    }
}
