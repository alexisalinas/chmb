package com.banamex.cops.app.model;

/**
 * Una fila de {@code COP_SUPP_CHNL}: la supresión de un canal (consulta {@code FetchChannels} del proceso de BW
 * {@code /BW/StartUp/startUpSuppression}).
 */
public record CopSuppressionChannel(String countryCode,
                                    String reqMode,
                                    String channelId,
                                    String suppressionFlag,
                                    String operationFlag,
                                    String sourceSystem) {
}
