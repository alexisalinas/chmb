package com.banamex.cops.app.model;

import java.sql.Timestamp;
import java.util.List;

/** Datos de cumplimiento (fulfillment) de una oferta. */
public record CopOfferFulfillment(
        String crpCategoryId,
        String prdType,
        String reasonCode,
        String reasonDesc,
        String prdDescription,
        String fulfillmentProcId,
        List<String> userFields,
        Timestamp apptStartDate,
        Timestamp apptEndDate,
        Timestamp expiryDate,
        Timestamp offerCreationDate,
        String prdCode,
        String prdFamily,
        String availability) {
}
