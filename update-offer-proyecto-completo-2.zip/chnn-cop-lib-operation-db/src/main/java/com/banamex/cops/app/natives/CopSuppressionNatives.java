package com.banamex.cops.app.natives;

/** Queries nativos de la lista de entidades suprimidas. */
public final class CopSuppressionNatives {

    private CopSuppressionNatives() {
    }

    /** {@code FetchChannels}: todos los canales con su supresión. */
    public static final String FIND_ALL_CHANNELS = "SELECT * FROM COP_SUPP_CHNL";

    /** {@code FetchOperations}: todas las operaciones suprimidas por canal. */
    public static final String FIND_ALL_OPERATIONS = "SELECT * FROM COP_SUPP_OPR";
}
