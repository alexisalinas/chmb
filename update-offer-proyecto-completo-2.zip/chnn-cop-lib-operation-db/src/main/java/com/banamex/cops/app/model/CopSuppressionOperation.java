package com.banamex.cops.app.model;

/** Una fila de {@code COP_SUPP_OPR}. */
public record CopSuppressionOperation(String operationName,
                                      String operationSuppressFlag,
                                      String reqChannel) {
}
