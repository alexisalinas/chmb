package com.banamex.cops.app.service;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;

import java.util.List;

/** Servicio de consulta de los datos de supresión (canales y operaciones suprimidas). */
public interface CopSuppressionService {

    /** Todos los canales con su supresión (consulta {@code FetchChannels}, solo lectura). */
    List<CopSuppressionChannel> findAllChannels(int timeoutSeconds, int maxRows);

    /** Todas las operaciones suprimidas por canal (consulta {@code FetchOperations}, solo lectura). */
    List<CopSuppressionOperation> findAllOperations(int timeoutSeconds, int maxRows);
}
