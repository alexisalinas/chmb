package com.banamex.cops.app.service;

import com.banamex.cops.app.model.CopOfferFulfillment;

import java.util.List;

/** Servicio de consulta de los datos de cumplimiento (fulfillment) de una oferta. */
public interface CopOfferFulfillmentService {

    /** Datos de cumplimiento de una oferta (consulta de solo lectura). */
    List<CopOfferFulfillment> findByWaveKeyAndOfferKey(String waveKey, String offerKey);
}
