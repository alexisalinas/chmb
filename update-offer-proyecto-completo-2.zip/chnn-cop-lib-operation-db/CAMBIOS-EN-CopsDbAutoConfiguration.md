# Registro de las clases de la consulta de Kafka

**Ya no hace falta tocar `CopsDbAutoConfiguration`.** El micro registra las dos clases con su propia configuración
(`OfferFulfillmentConfig`), usando el `spring.datasource` del yml:

- `CopOfferFulfillmentRepository` y `CopOfferFulfillmentServiceImpl`
- `CopSuppressionRepository` y `CopSuppressionServiceImpl`

La librería solo tiene que contener las clases de las consultas: las cinco de cumplimiento (`CopOfferFulfillment`,
`CopOfferFulfillmentNatives`, `CopOfferFulfillmentRepository`, `CopOfferFulfillmentService` y
`CopOfferFulfillmentServiceImpl`) y las de supresión (`CopSuppressionChannel`, `CopSuppressionOperation`,
`CopSuppressionNatives`, `CopSuppressionRepository`, `CopSuppressionService` y `CopSuppressionServiceImpl`), instalarse con `mvn clean install -DskipTests` y estar en el classpath del micro.

## Si prefieres que la registre la librería

Agrégalas al `@Import` de `CopsDbAutoConfiguration`, junto a las de `CopTimezoneLookup`:

```java
@Import({
    // ...
    CopOfferFulfillmentRepository.class,
    CopOfferFulfillmentServiceImpl.class,
    CopSuppressionRepository.class,
    CopSuppressionServiceImpl.class,
})
```

Puedes dejarlas también en `OfferFulfillmentConfig` del micro: las dos configuraciones **importan las mismas clases** con `@Import`
y Spring las registra una sola vez (con el nombre completo de la clase). Lo que no se debe hacer es declararlas con métodos `@Bean`,
porque eso crea un segundo bean con otro nombre y falla con "expected single matching bean but found 2".
