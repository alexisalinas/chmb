# Cómo correr el micro y ver los logs de cada resultado

> Nada de esto se ha compilado ni ejecutado contra tu ambiente. Lo que sí se revisó: que **todos** los archivos
> (micro, pruebas y librería) pasan el análisis de sintaxis de `javac` y que no hay errores entre las clases propias.
> No se pudo compilar con Spring ni con las demás dependencias.

## 1. Antes de arrancar (una sola vez)

| # | Qué hacer | Dónde |
|---|---|---|
| 1 | Copiar las carpetas del zip a tu proyecto y **borrar** lo que lista `LEEME.txt` | micro y librería |
| 2 | Copiar las 5 clases `CopOfferFulfillment*` a la librería `chnn-cop-lib-operation-db` y `mvn clean install -DskipTests` | librería |
| 3 | `pom.xml` (es el tuyo con lo agregado) y Maven > Update Project con Force Update | micro |
| 4 | La contraseña de `RMXCOP4` ya viene en `application.yml` (`${DB_PASSWORD:...}`). Si defines la variable de entorno **`DB_PASSWORD`**, esa tiene prioridad | `application.yml` / STS > Run Configurations > Environment |
| 5 | Arrancar `UpdateOfferApplication` | STS |

## 2. Configuración (hoy envía de verdad)

Con el yml actual el micro **envía de verdad** al EMS y a la cola de Kafka (actualiza datos en UAT). Para ver los logs sin enviar nada, pon los dos en modo de prueba:

| Propiedad | Valor actual | Para solo ver el log |
|---|---|---|
| `update-offer.ems.dry-run` | `false` (envía al EMS) | `true`: el XML y las propiedades se escriben en el log y **no** se envían; el micro simula la respuesta (`DRY-RUN`) |
| `offer.kafka.mode` | `jms` (publica en la cola de Kafka) | `dry-run`: el JSON se escribe en el log y **no** se publica |
| `offer.kafka.enabled` | `true` | Se arma el evento de Kafka |
| `update-offer.ems.message-format` | `both` | El mensaje JMS lleva el XML en el cuerpo **y** las propiedades (`OtherProperties`) |
| `update-offer.timezone.translate-time-zone` | `true` | Con la tabla `COP_TIMEZONE_LOOKUP` vacía: `COP_TZCOD_114` y sigue sin convertir |

## 3. Correr cada escenario con SoapUI

1. En SoapUI: **File > Import Project** y elige `pruebas/UpdateOffer-soapui-project.xml`.
2. Verás el proyecto `UpdateOffer` con la petición `POST http://localhost:8080/sd-campaing-management/v1/update-offer` y **9 peticiones** ya armadas (cuerpo y headers). Si tu micro corre en otro puerto, cambia el *endpoint* de la petición.
3. Abre una petición y pulsa **Submit**. Los logs salen en la consola de STS.

| Petición | Qué prueba | Qué debes ver |
|---|---|---|
| `01 BW real - PLT (2 ofertas)` | Las dos ofertas reales de tu log de BW, canal `PLT` y `client_id` `92023797` | Un `[REQUEST]` y un `[RESPONSE]` con dos respuestas; `[EMS]` y `[KAFKA]` por cada oferta |
| `02 BW real - CI` | Oferta real (`PAYPIL2026`), canal `CI`, `client_id` `MV00928` | Igual, con una oferta |
| `03 BW real - CK` | Oferta real (`OFERTA 5 PIN II`), canal `CK`, `client_id` `SYSTEM` | Igual |
| `04 BW real - IVR (sin client_id)` | Oferta real (`INCLINIVR`), canal `IVR`, sin `client_id` | `UpdatedBy` va vacío en el mensaje al EMS |
| `05 Estatus U` | `OfferStatus = "U"` | Respuesta con la llave `off:mx:...` y **sin fecha** |
| `06 Dos ofertas` | Dos ofertas, una `U` | Un solo `[REQUEST]` y un solo `[RESPONSE]` |
| `07 Oferta DYNMCBIRTHWELC` | Oferta real cuya ola no tiene filas | `KAFKA-NO-ROWS` en Kafka |
| `08 Ejemplo CAMP001` | Oferta que no existe en la base | Éxito en la respuesta y `KAFKA-NO-ROWS` |
| `09 Sin uuid` | Falta el header `uuid` | HTTP 400 y ningún `[REQUEST]` |

**Headers de cada petición** (ya vienen puestos; se ven en la pestaña *Headers* de SoapUI): `Accept: application/json`, `uuid` (nuevo en cada envío con `${=java.util.UUID.randomUUID()}`), `ChannelId`, `sid`, `countryCode: MX`, `businessCode: COP`, y opcionales `Accept-Language` y `client_id`. El `Host` lo pone SoapUI.

**Para comparar con BW:** las peticiones `01` a `04` salen de tus logs de BW. En esos logs, BW respondió `COP_UPDOF_0` y `Successfully update offer off:mx:CAMPAÑA:OLA:CLIENTE`, más dos `ControlField` (en `pruebas/request-bw-real.json` está la respuesta de BW de cada caso). Con `update-offer.response.source: ems` el micro devuelve lo que contesta el EMS.

> Estas peticiones **actualizan ofertas reales en UAT** mientras `ems.dry-run` sea `false` y `offer.kafka.mode` sea `jms`.

## 4. Logs esperados (los valores son de ejemplo)

Los logs de `[KAFKA]` salen de **otro hilo** (`offer-fulfillment-1`) unos 200 ms después: suelen aparecer **después** de `[RESPONSE]`.

### 4.1 Éxito, y Kafka no encuentra la oferta (`exito`, `ofertaReal`)

```
[REQUEST] uuid=3f8a1c52-9b7e-4d21-a6c0-5e2f7b9d1a44
{ "headers": { "uuid": "...", "ChannelId": "CAT", "client_id": "client-prueba-1", ... },
  "body": [ { "channelCode": "CAT", "campaignId": "CAMP001", ... "cardNumber": "************5678", ... } ] }

[EMS] dry-run: no se envió. Enviaría a queue=citi.gcg.la.cop_163621.mx_card.offer.update:
<Envelope>
   <Body>
      <UpdateOffer>
         <CampaignID>CAMP001</CampaignID>
         ...
         <UpdatedBy>client-prueba-1</UpdatedBy>
         ...
      </UpdateOffer>
   </Body>
</Envelope>

[RESPONSE] uuid=3f8a1c52-9b7e-4d21-a6c0-5e2f7b9d1a44
[ { "code": "COP_UPDOF_0", "description": "Successfully update offer 2026/11/11 10:30:45" } ]

KAFKA-NO-ROWS uuid=... refId=CAMP001_WAVE01_12345678_00112233445566_1234567812345678 waveKey=wvch:WAVE01:CAT offerKey=off:mx:CAMP001:WAVE01:12345678:00112233445566
[KAFKA] Resultado: Error send offer to Kafka 2026/11/11 10:30:45. Falló en Consulta a la base de datos: no se encontró la oferta (waveKey=wvch:WAVE01:CAT, offerKey=off:mx:CAMP001:WAVE01:12345678:00112233445566)
```

### 4.2 Éxito completo con Kafka (`conOla`, con `kafka.mode: dry-run`)

Cómo distinguir los dos "éxitos": `[RESPONSE]` es **lo que responde el micro** (`Successfully update offer {fecha}`) y `[KAFKA] Resultado` es **lo que pasó con Kafka** (`Successfully send offer to Kafka {fecha}`). Si ves `[KAFKA] Resultado: Kafka desactivado ...`, Kafka no está activo (`offer.kafka.enabled`).

```
[KAFKA] Envía: {"event":{"header":{"name":"Updateofferrequest","version":"1.0","producerCSI":"163621", ... },"body":{"RefID":"...", ... "ResponseCode":"DRY-RUN", ...}}}
[KAFKA] Resultado: Kafka en dry-run: el mensaje no se publicó 2026/11/11 10:30:45
```

Con `ems.dry-run: true` el `ResponseCode` del evento es `DRY-RUN` (respuesta simulada). Con `kafka.mode: jms` la última línea es
`[KAFKA] Resultado: Successfully send offer to Kafka 2026/11/11 10:30:45`.

### 4.2b Cómo se ve el envío al EMS con las propiedades del mensaje

```
[EMS] dry-run: no se envió. Enviaría a queue=citi.gcg.la.cop_163621.mx_card.offer.update:
<Envelope> ... </Envelope>
Propiedades del mensaje (OtherProperties):
  _nm_=UpdateOffer
  _ns_=www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer
  RequestingChannel=CAT
  CampaignID=CAMP001
  ...
  CardNO=************5678
```

Con el formato por defecto (`properties`) el cuerpo sale como `(cuerpo vacío)` y el XML no se envía; con `both` se ve el XML y las propiedades; con `xml` no salen propiedades.

### 4.3 EMS real (`ems.dry-run: false`)

```
[EMS] Envía a queue=citi.gcg.la.cop_163621.mx_card.offer.update:
<Envelope> ... </Envelope>
[EMS] Responde:
<UpdateOfferRes><ResponseCode>COP_UPDOF_0</ResponseCode><ResponseText>Successfully update offer off:mx:...</ResponseText></UpdateOfferRes>
```

Si el EMS no contesta dentro de `timeout-seconds` (7): `[EMS] Responde:\n(sin respuesta)`. La oferta se procesa y el micro responde éxito, pero
`[KAFKA] Resultado: Error send offer to Kafka {fecha}. Falló en Respuesta del JMS: el JMS no devolvió ResponseCode y ResponseText`.

### 4.4 Falla el envío al EMS

```
[EMS] Falló el envío a queue=... Causas: ...
Falló 'Envío al EMS' uuid=...: java.lang.RuntimeException: Error enviando al EMS: ...
[RESPONSE] uuid=...
[ { "code": "ERROR", "description": "Error update offer 2026/11/11 10:30:45. Falló en Envío al EMS: <causa>" } ]
```

No hay logs de `[KAFKA]`: Kafka va después del JMS.

### 4.5 Oferta `U` (`estatusU`)

```
[RESPONSE] uuid=...
[ { "code": "COP_UPDOF_0", "description": "Successfully update offer off:mx:CAMP001_WAVE01_12345678_00112233445566_1234567812345678" } ]
```

### 4.6 Falta un header (`sinUuid`)

```
HeaderValidation: POST /sd-campaing-management/v1/update-offer rechazado (400). Faltan headers requeridos: [uuid]
```

Respuesta HTTP 400:

```json
{ "type": "ERROR", "details": "Missing or invalid Parameters", "code": "InvalidRequest", "location": "header",
  "moreInfo": "Missing required headers: uuid", "uuid": "...", "timestamp": "..." }
```

## 4.7 Supresión (opcional)

Con `cop.suppression.check-for-suppression: "Y"` la primera petición carga la lista de `COP_SUPP_CHNL` y `COP_SUPP_OPR`. Si las tablas o columnas
no existen sale `Error en PerformSuppressionCheck` con el `ORA-...` y el flujo **sigue** (la supresión devuelve una lista vacía y se reintenta en la
siguiente petición). Revisa las tablas antes con `docs/prueba-supresion.sql`.

### 4.8 Si no ves el JSON de Kafka o el de la respuesta

| No ves | Causa más probable | Qué revisar |
|---|---|---|
| `[RESPONSE]` | Tu yml no trae `audit.points-enabled: "1001"` (la posición 4 activa el log de la respuesta) | Ya viene por defecto en `1001`; revisa que tu yml no lo sobrescriba |
| `[KAFKA] Envía` y `[KAFKA] Resultado` | Tu yml no trae el bloque `offer.kafka` o dice `enabled: false` | Ahora sale `[KAFKA] Resultado: Kafka desactivado ...` |
| `[KAFKA] Envía`, pero sí `[KAFKA] Resultado` con error | Falló antes de armar el JSON (no hay oferta en la base, no hubo respuesta del JMS...) | Lee el paso en el mensaje: `Falló en ...` |

## 5. Si algo falla al arrancar

| Error | Causa | Qué hacer |
|---|---|---|
| `required a bean of type '...JsonMapper' that could not be found` | La clase pedía un `JsonMapper` y Spring Boot solo registra un `ObjectMapper` (Jackson 2) | Ya corregido: el código inyecta `ObjectMapper` |
| `No qualifying bean ... NamedParameterJdbcTemplate` o `Failed to obtain JDBC Connection` | Falta `spring.datasource` o `DB_PASSWORD` | Variable `DB_PASSWORD` (usuario `RMXCOP4`) |
| `ORA-01017: invalid username/password` | Las credenciales que usa la ejecución no son las del yml: una variable de entorno (`DB_PASSWORD`, `DB_USER`, `SPRING_DATASOURCE_PASSWORD`…) con otro valor le gana, hay otro archivo de configuración, o el micro sigue leyendo un `application.yml` viejo de `target` | Al arrancar salen dos líneas: `[DB] Configuración: … (fuente: …)` dice **de dónde** sale cada dato y `[DB] Conexión real: …` dice qué usuario y qué longitud de contraseña usa el `DataSource` de verdad. Compáralos con el yml. Si la fuente es `systemEnvironment`, es una variable de entorno. Si la longitud no es 8, no es la contraseña del yml. Prueba también *Project > Clean*. Varios intentos fallidos bloquean la cuenta (`ORA-28000`) |
| `Could not resolve placeholder 'DB_PASSWORD'` | Falta la variable | Definirla en Run Configurations |
| `Not a managed type: class com.banamex.cops.app.entity.CopAccount` | JPA no escanea las entidades de la librería | `@EntityScan` en `UpdateOfferApplication` (ya viene) |
| Errores de compilación | No pude compilar con las dependencias reales | Pásame el archivo y la línea |

## 6. Qué pegarme después de la primera corrida

1. Lo que sale en consola desde `[REQUEST]` hasta `[KAFKA] Resultado` para el escenario `exito`.
2. Lo mismo para `estatusU` y `dosOfertas`.
3. Si hay un error al arrancar o al compilar, el mensaje completo.
