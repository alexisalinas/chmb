-- ============================================================================
-- ¿EXISTEN EN ESTA BASE LAS OFERTAS REALES DE LOS LOGS DE BW?
-- Una sola consulta (F9) con la conexion UAT_COPS. Una fila por oferta.
--   oferta_existe       -> 1 si existe D_OFFERPALETTE.EXTID$ = 'off:mx:CAMPAÑA:OLA:CLIENTE'
--   campana_existe      -> 1 si existe la campaña en D_CAMPAIGN
--   olas_encontradas    -> filas de D_WAVECHINFO cuya clave contiene la ola
--   clave_de_ola_real   -> la(s) clave(s) real(es) de la ola: de aqui se ve el CANAL con el que esta guardada
--   clave_que_busca_el_micro -> 'wvch:OLA:CANAL' (el CANAL es el RequestingChannel de la peticion)
-- Si oferta_existe = 0, Kafka da KAFKA-NO-ROWS (la oferta no esta en esta base).
-- Si la ola esta guardada con otro canal, compara clave_de_ola_real con clave_que_busca_el_micro.
-- ============================================================================
WITH par AS (
  SELECT 'BRANCH' AS canal_peticion, 'TOP UP SUCCANDIGI' AS campana, 'GSA3FADLQR' AS ola, '000601149' AS cliente FROM dual UNION ALL
  SELECT 'BRANCH', '3 CLICKS 2',      'GIBP4Q63CV', '000601149' FROM dual UNION ALL
  SELECT 'ACCOP',  'PAYPIL2026',      'II8E98ULMK', '116764778' FROM dual UNION ALL
  SELECT 'ATM',    'OFERTA 5 PIN II', 'R2IALSY655', '157729190' FROM dual UNION ALL
  SELECT 'IVR',    'INCLINIVR',       'O2GZYDHD9L', '116727374' FROM dual UNION ALL
  SELECT 'CAT',    'DYNMCBIRTHWELC',  'DUNIUWPEMQ', '023810810' FROM dual
)
SELECT par.campana, par.ola, par.cliente,
       (SELECT COUNT(*) FROM D_OFFERPALETTE
         WHERE D_OFFERPALETTE.EXTID$ = 'off:mx:' || par.campana || ':' || par.ola || ':' || par.cliente)  AS oferta_existe,
       (SELECT COUNT(*) FROM D_CAMPAIGN
         WHERE D_CAMPAIGN.CMPID = par.campana)                                                            AS campana_existe,
       (SELECT COUNT(*) FROM D_WAVECHINFO
         WHERE D_WAVECHINFO.EXTID$ LIKE '%' || par.ola || '%')                                            AS olas_encontradas,
       (SELECT LISTAGG(D_WAVECHINFO.EXTID$, ' | ') WITHIN GROUP (ORDER BY D_WAVECHINFO.EXTID$)
          FROM D_WAVECHINFO
         WHERE D_WAVECHINFO.EXTID$ LIKE '%' || par.ola || '%')                                            AS clave_de_ola_real,
       'wvch:' || par.ola || ':' || par.canal_peticion                                                    AS clave_que_busca_el_micro
  FROM par
 ORDER BY par.campana;
