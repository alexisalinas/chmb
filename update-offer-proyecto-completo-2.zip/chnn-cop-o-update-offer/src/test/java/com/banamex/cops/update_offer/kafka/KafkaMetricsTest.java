package com.banamex.cops.update_offer.kafka;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code KafkaMetrics}. */
class KafkaMetricsTest {

    @Test
    void empiezanEnCeroYCadaContadorEsIndependiente() {
        // Given
        KafkaMetrics m = new KafkaMetrics();

        // When / Then
        assertThat(m.getSent() + m.getNoRows() + m.getInvalid() + m.getFailed() + m.getRejected()).isZero();

        m.incSent();
        m.incSent();
        m.incNoRows();
        m.incInvalid();
        m.incFailed();
        m.incRejected();
        m.incRejected();
        m.incRejected();

        assertThat(m.getSent()).isEqualTo(2);
        assertThat(m.getNoRows()).isEqualTo(1);
        assertThat(m.getInvalid()).isEqualTo(1);
        assertThat(m.getFailed()).isEqualTo(1);
        assertThat(m.getRejected()).isEqualTo(3);
    }
}
