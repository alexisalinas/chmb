package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.config.UpdateOfferResponseProperties;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.testutil.TestData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code UpdateOfferResponseFactory}. */
class UpdateOfferResponseFactoryTest {

    /** 2026-11-11 16:30:45 UTC = 10:30:45 en US/Central (hora estándar, UTC-6). */
    private static final Instant AHORA = Instant.parse("2026-11-11T16:30:45Z");

    private UpdateOfferResponseProperties props;
    private UpdateOfferResponseFactory factory;

    @BeforeEach
    void setUp() {
        props = new UpdateOfferResponseProperties();
        factory = new UpdateOfferResponseFactory(props);
        ReflectionTestUtils.setField(factory, "clock", Clock.fixed(AHORA, ZoneOffset.UTC));
    }

    @Test
    void exito_llevaElCodigoYElTextoConLaFechaDeLaZonaEcrm() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = factory.success();

        // Then
        assertThat(r.getCode()).isEqualTo("COP_UPDOF_0");
        assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
    }

    @Test
    void laFechaSigueElFormatoYYYYMMDDHH24MISS() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.success().getDescription()).matches(".* \\d{4}/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2}$");
    }

    @Test
    void laFechaUsaLaZonaEcrmConfigurada() {
        // Given
        ReflectionTestUtils.setField(factory, "ecrmTimeZone", "Asia/Tokyo");

        // When
        UpdateOfferResponse r = factory.success();

        // Then
        assertThat(r.getDescription()).endsWith("2026/11/12 01:30:45");
    }

    @Test
    void elFormatoDeLaFechaEsConfigurable() {
        // Given
        props.setDateFormat("dd-MM-yyyy HH:mm");

        // When
        UpdateOfferResponse r = factory.success();

        // Then
        assertThat(r.getDescription()).endsWith("11-11-2026 10:30");
    }

    @Test
    void elCodigoYElTextoDeExitoSonConfigurables() {
        // Given
        props.setSuccessCode("OK");
        props.setSuccessText("Hecho el {dateTime}");

        // When
        UpdateOfferResponse r = factory.success();

        // Then
        assertThat(r.getCode()).isEqualTo("OK");
        assertThat(r.getDescription()).isEqualTo("Hecho el 2026/11/11 10:30:45");
    }

    @Test
    void error_llevaLaFechaElPasoYLaCausa() {
        // Given
        Throwable causa = new IllegalStateException("sin conexión");

        // When
        UpdateOfferResponse r = factory.error("Envío al EMS", causa);

        // Then
        assertThat(r.getCode()).isEqualTo("ERROR");
        assertThat(r.getDescription())
                .isEqualTo("Error update offer 2026/11/11 10:30:45. Falló en Envío al EMS: sin conexión");
    }

    @Test
    void error_usaLaCausaMasProfunda() {
        // Given
        Throwable causa = new RuntimeException("Error enviando al EMS",
                new RuntimeException("Uncategorized", new java.net.ConnectException("Connection refused")));

        // When
        UpdateOfferResponse r = factory.error("Envío al EMS", causa);

        // Then
        assertThat(r.getDescription()).endsWith("Connection refused");
    }

    @Test
    void error_siLaCausaNoTieneMensaje_usaElNombreDeSuClase() {
        // Given
        Throwable causa = new NullPointerException();

        // When
        UpdateOfferResponse r = factory.error("Armado del XML para el EMS", causa);

        // Then
        assertThat(r.getDescription()).endsWith("NullPointerException");
    }

    @Test
    void error_sinCausa_dejaElDetalleVacioSinFallar() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        UpdateOfferResponse r = factory.error("Validación de supresión", null);

        // Then
        assertThat(r.getCode()).isEqualTo("ERROR");
        assertThat(r.getDescription()).contains("Validación de supresión").doesNotContain("{detail}");
    }

    @Test
    void elCodigoYElTextoDeErrorSonConfigurables() {
        // Given
        props.setErrorCode("COP_ERR");
        props.setErrorText("{step} falló: {detail} ({dateTime})");

        // When
        UpdateOfferResponse r = factory.error("EMS", new RuntimeException("boom"));

        // Then
        assertThat(r.getCode()).isEqualTo("COP_ERR");
        assertThat(r.getDescription()).isEqualTo("EMS falló: boom (2026/11/11 10:30:45)");
    }

    @Test
    void elTextoSinMarcadores_seDevuelveTalCual() {
        // Given
        props.setSuccessText("Listo");

        // When / Then
        assertThat(factory.success().getDescription()).isEqualTo("Listo");
    }

    @Test
    void kafka_exito_llevaLaFechaDeLaZonaEcrm() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.kafkaSuccessText()).isEqualTo("Successfully send offer to Kafka 2026/11/11 10:30:45");
    }

    @Test
    void kafka_dryRun_llevaLaFecha() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.kafkaDryRunText()).isEqualTo("Kafka en dry-run: el mensaje no se publicó 2026/11/11 10:30:45");
    }

    @Test
    void kafka_error_llevaLaFechaElPasoYElDetalle() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.kafkaErrorText("Consulta a la base de datos", "no se encontró la oferta"))
                .isEqualTo("Error send offer to Kafka 2026/11/11 10:30:45. Falló en Consulta a la base de datos: no se encontró la oferta");
    }

    @Test
    void kafka_error_conExcepcion_usaLaCausaMasProfunda() {
        // Given
        Throwable causa = new RuntimeException("envoltorio", new IllegalStateException("broker caído"));

        // When / Then
        assertThat(factory.kafkaErrorText("Publicación en la cola de Kafka", causa)).endsWith("broker caído");
    }

    @Test
    void kafka_losTextosSonConfigurables() {
        // Given
        props.setKafkaSuccessText("Enviado {dateTime}");
        props.setKafkaErrorText("Falló {step}: {detail}");

        // When / Then
        assertThat(factory.kafkaSuccessText()).isEqualTo("Enviado 2026/11/11 10:30:45");
        assertThat(factory.kafkaErrorText("X", "Y")).isEqualTo("Falló X: Y");
    }

    private UpdateOfferRequest estatusU() {
        UpdateOfferRequest rq = TestData.request();
        rq.setOfferStatus("U");
        return rq;
    }

    @Test
    void estatusU_conCuentaYTarjeta_laLlaveLasLleva() {
        // Given
        UpdateOfferRequest rq = estatusU();

        // When
        UpdateOfferResponse r = factory.success(rq);

        // Then
        assertThat(r.getCode()).isEqualTo("COP_UPDOF_0");
        assertThat(r.getDescription())
                .isEqualTo("Successfully update offer off:mx:CAMP001_WAVE01_12345678_00112233445566_1234567812345678");
    }

    @Test
    void estatusU_soloConCuenta_laLlaveLlevaLaCuenta() {
        // Given
        UpdateOfferRequest rq = estatusU();
        rq.setCardNumber(null);

        // When / Then
        assertThat(factory.success(rq).getDescription())
                .isEqualTo("Successfully update offer off:mx:CAMP001_WAVE01_12345678_00112233445566");
    }

    @Test
    void estatusU_soloConTarjeta_laLlaveLlevaLaTarjeta() {
        // Given
        UpdateOfferRequest rq = estatusU();
        rq.setAccountNumber("");

        // When / Then
        assertThat(factory.success(rq).getDescription())
                .isEqualTo("Successfully update offer off:mx:CAMP001_WAVE01_12345678_1234567812345678");
    }

    @Test
    void estatusU_sinCuentaNiTarjeta_laLlaveEsCampanaOlaCliente() {
        // Given
        UpdateOfferRequest rq = estatusU();
        rq.setAccountNumber(null);
        rq.setCardNumber("");

        // When / Then
        assertThat(factory.success(rq).getDescription())
                .isEqualTo("Successfully update offer off:mx:CAMP001_WAVE01_12345678");
    }

    @Test
    void estatusU_sinCampaignId_respondeElCodigo432ConSuTexto() {
        // Given
        UpdateOfferRequest rq = estatusU();
        rq.setCampaignId("");

        // When
        UpdateOfferResponse r = factory.success(rq);

        // Then
        assertThat(r.getCode()).isEqualTo("COP_UPDOF_432");
        assertThat(r.getDescription()).isEqualTo("Campaign cmp:  is not present cannot proceed with the Update Offer");
    }

    @Test
    void estatusU_conCampaignIdNulo_tambienRespondeElCodigo432() {
        // Given
        UpdateOfferRequest rq = estatusU();
        rq.setCampaignId(null);

        // When / Then
        assertThat(factory.success(rq).getCode()).isEqualTo("COP_UPDOF_432");
    }

    @Test
    void estatusU_conCampaignIdDeSoloEspacios_cuentaComoConValor_comoEnXPath() {
        // Given
        UpdateOfferRequest rq = estatusU();
        rq.setCampaignId(" ");

        // When / Then
        assertThat(factory.success(rq).getCode()).isEqualTo("COP_UPDOF_0");
    }

    @Test
    void estatusU_noLlevaFecha() {
        // Given
        UpdateOfferRequest rq = estatusU();

        // When / Then
        assertThat(factory.success(rq).getDescription()).doesNotContainPattern("\\d{4}/\\d{2}/\\d{2}");
    }

    @Test
    void estatusU_noLlenaControlFieldNiLosCamposOpcionales_comoElMapDataDeBw() {
        // Given
        UpdateOfferRequest rq = estatusU();

        // When
        UpdateOfferResponse r = factory.success(rq);

        // Then
        assertThat(r.getContextType()).isNullOrEmpty();
        assertThat(r.getCustomerReferenceNumber()).isNull();
        assertThat(r.getStartDate()).isNull();
        assertThat(r.getEndDate()).isNull();
        assertThat(r.getSurveyModeCode()).isNull();
    }

    @Test
    void otroEstatus_respondeElExitoGenericoConLaFecha() {
        // Given
        UpdateOfferRequest rq = TestData.request();
        rq.setOfferStatus("H");

        // When
        UpdateOfferResponse r = factory.success(rq);

        // Then
        assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
    }

    @Test
    void conElFormatoDeBwApagado_elEstatusUTambienRespondeElExitoGenerico() {
        // Given
        props.setStatusUBwFormat(false);

        // When
        UpdateOfferResponse r = factory.success(estatusU());

        // Then
        assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
    }

    @Test
    void sinOferta_respondeElExitoGenerico() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.success((UpdateOfferRequest) null).getCode()).isEqualTo("COP_UPDOF_0");
    }

    @Test
    void estatusU_loscodigosYTextosSonConfigurables() {
        // Given
        props.setStatusUSuccessCode("OK_U");
        props.setStatusUSuccessText("Hecho {offerKey}");

        // When
        UpdateOfferResponse r = factory.success(estatusU());

        // Then
        assertThat(r.getCode()).isEqualTo("OK_U");
        assertThat(r.getDescription()).startsWith("Hecho off:mx:CAMP001_WAVE01_");
    }

    @Test
    void kafka_desactivado_diceQueNoSeEnvioNadaConLaFecha() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When / Then
        assertThat(factory.kafkaDisabledText())
                .isEqualTo("Kafka desactivado (offer.kafka.enabled = false): no se envió nada 2026/11/11 10:30:45");
    }

    private UpdateOfferResponse respuestaDelEms() {
        UpdateOfferResponse r = new UpdateOfferResponse();
        r.setCode("COP_UPDOF_0");
        r.setDescription("Successfully update offer off:mx:CAMP001:WAVE01:12345678");
        r.setContextType(java.util.List.of(
                com.banamex.cops.update_offer.dto.ControlFieldDTO.builder().contextType("5").build()));
        return r;
    }

    @Test
    void porDefectoElOrigenEsElMicro_yIgnoraLaRespuestaDelEms() {
        // Given
        UpdateOfferRequest rq = TestData.request();

        // When
        UpdateOfferResponse r = factory.success(rq, respuestaDelEms());

        // Then
        assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
        assertThat(r.getContextType()).isNullOrEmpty();
    }

    @Test
    void conOrigenEms_devuelveLaRespuestaDelEmsTalCual_conSuControlField() {
        // Given
        props.setSource("ems");
        UpdateOfferResponse ems = respuestaDelEms();

        // When
        UpdateOfferResponse r = factory.success(TestData.request(), ems);

        // Then
        assertThat(r).isSameAs(ems);
        assertThat(r.getContextType()).hasSize(1);
    }

    @Test
    void conOrigenEms_peroSinRespuestaDelEms_usaLaDelMicro() {
        // Given
        props.setSource("ems");

        // When
        UpdateOfferResponse r = factory.success(TestData.request(), null);

        // Then
        assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
    }

    @Test
    void conOrigenEms_siLaRespuestaDelEmsNoTraeCodigo_usaLaDelMicro() {
        // Given
        props.setSource("ems");
        UpdateOfferResponse sinCodigo = new UpdateOfferResponse();

        // When
        UpdateOfferResponse r = factory.success(TestData.request(), sinCodigo);

        // Then
        assertThat(r.getCode()).isEqualTo("COP_UPDOF_0");
        assertThat(r).isNotSameAs(sinCodigo);
    }

    @Test
    void conOrigenEms_lasOfertasUSiguenElFormatoDeMapDataDeBw() {
        // Given
        props.setSource("ems");
        UpdateOfferRequest rq = TestData.request();
        rq.setOfferStatus("U");

        // When
        UpdateOfferResponse r = factory.success(rq, respuestaDelEms());

        // Then
        assertThat(r.getDescription()).startsWith("Successfully update offer off:mx:CAMP001_WAVE01_");
    }

    @Test
    void elOrigenNoDistingueMayusculas() {
        // Given
        props.setSource("EMS");
        UpdateOfferResponse ems = respuestaDelEms();

        // When / Then
        assertThat(factory.success(TestData.request(), ems)).isSameAs(ems);
    }
}
