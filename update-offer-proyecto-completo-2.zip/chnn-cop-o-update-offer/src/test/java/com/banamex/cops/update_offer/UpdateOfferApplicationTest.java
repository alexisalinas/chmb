package com.banamex.cops.update_offer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code UpdateOfferApplication}. */
class UpdateOfferApplicationTest {

    @Test
    void escaneaSoloLosBeansDelMicro_noLosDeLaLibreria() {
        // Given
        SpringBootApplication anotacion = UpdateOfferApplication.class.getAnnotation(SpringBootApplication.class);

        // When / Then
        assertThat(anotacion.scanBasePackages()).containsExactly("com.banamex.cops.update_offer");
    }

    @Test
    void escaneaLasEntidadesJpaDeLaLibreria_paraQueNoFalleConNotAManagedType() {
        // Given
        EntityScan entityScan = UpdateOfferApplication.class.getAnnotation(EntityScan.class);

        // When / Then
        assertThat(entityScan).isNotNull();
        assertThat(entityScan.basePackages()).contains("com.banamex.cops.app");
    }
}
