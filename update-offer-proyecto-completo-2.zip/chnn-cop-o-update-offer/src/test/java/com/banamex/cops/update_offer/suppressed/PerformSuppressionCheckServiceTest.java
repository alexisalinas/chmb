package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionList;
import com.banamex.cops.update_offer.dto.suppression.StartRequest;
import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/** Pruebas unitarias de {@code PerformSuppressionCheckService}. */
@ExtendWith(MockitoExtension.class)
class PerformSuppressionCheckServiceTest {

    @Mock SuppressedEntitiesClient client;
    @Mock SuppressionCheckService checkService;
    @InjectMocks PerformSuppressionCheckService service;

    private StartRequest request;

    @BeforeEach
    void setUp() {
        StartRequestParams p = new StartRequestParams();
        p.setRequestingChannel("CAT");
        p.setCountryCode("MX");
        p.setCurrentOperationName("UpdateOffer");
        request = new StartRequest();
        request.setRequestParams(p);
    }

    @Test
    void conCheckForSuppressionY_consultaLaListaYAplicaLaValidacion() {
        // Given
        ReflectionTestUtils.setField(service, "checkForSuppression", "Y");
        SuppressedEntitiesListRoot lista = new SuppressedEntitiesListRoot();
        FilteredSuppressionList esperado = new FilteredSuppressionList();
        when(client.getListOfSuppressedEntities(request.getRequestParams())).thenReturn(lista);
        when(checkService.checkIfSuppressed(request, lista)).thenReturn(esperado);

        // When / Then
        assertThat(service.perform(request)).isSameAs(esperado);
        verify(client).getListOfSuppressedEntities(request.getRequestParams());
    }

    @Test
    void conCheckForSuppressionDistintoDeY_devuelveVacioSinConsultarNada() {
        // Given
        ReflectionTestUtils.setField(service, "checkForSuppression", "N");

        // When
        FilteredSuppressionList r = service.perform(request);

        // Then
        assertThat(r.getResults()).isEmpty();
        verifyNoInteractions(client, checkService);
    }

    @Test
    void laComparacionEsExactaConY_minusculaNoActiva() {
        // Given
        ReflectionTestUtils.setField(service, "checkForSuppression", "y");

        // When / Then
        assertThat(service.perform(request).getResults()).isEmpty();
        verifyNoInteractions(client);
    }

    @Test
    void siFallaLaConsulta_devuelveVacioYNoLanzaExcepcion() {
        // Given
        ReflectionTestUtils.setField(service, "checkForSuppression", "Y");
        when(client.getListOfSuppressedEntities(any())).thenThrow(new RuntimeException("sin lista"));

        // When / Then
        assertThat(service.perform(request).getResults()).isEqualTo(List.of());
    }

    @Test
    void siFallaLaValidacion_devuelveVacioYNoLanzaExcepcion() {
        // Given
        ReflectionTestUtils.setField(service, "checkForSuppression", "Y");
        when(client.getListOfSuppressedEntities(any())).thenReturn(new SuppressedEntitiesListRoot());
        when(checkService.checkIfSuppressed(any(), any())).thenThrow(new NullPointerException("detalle nulo"));

        // When / Then
        assertThat(service.perform(request).getResults()).isEmpty();
    }

    @Test
    void elClienteSePidePorNombre_laDeLaBaseDeDatos() {
        // Given
        var constructor = PerformSuppressionCheckService.class.getConstructors()[0];

        // When
        var qualifier = constructor.getParameters()[0]
                .getAnnotation(org.springframework.beans.factory.annotation.Qualifier.class);

        // Then
        assertThat(qualifier).isNotNull();
        assertThat(qualifier.value()).isEqualTo("dbSuppressedEntitiesClient");
    }

    /** Dos implementaciones más, las dos @Primary, como en el proyecto de Alexis. */
    @org.springframework.context.annotation.Configuration
    static class OtrasImplementaciones {

        @org.springframework.context.annotation.Bean
        @org.springframework.context.annotation.Primary
        SuppressedEntitiesClient inMemorySuppressedEntitiesClient() {
            return params -> null;
        }

        @org.springframework.context.annotation.Bean
        @org.springframework.context.annotation.Primary
        SuppressedEntitiesClient sharedVariableSuppressedEntitiesClient() {
            return params -> null;
        }
    }

    @Test
    void conVariasImplementacionesPrimarias_elContextoArrancaYUsaLaDeLaBaseDeDatos() {
        // Given
        var runner = new org.springframework.boot.test.context.runner.ApplicationContextRunner()
                .withUserConfiguration(OtrasImplementaciones.class)
                .withBean(DbSuppressedEntitiesClient.class)
                .withBean(StartUpSuppressionLoader.class)
                .withBean(com.banamex.cops.app.service.CopSuppressionService.class,
                        () -> org.mockito.Mockito.mock(com.banamex.cops.app.service.CopSuppressionService.class))
                .withBean(SuppressionCheckService.class, () -> org.mockito.Mockito.mock(SuppressionCheckService.class))
                .withBean(PerformSuppressionCheckService.class);

        // When / Then
        runner.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            Object cliente = org.springframework.test.util.ReflectionTestUtils.getField(
                    ctx.getBean(PerformSuppressionCheckService.class), "suppressedEntitiesClient");
            assertThat(cliente).isInstanceOf(DbSuppressedEntitiesClient.class);
        });
    }
}
