package com.banamex.cops.update_offer.service.timeZoneValidation;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code UpdateOfferFlowConditions}. */
class UpdateOfferFlowConditionsTest {

    @Test
    void translateTimeZone_soloEsTrueConLaPalabraTrueSinImportarMayusculas() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(UpdateOfferFlowConditions.translateTimeZone("true")).isTrue();
        assertThat(UpdateOfferFlowConditions.translateTimeZone("TRUE")).isTrue();
        assertThat(UpdateOfferFlowConditions.translateTimeZone("True")).isTrue();
        assertThat(UpdateOfferFlowConditions.translateTimeZone("false")).isFalse();
        assertThat(UpdateOfferFlowConditions.translateTimeZone("")).isFalse();
        assertThat(UpdateOfferFlowConditions.translateTimeZone(null)).isFalse();
    }

    @Test
    void continueToSuppression_continuaSiElCodigoTerminaEnCero() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_000")).isTrue();
        assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_110")).isTrue();
        assertThat(UpdateOfferFlowConditions.continueToSuppression("0")).isTrue();
    }

    @Test
    void continueToSuppression_continuaConElCodigo114() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_114")).isTrue();
    }

    @Test
    void continueToSuppression_seDetieneConCualquierOtroCodigo() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_101")).isFalse();
        assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_113")).isFalse();
        assertThat(UpdateOfferFlowConditions.continueToSuppression("ERROR")).isFalse();
    }

    @Test
    void continueToSuppression_nuloOVacioSeDetiene() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(UpdateOfferFlowConditions.continueToSuppression(null)).isFalse();
        assertThat(UpdateOfferFlowConditions.continueToSuppression("")).isFalse();
    }
}
