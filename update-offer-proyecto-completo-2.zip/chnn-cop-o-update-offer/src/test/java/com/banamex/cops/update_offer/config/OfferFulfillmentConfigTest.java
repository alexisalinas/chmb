package com.banamex.cops.update_offer.config;

import com.banamex.cops.app.repository.CopOfferFulfillmentRepository;
import com.banamex.cops.app.repository.CopSuppressionRepository;
import com.banamex.cops.app.repository.CopTimezoneLookupRepository;
import com.banamex.cops.app.service.CopOfferFulfillmentService;
import com.banamex.cops.app.service.CopSuppressionService;
import com.banamex.cops.app.service.CopTimezoneLookupService;
import com.banamex.cops.app.service.impl.CopOfferFulfillmentServiceImpl;
import com.banamex.cops.app.service.impl.CopSuppressionServiceImpl;
import com.banamex.cops.update_offer.kafka.OfferDataClient;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** Pruebas unitarias de {@code OfferFulfillmentConfig}. */
class OfferFulfillmentConfigTest {

    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withUserConfiguration(OfferFulfillmentConfig.class);

    @Test
    void conUnaConexionJdbc_registraElRepositorioYElServicioDeLaConsulta() {
        // Given
        ApplicationContextRunner conJdbc = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conJdbc.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(ctx).hasSingleBean(CopOfferFulfillmentRepository.class);
            assertThat(ctx).hasSingleBean(CopOfferFulfillmentService.class);
        });
    }

    @Test
    void conUnaConexionJdbc_registraTambienLasConsultasDeSupresion() {
        // Given
        ApplicationContextRunner conJdbc = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conJdbc.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(ctx).hasSingleBean(CopSuppressionRepository.class);
            assertThat(ctx).hasSingleBean(CopSuppressionService.class);
        });
    }

    @Test
    void elClienteDeDatosEncuentraElServicioRegistrado_yNoLanzaErrorDeDisponibilidad() {
        // Given
        NamedParameterJdbcTemplate jdbc = mock(NamedParameterJdbcTemplate.class);
        when(jdbc.getJdbcOperations()).thenReturn(mock(JdbcOperations.class));
        ApplicationContextRunner conCliente = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> jdbc)
                .withBean(OfferDataClient.class);

        // When / Then
        conCliente.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(ctx.getBean(OfferDataClient.class).find("wvch:W1:CAT", "off:mx:C1:W1:123")).isEmpty();
        });
    }

    @Test
    void siLaLibreriaTambienImportaLasMismasClases_cadaUnaSeRegistraUnaSolaVez() {
        // Given: la autoconfiguración de la librería ya importa las clases de cumplimiento (el caso real del error)
        ApplicationContextRunner conLibreria = new ApplicationContextRunner()
                .withUserConfiguration(OfferFulfillmentConfig.class, LibreriaQueTambienImporta.class)
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conLibreria.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(ctx.getBeanNamesForType(CopOfferFulfillmentRepository.class)).hasSize(1);
            assertThat(ctx.getBeanNamesForType(CopOfferFulfillmentService.class)).hasSize(1);
            assertThat(ctx.getBeanNamesForType(CopSuppressionRepository.class)).hasSize(1);
            assertThat(ctx.getBeanNamesForType(CopSuppressionService.class)).hasSize(1);
        });
    }

    @Test
    void lasClasesSeRegistranConElNombreCompletoDeLaClase_comoLasRegistraLaLibreria() {
        // Given
        ApplicationContextRunner conJdbc = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conJdbc.run(ctx -> assertThat(ctx.getBeanNamesForType(CopOfferFulfillmentRepository.class))
                .containsExactly("com.banamex.cops.app.repository.CopOfferFulfillmentRepository"));
    }

    @Test
    void sinConexionJdbc_elContextoFallaPorqueNoHayNamedParameterJdbcTemplate() {
        // Given
        // (sin precondiciones: no se agrega ninguna conexión a la base de datos)

        // When / Then
        runner.run(ctx -> assertThat(ctx).hasFailed());
    }

    /**
     * Simula la autoconfiguración de la librería ({@code CopsDbAutoConfiguration}), que importa las mismas clases.
     */
    @Configuration
    @Import({
            CopOfferFulfillmentRepository.class,
            CopOfferFulfillmentServiceImpl.class,
            CopSuppressionRepository.class,
            CopSuppressionServiceImpl.class
    })
    static class LibreriaQueTambienImporta {
    }

    @Test
    void noRegistraElLookupDeZonaHoraria_porqueYaLoRegistraLaLibreria() {
        // Given
        ApplicationContextRunner conJdbc = runner
                .withBean(NamedParameterJdbcTemplate.class, () -> mock(NamedParameterJdbcTemplate.class));

        // When / Then
        conJdbc.run(ctx -> {
            assertThat(ctx).hasNotFailed();
            assertThat(ctx).doesNotHaveBean(CopTimezoneLookupRepository.class);
            assertThat(ctx).doesNotHaveBean(CopTimezoneLookupService.class);
        });
    }
}
