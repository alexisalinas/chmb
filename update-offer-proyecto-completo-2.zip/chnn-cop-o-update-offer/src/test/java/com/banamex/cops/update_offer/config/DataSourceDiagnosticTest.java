package com.banamex.cops.update_offer.config;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.core.env.MapPropertySource;
import org.springframework.mock.env.MockEnvironment;

import javax.sql.DataSource;
import java.util.Map;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** Pruebas unitarias de {@code DataSourceDiagnostic}. */
class DataSourceDiagnosticTest {

    @Test
    void describe_sinContrasena_dice_queNoEstaDefinida() {
        // Given
        // (sin precondiciones propias)

        // When / Then
        assertThat(DataSourceDiagnostic.describe(null)).isEqualTo("NO DEFINIDA");
        assertThat(DataSourceDiagnostic.describe("")).isEqualTo("VACÍA");
    }

    @Test
    void describe_conLaVariableSinResolver_avisaQueSeEnviaraElTextoLiteral() {
        // Given
        String password = "${DB_PASSWORD}";

        // When
        String texto = DataSourceDiagnostic.describe(password);

        // Then
        assertThat(texto).startsWith("SIN RESOLVER").contains("${DB_PASSWORD}");
    }

    @Test
    void describe_contrasenaNormal_soloDiceLaLongitud() {
        // Given
        String password = "abc123XYZ";

        // When
        String texto = DataSourceDiagnostic.describe(password);

        // Then
        assertThat(texto).isEqualTo("******** (longitud 9)");
        assertThat(texto).doesNotContain("abc123");
    }

    @Test
    void describe_avisaDeEspaciosAlInicioOAlFinal() {
        // Given
        // (sin precondiciones propias)

        // When / Then
        assertThat(DataSourceDiagnostic.describe("clave ")).contains("espacios");
        assertThat(DataSourceDiagnostic.describe(" clave")).contains("espacios");
    }

    @Test
    void describe_avisaDeComillasEnLosExtremos() {
        // Given
        // (sin precondiciones propias)

        // When / Then
        assertThat(DataSourceDiagnostic.describe("\"clave\"")).contains("comillas");
        assertThat(DataSourceDiagnostic.describe("'clave'")).contains("comillas");
    }

    @Test
    void describe_avisaDeUnaComaOPuntoYComaAlFinal_comoElErrorQueYaSeVio() {
        // Given
        // (sin precondiciones propias)

        // When / Then
        assertThat(DataSourceDiagnostic.describe("clave,")).contains("coma");
        assertThat(DataSourceDiagnostic.describe("clave;")).contains("coma");
    }

    @Test
    void logConnection_escribeUrlYUsuario_peroNuncaLaContrasena() {
        // Given
        MockEnvironment env = new MockEnvironment()
                .withProperty("spring.datasource.url", "jdbc:oracle:thin:@//host:8889/SVC")
                .withProperty("spring.datasource.username", "RMXCOP4")
                .withProperty("spring.datasource.password", "secreta123,");
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, sinDataSources()).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        String linea = appender.list.get(0).getFormattedMessage();
        assertThat(linea).startsWith("[DB] Configuración:")
                .contains("url=jdbc:oracle:thin:@//host:8889/SVC", "username=RMXCOP4", "longitud 12", "coma");
        assertThat(linea).doesNotContain("secreta123");
    }

    @Test
    void logConnection_conLaVariableSinResolver_diceQueFaltaDB_PASSWORD() {
        // Given
        MockEnvironment env = new MockEnvironment()
                .withProperty("spring.datasource.username", "RMXCOP4")
                .withProperty("spring.datasource.password", "${DB_PASSWORD}");
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, sinDataSources()).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list.get(0).getFormattedMessage()).contains("NO DEFINIDA (falta la variable DB_PASSWORD)");
    }

    @Test
    void logConnection_conLaVariableSinDefinir_loEscribeComoErrorConElMotivo() {
        // Given
        MockEnvironment env = new MockEnvironment()
                .withProperty("spring.datasource.username", "RMXCOP4")
                .withProperty("spring.datasource.password", "${DB_PASSWORD}");
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, sinDataSources()).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list.get(0).getLevel()).isEqualTo(ch.qos.logback.classic.Level.ERROR);
        assertThat(appender.list.get(0).getFormattedMessage()).contains("ORA-01017");
    }

    @Test
    void logConnection_conUnaContrasenaDefinida_loEscribeComoInfo() {
        // Given
        MockEnvironment env = new MockEnvironment().withProperty("spring.datasource.password", "clave123");
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, sinDataSources()).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list.get(0).getLevel()).isEqualTo(ch.qos.logback.classic.Level.INFO);
    }

    @Test
    void logConnection_listaLosArchivosDeConfiguracion_enOrdenDePrioridad_yElDirectorioDeTrabajo() {
        // Given
        MockEnvironment env = new MockEnvironment().withProperty("spring.datasource.password", "clave123");
        env.getPropertySources().addLast(new MapPropertySource(
                "Config resource 'class path resource [application.yml]' via location 'optional:classpath:/'", Map.of()));
        env.getPropertySources().addFirst(new MapPropertySource(
                "Config resource 'file [config/application.yml]' via location 'optional:file:./config/'", Map.of()));
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, sinDataSources()).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        String linea = appender.list.stream().map(e -> e.getFormattedMessage())
                .filter(m -> m.startsWith("[DB] Archivos de configuración cargados")).findFirst().orElseThrow();
        assertThat(linea).contains("[file [config/application.yml], class path resource [application.yml]]");
        assertThat(linea).contains("directorio de trabajo: " + System.getProperty("user.dir"));
    }

    @Test
    void shorten_dejaSoloElArchivo() {
        // Given
        String nombre = "Config resource 'class path resource [application.yml]' via location 'optional:classpath:/'";

        // When / Then
        assertThat(DataSourceDiagnostic.shorten(nombre)).isEqualTo("class path resource [application.yml]");
        assertThat(DataSourceDiagnostic.shorten("otro nombre")).isEqualTo("otro nombre");
    }

    @SuppressWarnings("unchecked")
    private static ObjectProvider<DataSource> sinDataSources() {
        ObjectProvider<DataSource> provider = mock(ObjectProvider.class);
        when(provider.orderedStream()).thenAnswer(inv -> Stream.empty());
        return provider;
    }

    /** DataSource de mentira con los mismos métodos que Hikari. */
    public static class FakeDataSource {
        public String getJdbcUrl() { return "jdbc:oracle:thin:@//otro-host:1521/OTRO"; }
        public String getUsername() { return "OTRO_USUARIO"; }
        public String getPassword() { return "otra-clave-larga"; }
    }

    @Test
    void logConnection_diceDeQueFuenteSaleCadaDato() {
        // Given
        MockEnvironment env = new MockEnvironment()
                .withProperty("spring.datasource.url", "jdbc:oracle:thin:@//host:8889/SVC")
                .withProperty("spring.datasource.username", "RMXCOP4")
                .withProperty("spring.datasource.password", "clave123");
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, sinDataSources()).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list.get(0).getFormattedMessage()).contains("(fuente: mockProperties)");
    }

    @Test
    void logConnection_siLaContrasenaVieneDeUnaVariableDeEntorno_avisaQueLeGanaAlYml() {
        // Given
        MockEnvironment env = new MockEnvironment().withProperty("spring.datasource.password", "del-yml");
        env.getPropertySources().addFirst(new MapPropertySource("systemEnvironment",
                Map.of("spring.datasource.password", "de-la-variable")));
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, sinDataSources()).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list.get(0).getFormattedMessage()).contains("password=******** (longitud 14) (fuente: systemEnvironment)");
        assertThat(appender.list).anyMatch(e -> e.getLevel() == ch.qos.logback.classic.Level.WARN
                && e.getFormattedMessage().contains("viene de una variable de entorno"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void logConnection_tambienDescribeElDataSourceReal_sinMostrarSuContrasena() {
        // Given
        MockEnvironment env = new MockEnvironment().withProperty("spring.datasource.password", "clave123");
        ObjectProvider<DataSource> provider = mock(ObjectProvider.class);
        when(provider.orderedStream()).thenAnswer(inv -> Stream.of(mock(DataSource.class)));
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, provider).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list).anyMatch(e -> e.getFormattedMessage().startsWith("[DB] Conexión real:"));
    }

    @Test
    void describeDataSource_leeUrlUsuarioYContrasena_sinMostrarla() {
        // Given
        FakeDataSource ds = new FakeDataSource();

        // When
        String texto = DataSourceDiagnostic.describeDataSource(ds);

        // Then
        assertThat(texto).contains("url=jdbc:oracle:thin:@//otro-host:1521/OTRO", "username=OTRO_USUARIO", "longitud 16");
        assertThat(texto).doesNotContain("otra-clave-larga");
    }

    @Test
    void logConnection_siNoHayDataSource_lodice() {
        // Given
        MockEnvironment env = new MockEnvironment().withProperty("spring.datasource.password", "clave123");
        var appender = escucharElLog();

        // When
        try {
            new DataSourceDiagnostic(env, sinDataSources()).logConnection();
        } finally {
            dejarDeEscucharElLog(appender);
        }

        // Then
        assertThat(appender.list).anyMatch(e -> e.getFormattedMessage().contains("(no hay ningún DataSource)"));
    }

    private ListAppender<ILoggingEvent> escucharElLog() {
        Logger logger = (Logger) LoggerFactory.getLogger(DataSourceDiagnostic.class);
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        return appender;
    }

    private void dejarDeEscucharElLog(ListAppender<ILoggingEvent> appender) {
        ((Logger) LoggerFactory.getLogger(DataSourceDiagnostic.class)).detachAppender(appender);
    }
}
