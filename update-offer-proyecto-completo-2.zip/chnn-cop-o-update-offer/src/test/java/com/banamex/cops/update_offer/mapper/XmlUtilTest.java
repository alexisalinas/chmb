package com.banamex.cops.update_offer.mapper;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code XmlUtil}. */
class XmlUtilTest {

    @Test
    void esc_escapaLosCincoCaracteresEspeciales() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(XmlUtil.esc("a & b < c > d \" e ' f"))
                .isEqualTo("a &amp; b &lt; c &gt; d &quot; e &apos; f");
    }

    @Test
    void tag_escribeElElementoConIndentacionYEscapaElValor() {
        // Given
        StringBuilder x = new StringBuilder();

        // When
        XmlUtil.tag(x, "  ", "Name", "a&b");

        // Then
        assertThat(x.toString()).isEqualTo("  <Name>a&amp;b</Name>\n");
    }

    @Test
    void tag_omiteElElementoCuandoElValorEsNull() {
        // Given
        StringBuilder x = new StringBuilder();

        // When
        XmlUtil.tag(x, "  ", "Name", null);

        // Then
        assertThat(x).isEmpty();
    }

    @Test
    void tag_conValorVacioEscribeElementoAbiertoYCerrado() {
        // Given
        StringBuilder x = new StringBuilder();

        // When
        XmlUtil.tag(x, "", "Name", "");

        // Then
        assertThat(x.toString()).isEqualTo("<Name></Name>\n");
    }

    @Test
    void tagOrEmpty_nullOVacioSeEscribeAutocerrado() {
        // Given
        StringBuilder x = new StringBuilder();

        // When
        XmlUtil.tagOrEmpty(x, "", "A", null);
        XmlUtil.tagOrEmpty(x, "", "B", "");

        // Then
        assertThat(x.toString()).isEqualTo("<A/>\n<B/>\n");
    }

    @Test
    void tagOrEmpty_conValorEscribeElElemento() {
        // Given
        StringBuilder x = new StringBuilder();

        // When
        XmlUtil.tagOrEmpty(x, "", "A", "1");

        // Then
        assertThat(x.toString()).isEqualTo("<A>1</A>\n");
    }
}
