package com.banamex.cops.update_offer.kafka;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de los valores por defecto de {@code OfferKafkaProps}. */
class OfferKafkaPropsTest {

    @Test
    void sinConfiguracion_kafkaEstaActivoPeroEnDryRun() {
        // Given
        OfferKafkaProps props = new OfferKafkaProps();

        // When / Then
        assertThat(props.isEnabled()).isTrue();
        assertThat(props.getMode()).isEqualTo("dry-run");
    }

    @Test
    void sinConfiguracion_elMensajeALaColaEsElJsonTodoJunto() {
        // Given
        OfferKafkaProps props = new OfferKafkaProps();

        // When / Then
        assertThat(props.getMessageFormat()).isEqualTo("json");
    }

    @Test
    void sinConfiguracion_elEventoSeLlamaUpdateofferrequest() {
        // Given
        OfferKafkaProps props = new OfferKafkaProps();

        // When / Then
        assertThat(props.getEventName()).isEqualTo("Updateofferrequest");
    }
}
