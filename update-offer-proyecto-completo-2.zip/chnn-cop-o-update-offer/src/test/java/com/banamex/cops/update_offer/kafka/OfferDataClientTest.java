package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.app.service.CopOfferFulfillmentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

/** Pruebas unitarias de {@code OfferDataClient}. */
@ExtendWith(MockitoExtension.class)
class OfferDataClientTest {

    @Mock ObjectProvider<CopOfferFulfillmentService> provider;
    @Mock CopOfferFulfillmentService service;
    @InjectMocks OfferDataClient client;

    private CopOfferFulfillment fila(String prdType) {
        return new CopOfferFulfillment("C", prdType, "R", "D", "P", "F", List.of(), null, null, null, null, "PC", "PF", "Y");
    }

    @Test
    void devuelveLaPrimeraFila() {
        // Given
        when(provider.orderedStream()).thenAnswer(inv -> Stream.of(service));
        when(service.findByWaveKeyAndOfferKey("wvch:W1:CAT", "off:mx:C1:W1:123")).thenReturn(List.of(fila("A")));

        // When
        Optional<CopOfferFulfillment> r = client.find("wvch:W1:CAT", "off:mx:C1:W1:123");

        // Then
        assertThat(r).isPresent();
        assertThat(r.get().prdType()).isEqualTo("A");
    }

    @Test
    void conVariasFilas_usaLaPrimera() {
        // Given
        when(provider.orderedStream()).thenAnswer(inv -> Stream.of(service));
        when(service.findByWaveKeyAndOfferKey("a", "b")).thenReturn(List.of(fila("A"), fila("B")));

        // When / Then
        assertThat(client.find("a", "b").get().prdType()).isEqualTo("A");
    }

    @Test
    void sinFilas_devuelveVacio() {
        // Given
        when(provider.orderedStream()).thenAnswer(inv -> Stream.of(service));
        when(service.findByWaveKeyAndOfferKey("a", "b")).thenReturn(List.of());

        // When / Then
        assertThat(client.find("a", "b")).isEmpty();
    }

    @Test
    void listaNulaDeLaLibreria_seTrataComoSinFilas() {
        // Given
        when(provider.orderedStream()).thenAnswer(inv -> Stream.of(service));
        when(service.findByWaveKeyAndOfferKey("a", "b")).thenReturn(null);

        // When / Then
        assertThat(client.find("a", "b")).isEmpty();
    }

    @Test
    void sinLibreriaOSinBD_lanzaIllegalStateParaQueSeReintenteYSeContePorFalla() {
        // Given
        when(provider.orderedStream()).thenAnswer(inv -> Stream.empty());

        // When / Then
        assertThatThrownBy(() -> client.find("a", "b"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("CopOfferFulfillmentService");
    }
}
