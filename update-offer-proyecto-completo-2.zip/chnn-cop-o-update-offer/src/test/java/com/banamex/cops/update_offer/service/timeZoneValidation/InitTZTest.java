package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.TzFormatsDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/** Pruebas unitarias de {@code InitTZ}. */
class InitTZTest {

    private final InitTZ initTZ = new InitTZ();

    private TzLookUpDTO lookUp(String system, String mode, String type, String offset) {
        TzLookUpDTO l = new TzLookUpDTO();
        l.setSystemName(system);
        l.setMode(mode);
        l.setType(type);
        l.setTimeOffset(offset);
        l.setDateFormat("yyyy-MM-dd");
        l.setTimeFormat("HH:mm:ss");
        l.setDateTimeFormat("yyyy-MM-dd'T'HH:mm:ss");
        l.setTimeZone("America/Bogota");
        return l;
    }

    @Test
    void conCoincidencia_devuelveLosFormatosConLosNombresDeBW() {
        // Given
        // (sin precondiciones)

        // When
        Optional<TzFormatsDTO> r = initTZ.execute("COPS", "RT", "Request",
                List.of(lookUp("OTRO", "RT", "Request", "+01:00"), lookUp("COPS", "RT", "Request", "-05:00")));

        // Then
        assertThat(r).isPresent();
        assertThat(r.get().getTimeZoneOffset()).isEqualTo("-05:00");
        assertThat(r.get().getDateFormat()).isEqualTo("yyyy-MM-dd");
        assertThat(r.get().getTimeFormat()).isEqualTo("HH:mm:ss");
        assertThat(r.get().getDateTimeFormat()).isEqualTo("yyyy-MM-dd'T'HH:mm:ss");
        assertThat(r.get().getTimeZone()).isEqualTo("America/Bogota");
    }

    @Test
    void sinCoincidencia_devuelveVacio() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(initTZ.execute("COPS", "RT", "Response", List.of(lookUp("COPS", "RT", "Request", "-05:00")))).isEmpty();
        assertThat(initTZ.execute("COPS", "BATCH", "Request", List.of(lookUp("COPS", "RT", "Request", "-05:00")))).isEmpty();
        assertThat(initTZ.execute("XXXX", "RT", "Request", List.of(lookUp("COPS", "RT", "Request", "-05:00")))).isEmpty();
    }

    @Test
    void listaNulaOVacia_devuelveVacio() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(initTZ.execute("COPS", "RT", "Request", null)).isEmpty();
        assertThat(initTZ.execute("COPS", "RT", "Request", List.of())).isEmpty();
    }

    @Test
    void conVariasCoincidencias_tomaLaPrimera() {
        // Given
        // (sin precondiciones)

        // When
        Optional<TzFormatsDTO> r = initTZ.execute("COPS", "RT", "Request",
                List.of(lookUp("COPS", "RT", "Request", "-05:00"), lookUp("COPS", "RT", "Request", "+09:00")));

        // Then
        assertThat(r.get().getTimeZoneOffset()).isEqualTo("-05:00");
    }

    @Test
    void valoresNulosEnLaConsultaNoLanzanExcepcion() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(initTZ.execute(null, null, null, List.of(lookUp("COPS", "RT", "Request", "-05:00")))).isEmpty();
    }
}
