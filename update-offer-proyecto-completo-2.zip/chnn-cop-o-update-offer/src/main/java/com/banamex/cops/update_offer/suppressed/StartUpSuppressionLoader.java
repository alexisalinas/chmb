package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailsDTO;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntityDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/** Equivale al {@code SetVariable} del proceso de BW {@code /BW/StartUp/startUpSuppression}. */
@Component
public class StartUpSuppressionLoader {

    /** Arma la lista de entidades suprimidas. */
    public SuppressedEntitiesListRoot build(List<CopSuppressionChannel> channels, List<CopSuppressionOperation> operations) {
        List<CopSuppressionOperation> ops = operations == null ? List.of() : operations;
        List<SuppressedEntityDTO> entities = new ArrayList<>();
        if (channels != null) {
            for (CopSuppressionChannel channel : channels) {
                entities.add(entity(channel, details(channel, ops)));
            }
        }
        return SuppressedEntitiesListRoot.builder().suppressedEntities(entities).build();
    }

    private SuppressedEntityDTO entity(CopSuppressionChannel c, List<OperationDetailsDTO> details) {
        return SuppressedEntityDTO.builder()
                .countryCode(c.countryCode())
                .mode(c.reqMode())
                .channelId(c.channelId())
                .suppressionFlag(c.suppressionFlag())
                .operationFlag(c.operationFlag())
                .sourceSystem(c.sourceSystem())
                .operationDetails(details)
                .build();
    }

    /** El {@code Choose} de BW: los detalles de operación según las banderas del canal. */
    private List<OperationDetailsDTO> details(CopSuppressionChannel c, List<CopSuppressionOperation> ops) {
        List<OperationDetailsDTO> out = new ArrayList<>();
        if ("Y".equals(c.suppressionFlag()) && "Y".equals(c.operationFlag())) {
            for (CopSuppressionOperation o : ops) {
                if (o.reqChannel() != null && o.reqChannel().equals(c.channelId())) {
                    out.add(detail(o, "Y"));
                }
            }
        } else if ("Y".equals(c.suppressionFlag()) && "N".equals(c.operationFlag())) {
            for (CopSuppressionOperation o : ops) {
                out.add(detail(o, o.operationSuppressFlag()));
            }
        }
        return out;
    }

    private OperationDetailsDTO detail(CopSuppressionOperation o, String operationFlag) {
        return OperationDetailsDTO.builder()
                .operationName(o.operationName())
                .operationFlag(operationFlag)
                .reqChannel(o.reqChannel())
                .build();
    }
}
