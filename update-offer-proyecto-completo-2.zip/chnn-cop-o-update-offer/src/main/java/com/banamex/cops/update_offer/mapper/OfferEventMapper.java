package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.config.OfferJmsProperties;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.timeZoneValidation.DateGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeGrpDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

/** Pestaña "Input" de la actividad JMS Queue Requestor de OpUpdateOffer (rama XSD Format). */
@Component
@RequiredArgsConstructor
public class OfferEventMapper {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    private static final DateTimeFormatter TS_OFFSET = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    private final OfferJmsProperties props;
    private final UserTextParser userTextParser;

    /** BW: lower-case($_globalVariables/COP/TimeZone/TranslateTimeZone) = "true" */
    @Value("${update-offer.timezone.translate-time-zone:true}")
    private boolean translateTimeZone;

    /** BW: $_globalVariables/COP/TimeZone/ECRMTimeZone */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone;

    /**
     * Convierte la oferta en los campos del evento que se manda al EMS (los {@code OtherProperties} del JMS Queue
     * Requestor).
     */
    public Map<String, String> map(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                                   String tzResponseCode, MapRequestResultDTO tz) {
        boolean tzActive = translateTimeZone && tz != null && tzOk(tzResponseCode);
        Map<Integer, String> uf = userTextParser.parse(rq.getUserText());
        Map<String, String> o = new LinkedHashMap<>();

        req(o, "RequestingChannel", rq.getChannelCode());
        req(o, "CampaignID", rq.getCampaignId());
        req(o, "WaveID", rq.getWaveId());
        req(o, "AccountNO", rq.getAccountNumber());
        req(o, "CardNO", rq.getCardNumber());
        req(o, "AssignedBy", rq.getAssignedBy());
        opt(o, "AgentID", rq.getAssignedTo());

        if (hasText(rq.getAppointmentDate())) {
            String tzDate = tzActive ? tzDate(tz, "AppointmentDate") : null;
            o.put("ApptDate", tzDate != null ? tzDate : rq.getAppointmentDate());
        }
        String tzStart = tzActive ? tzTime(tz, "AppointmentStartTime") : null;
        req(o, "ApptStartTime", tzStart != null ? tzStart : withoutSeconds(rq.getAppointmentStartTime()));
        String tzEnd = tzActive ? tzTime(tz, "AppointmentEndTime") : null;
        req(o, "ApptEndTime", tzEnd != null ? tzEnd : withoutSeconds(rq.getAppointmentEndTime()));

        opt(o, "ApptConfirmation", rq.getOfferedNumber());
        req(o, "ReasonCode", rq.getReasonCode());
        req(o, "ReasonDescription", rq.getReasonDescription());
        req(o, "Comments", rq.getComments());
        req(o, "ContactNumber", rq.getContactIndicatorNumber());
        req(o, "OfferStatus", rq.getOfferStatus());
        req(o, "SysVersion", rq.getSchemaVersion());

        req(o, "CustomerNO", customerNo(rq.getCustomerId()));
        req(o, "OfferSource", rq.getOfferSource());
        for (int i = 1; i <= 100; i++) {
            if (i <= 20 || i == 29) req(o, "UserField" + i, uf.get(i)); else opt(o, "UserField" + i, uf.get(i));
        }
        req(o, "OfferAction", rq.getOfferActionCode());
        req(o, "GiftCode", rq.getGiftCode());
        req(o, "GiftConfirmationNO", rq.getGiftConfirmationNumber());
        opt(o, "FulfillmentReferencedNO", rq.getFulfillmentTrackerFlag());
        opt(o, "ProbabilityAmount", rq.getAmount());
        opt(o, "Department", rq.getDepartmentId());
        opt(o, "Branch", rq.getBranchId());
        req(o, "ContactReference", rq.getCustomerReferenceNumber());
        opt(o, "Priority", rq.getOfferPriority());
        opt(o, "Workgroup", rq.getWorkgroupId());
        req(o, "LVCode", rq.getLevelCode());
        req(o, "UpdatedBy", updatedBy);
        req(o, "UpdateTime", tzActive
                ? OffsetDateTime.now(ZoneId.of(ecrmTimeZone)).format(TS_OFFSET)
                : (requestTime != null ? requestTime.format(TS) : null));
        opt(o, "ControlField", contextTypeAt(rq, 0));

        opt(o, "AreaID", rq.getAreaIdentifier());
        opt(o, "DivisionID", rq.getDivisionCode());
        opt(o, "RegionID", rq.getBranchRegionIdentifier());
        opt(o, "AgentName", rq.getAgentName());
        req(o, "ContactType", rq.getContactType());
        req(o, "ContactInfo", rq.getContactIndicatorNumber());
        opt(o, "OfferCategory", rq.getOfferCategory());
        opt(o, "BranchName", rq.getBranchName());
        req(o, "DepartmentName", rq.getDepartmentName());
        opt(o, "ChannelResponse", rq.getResponseChannel());
        opt(o, "Purpose", rq.getPurpose());
        opt(o, "LocationIndicator", contextTypeAt(rq, 1));
        opt(o, "CustomerEmail", rq.getCustomerEmailAddress());
        opt(o, "FulfillmentScript", rq.getFulfillmentCode());
        return o;
    }

    private String tzDate(MapRequestResultDTO tz, String name) {
        return tz.getDateGrp().stream()
                .filter(g -> name.equalsIgnoreCase(g.getDateName()))
                .map(DateGrpDTO::getDate).findFirst().orElse(null);
    }

    private String tzTime(MapRequestResultDTO tz, String name) {
        return tz.getTimeGrp().stream()
                .filter(g -> name.equalsIgnoreCase(g.getTimeName()))
                .map(TimeGrpDTO::getTime).findFirst().orElse(null);
    }

    /** if(count(tib:tokenize(t, ':')) = 3) then tib:substring-before-last(t, ':') else t */
    private static String withoutSeconds(String t) {
        if (t == null || t.isEmpty()) return "";
        return t.split(":", -1).length == 3 ? t.substring(0, t.lastIndexOf(':')) : t;
    }

    /** substring(ResponseCode, string-length(ResponseCode), 1) = '0' */
    private static boolean tzOk(String responseCode) {
        return responseCode != null && !responseCode.isEmpty()
                && responseCode.charAt(responseCode.length() - 1) == '0';
    }

    /** CustomerNO [Choose]: CustomerNo != "" y CustomerPadding="true" -> tib. */
    private String customerNo(String v) {
        if (v == null || v.isEmpty()) return "";
        return props.isCustomerPadding()
                ? padFront(v, props.getCustomerPaddingLength(), props.getCustomerPaddingChar()) : v;
    }

    private static String padFront(String v, int len, char c) {
        StringBuilder sb = new StringBuilder();
        for (int i = v.length(); i < len; i++) sb.append(c);
        return sb.append(v).toString();
    }

    private String contextTypeAt(UpdateOfferRequest rq, int idx) {
        return rq.getContextType() != null && idx < rq.getContextType().size()
                && rq.getContextType().get(idx) != null
                ? rq.getContextType().get(idx).getContextType() : null;
    }

    private static boolean hasText(String s) { return s != null && !s.trim().isEmpty(); }

    /** Campo obligatorio: siempre se escribe (vacío si no hay dato). */
    private static void req(Map<String, String> m, String k, String v) { m.put(k, v == null ? "" : v); }

    /** Campo opcional: solo si trae valor. */
    private static void opt(Map<String, String> m, String k, String v) { if (v != null) m.put(k, v); }
}
