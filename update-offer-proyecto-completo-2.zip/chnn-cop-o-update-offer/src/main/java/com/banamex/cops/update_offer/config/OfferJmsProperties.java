package com.banamex.cops.update_offer.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/** Globales de BW que usa el mapper del JMS Queue Requestor para CustomerNO. */
@Data
@Component
@ConfigurationProperties(prefix = "update-offer.jms-requestor")
public class OfferJmsProperties {

    private boolean customerPadding;
    private int customerPaddingLength = 19;
    private char customerPaddingChar = '0';
}
