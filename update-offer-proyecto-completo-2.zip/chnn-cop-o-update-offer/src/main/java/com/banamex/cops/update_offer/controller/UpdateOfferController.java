package com.banamex.cops.update_offer.controller;

import com.banamex.cops.update_offer.config.HeaderValidation;
import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.service.UpdateOfferService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Controlador REST que expone el endpoint para actualizar ofertas existentes. */
@Slf4j
@RestController
@RequestMapping("/sd-campaing-management/v1/update-offer")
@RequiredArgsConstructor
@HeaderValidation.Required({"uuid", "ChannelId", "sid", "countryCode", "businessCode", "host", "Accept", "Content-Type"})
public class UpdateOfferController {

    private final UpdateOfferService updateOfferService;

    /** Actualiza una o varias ofertas. */
    @PostMapping
    public ResponseEntity<List<UpdateOfferResponse>> updateOffer(
            @RequestHeader(value = "uuid", required = false) String uuid,
            @RequestHeader(value = "ChannelId", required = false) String channelId,
            @RequestHeader(value = "countryCode", required = false)
            @Pattern(regexp = "^[A-Za-z]{2}$", message = "countryCode debe tener 2 letras (ISO 3166)") String countryCode,
            @RequestHeader(value = "businessCode", required = false) String businessCode,
            @RequestHeader(value = "host", required = false) String host,
            @RequestHeader(value = "sid", required = false) String sid,
            @RequestHeader(value = "Accept-Language", required = false) String acceptLanguage,
            @RequestHeader HttpHeaders httpHeaders,
            @RequestBody List<@Valid UpdateOfferRequest> requests) {

        UpdateOfferHeaders headers = UpdateOfferHeaders.builder()
                .uuid(uuid)
                .channelId(channelId)
                .countryCode(countryCode)
                .businessCode(businessCode)
                .host(host)
                .sid(sid)
                .acceptLanguage(acceptLanguage)
                .all(allHeaders(httpHeaders))
                .build();

        List<UpdateOfferResponse> responses = updateOfferService.updateOffer(requests, headers);

        return ResponseEntity.ok(responses);
    }

    /** Todos los headers recibidos (sin distinguir mayúsculas), con su primer valor. */
    private static Map<String, String> allHeaders(HttpHeaders httpHeaders) {
        Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        if (httpHeaders != null) {
            httpHeaders.forEach((name, values) -> {
                if (values != null && !values.isEmpty()) {
                    all.put(name, values.get(0));
                }
            });
        }
        return all;
    }
}
