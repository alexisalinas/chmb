package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.config.UpdateOfferResponseProperties;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/** Arma la respuesta que el micro devuelve por cada oferta (el {@code End} de BW). */
@Component
@RequiredArgsConstructor
public class UpdateOfferResponseFactory {

    private final UpdateOfferResponseProperties props;

    /** Zona de la fecha: la misma ECRMTimeZone de las globales (US/Central). */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone = "US/Central";

    /** Reloj (se cambia en las pruebas). */
    private Clock clock = Clock.systemUTC();

    /** Respuesta de éxito. */
    public UpdateOfferResponse success() {
        return build(props.getSuccessCode(), props.getSuccessText(), "", "");
    }

    /** Respuesta de éxito de una oferta. */
    public UpdateOfferResponse success(UpdateOfferRequest request) {
        if (request == null || !props.isStatusUBwFormat() || !"U".equals(request.getOfferStatus())) {
            return success();
        }
        UpdateOfferResponse r = new UpdateOfferResponse();
        if (isEmpty(request.getCampaignId())) {
            r.setCode(props.getStatusUCampaignMissingCode());
            r.setDescription(props.getStatusUCampaignMissingText()
                    .replace("{campaignId}", request.getCampaignId() == null ? "" : request.getCampaignId()));
        } else {
            r.setCode(props.getStatusUSuccessCode());
            r.setDescription(props.getStatusUSuccessText().replace("{offerKey}", updateKey(request)));
        }
        return r;
    }

    /** Respuesta de éxito de una oferta, teniendo en cuenta lo que contestó el EMS. */
    public UpdateOfferResponse success(UpdateOfferRequest request, UpdateOfferResponse emsResponse) {
        boolean esU = request != null && props.isStatusUBwFormat() && "U".equals(request.getOfferStatus());
        if (!esU && "ems".equalsIgnoreCase(props.getSource()) && emsResponse != null
                && emsResponse.getCode() != null && !emsResponse.getCode().isBlank()) {
            return emsResponse;
        }
        return success(request);
    }

    /** Llave de la oferta que arma el {@code Map-Data} de BW en el caso {@code U}. */
    static String updateKey(UpdateOfferRequest rq) {
        StringBuilder key = new StringBuilder("off:mx:")
                .append(nz(rq.getCampaignId())).append('_')
                .append(nz(rq.getWaveId())).append('_')
                .append(nz(rq.getCustomerId()));
        if (!isEmpty(rq.getAccountNumber())) {
            key.append('_').append(rq.getAccountNumber());
        }
        if (!isEmpty(rq.getCardNumber())) {
            key.append('_').append(rq.getCardNumber());
        }
        return key.toString();
    }

    /** XPath {@code string-length(x) = 0}: nulo o vacío (un texto de solo espacios SÍ cuenta como con valor). */
    private static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    /** Respuesta de error. */
    public UpdateOfferResponse error(String step, Throwable cause) {
        return build(props.getErrorCode(), props.getErrorText(), step, detail(cause));
    }

    /** Texto del log cuando el evento se publicó en Kafka. */
    public String kafkaSuccessText() {
        return format(props.getKafkaSuccessText(), "", "");
    }

    /** Texto del log cuando Kafka está desactivado: no se envió nada. */
    public String kafkaDisabledText() {
        return format(props.getKafkaDisabledText(), "", "");
    }

    /** Texto del log cuando el modo de Kafka es dry-run: el mensaje no se publica. */
    public String kafkaDryRunText() {
        return format(props.getKafkaDryRunText(), "", "");
    }

    /** Texto del log cuando el evento no se envió a Kafka. */
    public String kafkaErrorText(String step, String detail) {
        return format(props.getKafkaErrorText(), step, detail);
    }

    /** Igual que {@link #kafkaErrorText(String, String)}, tomando la causa más profunda de la excepción. */
    public String kafkaErrorText(String step, Throwable cause) {
        return format(props.getKafkaErrorText(), step, detail(cause));
    }

    private UpdateOfferResponse build(String code, String textTemplate, String step, String detail) {
        UpdateOfferResponse r = new UpdateOfferResponse();
        r.setCode(code);
        r.setDescription(format(textTemplate, step, detail));
        return r;
    }

    private String format(String template, String step, String detail) {
        return template
                .replace("{dateTime}", dateTime())
                .replace("{step}", step == null ? "" : step)
                .replace("{detail}", detail == null ? "" : detail);
    }

    /** Fecha y hora actuales en la zona ECRM con el formato configurado. */
    String dateTime() {
        return ZonedDateTime.now(clock.withZone(ZoneId.of(ecrmTimeZone)))
                .format(DateTimeFormatter.ofPattern(props.getDateFormat()));
    }

    /** Mensaje de la causa más profunda; si no tiene, el nombre de su clase. */
    private static String detail(Throwable cause) {
        if (cause == null) return "";
        Throwable root = cause;
        while (root.getCause() != null && root.getCause() != root) root = root.getCause();
        return root.getMessage() != null ? root.getMessage() : root.getClass().getSimpleName();
    }
}
