package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** DateTimeGrp* (lista del resultado de MapRequest). */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DateTimeGrpDTO {

    @NotNull private String dateTime;
    @NotNull private String dateTimeStatus;

    private String dateTimeName;
}
