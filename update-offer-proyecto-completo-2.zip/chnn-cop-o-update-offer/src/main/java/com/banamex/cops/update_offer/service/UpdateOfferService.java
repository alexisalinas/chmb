package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;

import java.util.List;

/** Contrato del servicio que atiende la actualización de ofertas. */
public interface UpdateOfferService {

    /** Actualiza las ofertas existentes con los datos de la petición. */
    List<UpdateOfferResponse> updateOffer(List<UpdateOfferRequest> requests, UpdateOfferHeaders headers);
}
