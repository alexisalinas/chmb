package com.banamex.cops.update_offer.dto.suppression;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Start/Request/RequestParams. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StartRequestParams {

    private String requestingChannel;

    @NotBlank(message = "El campo CountryCode es obligatorio")
    private String countryCode;

    @NotBlank(message = "El campo CurrentOperationName es obligatorio")
    private String currentOperationName;
}
