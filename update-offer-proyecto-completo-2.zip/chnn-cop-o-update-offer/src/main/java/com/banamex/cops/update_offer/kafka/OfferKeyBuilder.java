package com.banamex.cops.update_offer.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/** Arma las claves a partir de los valores SIN modificar (como llegan en el request). */
@Component
@RequiredArgsConstructor
public class OfferKeyBuilder {

    private final OfferKafkaProps props;

    /**
     * Arma la clave de la oferta para la consulta ({@code D_OFFERPALETTE.EXTID$}):
     * {@code off:mx:campaña:ola:cliente[:cuenta]}.
     */
    public String offerKey(String campaignId, String waveId, String customerNo, String accountNo) {
        return props.getOfferPrefix() + join(props.getKeySeparator(), campaignId, waveId, customerNo, accountNo, null);
    }

    /** Arma el {@code RefID} del evento, igual que {@code KafkaSenderDashboard} en BW. */
    public String refId(String campaignId, String waveId, String customerNo, String accountNo, String cardNumber) {
        boolean cuentaYTarjeta = hasText(accountNo) && hasText(cardNumber);
        return cuentaYTarjeta
                ? join("_", campaignId, waveId, customerNo, accountNo, cardNumber)
                : join("_", campaignId, waveId, customerNo, null, null);
    }

    private static boolean hasText(String s) {
        return s != null && !s.isBlank();
    }

    /** Arma la clave de la ola con su canal ({@code D_WAVECHINFO.EXTID$}). */
    public String waveKey(String waveId, String channel) {
        return props.getWavePrefix() + waveId + props.getKeySeparator() + channel;
    }

    /** Campaña, ola y cliente siempre van; cuenta y tarjeta solo si traen valor. */
    private static String join(String sep, String campaignId, String waveId, String customerNo,
                               String accountNo, String cardNumber) {
        StringBuilder sb = new StringBuilder();
        sb.append(campaignId).append(sep).append(waveId).append(sep).append(customerNo);
        if (!isBlank(accountNo)) sb.append(sep).append(accountNo);
        if (!isBlank(cardNumber)) sb.append(sep).append(cardNumber);
        return sb.toString();
    }

    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
