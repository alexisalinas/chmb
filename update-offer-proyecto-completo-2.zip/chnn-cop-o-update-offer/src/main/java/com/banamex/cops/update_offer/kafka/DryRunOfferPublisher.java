package com.banamex.cops.update_offer.kafka;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/** Modo de prueba: no envía nada. */
@Slf4j
@Component
@ConditionalOnProperty(name = "offer.kafka.mode", havingValue = "dry-run", matchIfMissing = true)
public class DryRunOfferPublisher implements OfferPublisher {

    /** No publica nada: solo avisa en el log que se está en modo de prueba. */
    @Override
    public String publish(String refId, String json) {
        log.debug("[KAFKA] dry-run: no se publicó refId={}", refId);
        return "dry-run";
    }
}
