package com.banamex.cops.update_offer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

/** Arranque del microservicio {@code chnn-cop-o-update-offer}. */
@SpringBootApplication(scanBasePackages = "com.banamex.cops.update_offer")
@EntityScan(basePackages = {"com.banamex.cops.update_offer", "com.banamex.cops.app"})
public class UpdateOfferApplication {

    public static void main(String[] args) {
        SpringApplication.run(UpdateOfferApplication.class, args);
    }
}
