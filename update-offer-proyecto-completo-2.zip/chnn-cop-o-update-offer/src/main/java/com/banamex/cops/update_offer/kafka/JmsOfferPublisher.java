package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.mapper.XmlUtil;
import jakarta.jms.DeliveryMode;
import jakarta.jms.MessageProducer;
import jakarta.jms.TextMessage;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Lazy;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

/**
 * Publica el evento en la cola JMS que lee el bridge hacia Kafka (equivale al JMS Queue Sender
 * {@code KafkaMsgSender} de BW).
 */
@Component
@ConditionalOnProperty(name = "offer.kafka.mode", havingValue = "jms")
public class JmsOfferPublisher implements OfferPublisher {

    private final JmsTemplate jms;
    private final OfferKafkaProps props;

    /** Crea el publicador por JMS. */
    public JmsOfferPublisher(@Qualifier("updateOfferJmsTemplate") @Lazy JmsTemplate jms, OfferKafkaProps props) {
        this.jms = jms;
        this.props = props;
    }

    /**
     * Deja en la cola el mensaje: el JSON del evento todo junto, o el envoltorio {@code <root>} (según
     * {@code offer.kafka.message-format}).
     */
    @Override
    public String publish(String refId, String json) throws Exception {
        String body = "envelope".equalsIgnoreCase(props.getMessageFormat())
                ? "<root><RefId>" + XmlUtil.esc(refId) + "</RefId><jsonString>" + XmlUtil.esc(json) + "</jsonString></root>"
                : json;

        return jms.execute(session -> {
            try (MessageProducer producer = session.createProducer(session.createQueue(props.getQueue()))) {
                TextMessage message = session.createTextMessage(body);
                message.setJMSCorrelationID(refId);
                message.setStringProperty("RefId", refId);
                producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
                if (props.getTimeToLiveMs() > 0) {
                    producer.setTimeToLive(props.getTimeToLiveMs());
                }
                producer.send(message);
                return message.getJMSMessageID();
            }
        }, false);
    }
}
