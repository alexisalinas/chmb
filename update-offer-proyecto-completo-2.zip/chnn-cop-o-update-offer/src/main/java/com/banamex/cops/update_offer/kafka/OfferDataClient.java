package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.app.service.CopOfferFulfillmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/** Paso 2 (BW: /BW/Kafka/DataFetch). */
@Slf4j
@Component
@RequiredArgsConstructor
public class OfferDataClient {

    private final ObjectProvider<CopOfferFulfillmentService> service;

    /** Trae los datos de cumplimiento de una oferta. */
    public Optional<CopOfferFulfillment> find(String waveKey, String offerKey) {
        CopOfferFulfillmentService s = service.orderedStream().findFirst().orElse(null);
        if (s == null) {
            throw new IllegalStateException("CopOfferFulfillmentService no está disponible: revisa que exista "
                    + "OfferFulfillmentConfig (registra la consulta de la librería) y que haya un spring.datasource configurado");
        }
        List<CopOfferFulfillment> rows = s.findByWaveKeyAndOfferKey(waveKey, offerKey);
        if (rows != null && rows.size() > 1) {
            log.warn("KAFKA-MULTI-ROWS la consulta devolvió {} filas; se usa la primera. waveKey={} offerKey={}",
                    rows.size(), waveKey, offerKey);
        }
        return rows == null ? Optional.empty() : rows.stream().findFirst();
    }
}
