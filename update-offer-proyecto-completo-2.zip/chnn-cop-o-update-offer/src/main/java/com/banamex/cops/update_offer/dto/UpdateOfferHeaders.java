package com.banamex.cops.update_offer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;
import java.util.TreeMap;

/** Headers HTTP de la petición. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOfferHeaders {
    private String uuid;
    private String host;
    private String channelId;
    private String countryCode;
    private String businessCode;
    private String sid;
    private String acceptLanguage;

    @Builder.Default
    private Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

    /** Valor del header con ese nombre (sin distinguir mayúsculas) o null si no llegó. */
    public String get(String name) {
        return name == null || all == null ? null : all.get(name);
    }
}
