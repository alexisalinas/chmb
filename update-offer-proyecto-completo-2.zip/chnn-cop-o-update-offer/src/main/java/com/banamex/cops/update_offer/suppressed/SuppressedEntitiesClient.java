package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;

/**
 * Equivale a la actividad {@code GetListOfSuppressedEntities} del proceso de BW: entrega la lista de entidades
 * suprimidas.
 */
public interface SuppressedEntitiesClient {

    /** Devuelve la lista de entidades suprimidas. */
    SuppressedEntitiesListRoot getListOfSuppressedEntities(StartRequestParams params);
}
