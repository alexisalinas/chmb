package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionList;
import com.banamex.cops.update_offer.dto.suppression.StartRequest;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

/** Equivale al subproceso /BW/Common/PerformSuppressionCheck */
@Slf4j
@Service
public class PerformSuppressionCheckService {

    private final SuppressedEntitiesClient suppressedEntitiesClient;
    private final SuppressionCheckService checkService;

    /** Crea el servicio. */
    public PerformSuppressionCheckService(@Qualifier("dbSuppressedEntitiesClient") SuppressedEntitiesClient suppressedEntitiesClient,
                                          SuppressionCheckService checkService) {
        this.suppressedEntitiesClient = suppressedEntitiesClient;
        this.checkService = checkService;
    }

    @Value("${cop.suppression.check-for-suppression:N}")
    private String checkForSuppression;

    /** Consulta la lista de entidades suprimidas y devuelve las que coinciden con la petición. */
    public FilteredSuppressionList perform(StartRequest request) {
        try {
            if ("Y".equals(checkForSuppression)) {
                SuppressedEntitiesListRoot suppressed =
                        suppressedEntitiesClient.getListOfSuppressedEntities(request.getRequestParams());
                return checkService.checkIfSuppressed(request, suppressed);
            }

            return empty();

        } catch (Exception ex) {
            log.error("Error en PerformSuppressionCheck", ex);
            return empty();
        }
    }

    private FilteredSuppressionList empty() {
        FilteredSuppressionList out = new FilteredSuppressionList();
        out.setResults(List.of());
        return out;
    }
}
