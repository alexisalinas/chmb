package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Map;

import static com.banamex.cops.update_offer.mapper.XmlUtil.tag;

/** UpdateOfferRequest (REST) -> XML que se manda al EMS. */
@Component
@RequiredArgsConstructor
public class UpdateOfferRequestXmlMapper {

    private final OfferEventMapper offerEventMapper;

    /**
     * Si es {@code true}, el evento va dentro de {@code <Envelope><Body>}; si es {@code false}, va solo el evento.
     */
    @Value("${update-offer.ems.envelope:true}")
    private boolean envelope;

    /** Si es {@code true}, el elemento del evento lleva su namespace como {@code xmlns} sin prefijo. */
    @Value("${update-offer.ems.xml-namespace:false}")
    private boolean xmlNamespace;

    /** BW: _ns_ del evento (namespace). */
    @Value("${update-offer.ems.event-namespace:www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer}")
    private String eventNamespace = "www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer";

    /** BW: _nm_ del evento (nombre del elemento del cuerpo). */
    @Value("${update-offer.ems.body-element:UpdateOffer}")
    private String bodyElement;

    /**
     * Arma el XML que se manda al EMS: el evento {@code UpdateOffer} con sus campos, en elementos simples, sin
     * URLs, namespaces ni prefijos.
     */
    public String toEmsXml(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                           String tzResponseCode, MapRequestResultDTO tz) {
        Map<String, String> fields = offerEventMapper.map(rq, requestTime, updatedBy, tzResponseCode, tz);

        String indent = envelope ? "      " : "";
        StringBuilder x = new StringBuilder();
        if (envelope) {
            x.append("<Envelope>\n");
            x.append("   <Body>\n");
        }
        x.append(indent).append("<").append(bodyElement)
                .append(xmlNamespace ? " xmlns=\"" + XmlUtil.esc(eventNamespace) + "\"" : "").append(">\n");
        fields.forEach((k, v) -> tag(x, indent + "   ", k, v));
        x.append(indent).append("</").append(bodyElement).append(">");
        if (envelope) {
            x.append("\n   </Body>\n");
            x.append("</Envelope>");
        }
        return x.toString();
    }

    /** Arma las propiedades del mensaje JMS (el {@code OtherProperties} del {@code JMS Queue Requestor} de BW). */
    public Map<String, String> toEmsProperties(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                                               String tzResponseCode, MapRequestResultDTO tz) {
        Map<String, String> properties = new java.util.LinkedHashMap<>();
        properties.put("_nm_", bodyElement);
        properties.put("_ns_", eventNamespace);
        properties.putAll(offerEventMapper.map(rq, requestTime, updatedBy, tzResponseCode, tz));
        return properties;
    }
}
