package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.service.CopSuppressionService;
import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/** Equivale a {@code GetListOfSuppressedEntities} y a la variable compartida de BW. */
@Slf4j
@Component
@RequiredArgsConstructor
public class DbSuppressedEntitiesClient implements SuppressedEntitiesClient {

    private final ObjectProvider<CopSuppressionService> suppressionService;
    private final StartUpSuppressionLoader loader;

    /** Timeout de las consultas (BW: COP/QueryRecords/TimeoutDefault). */
    @Value("${cop.suppression.query-timeout-seconds:30}")
    private int queryTimeoutSeconds = 30;

    /** Filas máximas de las consultas (BW: COP/Connections/BSDB/MaxConns); 0 = sin límite. */
    @Value("${cop.suppression.max-rows:0}")
    private int maxRows = 0;

    /** La "variable compartida": la lista ya armada. */
    private volatile SuppressedEntitiesListRoot cached;

    /** Devuelve la lista de entidades suprimidas; la primera vez la carga de la base. */
    @Override
    public SuppressedEntitiesListRoot getListOfSuppressedEntities(StartRequestParams params) {
        SuppressedEntitiesListRoot list = cached;
        if (list == null) {
            synchronized (this) {
                list = cached;
                if (list == null) {
                    list = load();
                    cached = list;
                }
            }
        }
        return list;
    }

    /** Vuelve a cargar la lista de la base y reemplaza la que está en memoria. */
    public synchronized SuppressedEntitiesListRoot reload() {
        SuppressedEntitiesListRoot list = load();
        cached = list;
        return list;
    }

    private SuppressedEntitiesListRoot load() {
        CopSuppressionService service = suppressionService.orderedStream().findFirst().orElseThrow(() ->
                new IllegalStateException("CopSuppressionService no está disponible: revisa que exista "
                        + "OfferFulfillmentConfig (registra las consultas de la librería) y que haya un spring.datasource configurado"));
        List<CopSuppressionChannel> channels = service.findAllChannels(queryTimeoutSeconds, maxRows);
        List<CopSuppressionOperation> operations = service.findAllOperations(queryTimeoutSeconds, maxRows);
        SuppressedEntitiesListRoot list = loader.build(channels, operations);
        log.debug("startUpSuppression: {} entidades suprimidas cargadas", list.getSuppressedEntities().size());
        return list;
    }
}
