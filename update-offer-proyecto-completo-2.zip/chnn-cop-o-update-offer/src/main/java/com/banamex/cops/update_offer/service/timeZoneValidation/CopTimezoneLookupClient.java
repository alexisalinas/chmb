package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.app.model.CopTimezoneLookup;
import com.banamex.cops.app.service.CopTimezoneLookupService;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Equivale a la actividad JDBC LookupTZ de BW: consulta COP_TIMEZONE_LOOKUP a través de la librería cops-bd
 * (CopTimezoneLookupService).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CopTimezoneLookupClient implements TimeZoneLookupClient {

    private final ObjectProvider<CopTimezoneLookupService> lookupService;

    /** {@inheritDoc} */
    @Override
    public List<TzLookUpDTO> find(String system, String sysMode, String type) {
        CopTimezoneLookupService service = lookupService.orderedStream().findFirst().orElse(null);
        if (service == null) {
            log.warn("CopTimezoneLookupService no está disponible (¿BD sin configurar?); sin lookup de zona horaria");
            return List.of();
        }
        return service.findBySystemNameAndModeAndOperationType(system, sysMode, type).stream()
                .map(this::toDto)
                .toList();
    }

    /** Los ocho campos del LookUp son obligatorios en el esquema: un NULL de la BD se convierte en "". */
    private TzLookUpDTO toDto(CopTimezoneLookup r) {
        TzLookUpDTO d = new TzLookUpDTO();
        d.setSystemName(nz(r.tzSystemName()));
        d.setMode(nz(r.tzMode()));
        d.setTimeZone(nz(r.tzTimezone()));
        d.setType(nz(r.tzOperationType()));
        d.setTimeOffset(nz(r.tzTimeOffset()));
        d.setDateFormat(nz(r.tzDateFormat()));
        d.setTimeFormat(nz(r.tzTimeFormat()));
        d.setDateTimeFormat(nz(r.tzDatetimeFormat()));
        return d;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
