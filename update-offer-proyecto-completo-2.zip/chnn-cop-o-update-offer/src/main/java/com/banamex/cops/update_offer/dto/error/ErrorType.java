package com.banamex.cops.update_offer.dto.error;

/** Tipo de mensaje de error que devuelve la API: {@code ERROR}, {@code WARNING} o {@code INFO}. */
public enum ErrorType {
    ERROR,
    WARNING,
    INFO
}
