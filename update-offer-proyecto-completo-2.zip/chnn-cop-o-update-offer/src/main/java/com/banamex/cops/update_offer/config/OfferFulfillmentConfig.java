package com.banamex.cops.update_offer.config;

import com.banamex.cops.app.repository.CopOfferFulfillmentRepository;
import com.banamex.cops.app.repository.CopSuppressionRepository;
import com.banamex.cops.app.service.impl.CopOfferFulfillmentServiceImpl;
import com.banamex.cops.app.service.impl.CopSuppressionServiceImpl;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/** Conecta el micro con las consultas de la librería {@code chnn-cop-lib-operation-db}. */
@Configuration
@Import({
        CopOfferFulfillmentRepository.class,
        CopOfferFulfillmentServiceImpl.class,
        CopSuppressionRepository.class,
        CopSuppressionServiceImpl.class
})
public class OfferFulfillmentConfig {
}
