package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.function.Supplier;

/** Paso 0 (BW: actividad KafkaSenderDashboard dentro de OpUpdateOffer). */
@Component
@RequiredArgsConstructor
public class KafkaSenderDashboard {

    /** Zona de la hora del evento (ResponseTime): la misma ECRMTimeZone de las globales (US/Central). */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone = "US/Central";

    /** Genera el ESBUUID (un GUID, como en BW). */
    private Supplier<String> esbUuidGenerator = () -> UUID.randomUUID().toString();

    private static final DateTimeFormatter TRANSACTION_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    private static final DateTimeFormatter WITH_OFFSET = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    private final OfferKeyBuilder keys;

    /** Arma el evento de entrada del envío a Kafka con el request, los headers HTTP y la respuesta del EMS. */
    public OfferInput build(UpdateOfferRequest rq, UpdateOfferHeaders headers, LocalDateTime requestTime,
                            UpdateOfferResponse rs) {
        LocalDateTime time = requestTime != null ? requestTime : LocalDateTime.now();
        return OfferInput.builder()
                .uuid(headers.getUuid())
                .esbUuid(esbUuidGenerator.get())
                .channel(rq.getChannelCode())
                .transactionTime(time.format(TRANSACTION_TIME))
                .refId(keys.refId(rq.getCampaignId(), rq.getWaveId(), rq.getCustomerId(), rq.getAccountNumber(), rq.getCardNumber()))
                .offerKey(keys.offerKey(rq.getCampaignId(), rq.getWaveId(), rq.getCustomerId(), rq.getAccountNumber()))
                .campaignId(rq.getCampaignId())
                .waveId(rq.getWaveId())
                .customerNo(rq.getCustomerId())
                .accountNo(rq.getAccountNumber())
                .cardNumber(rq.getCardNumber())
                .offerStatus(rq.getOfferStatus())
                .actionId(rq.getOfferActionCode())
                .responseTime(OffsetDateTime.now(ZoneId.of(ecrmTimeZone)).format(WITH_OFFSET))
                .responseCode(rs != null ? rs.getCode() : null)
                .responseText(rs != null ? rs.getDescription() : null)
                .build();
    }
}
