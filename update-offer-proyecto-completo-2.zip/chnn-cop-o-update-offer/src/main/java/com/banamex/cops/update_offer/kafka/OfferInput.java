package com.banamex.cops.update_offer.kafka;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Paso 0: evento de entrada (lo que arma KafkaSenderDashboard en BW). */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OfferInput {

    private String uuid;
    private String esbUuid;
    private String channel;
    private String transactionTime;

    private String refId;
    private String offerKey;
    private String campaignId;
    private String waveId;
    private String customerNo;
    private String accountNo;
    private String cardNumber;
    private String offerStatus;
    private String actionId;
    private String responseTime;
    private String responseCode;
    private String responseText;
}
