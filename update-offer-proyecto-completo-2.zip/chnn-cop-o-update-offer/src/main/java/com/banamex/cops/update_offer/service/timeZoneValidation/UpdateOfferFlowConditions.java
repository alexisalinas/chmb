package com.banamex.cops.update_offer.service.timeZoneValidation;

/** Condiciones de las transiciones de {@code OpUpdateOffer} que dependen de la zona horaria. */
public final class UpdateOfferFlowConditions {

    private UpdateOfferFlowConditions() {
    }

    /**
     * Condición de la transición hacia {@code RequestTimeZoneValidation}: la global {@code TranslateTimeZone} vale
     * {@code true}, sin distinguir mayúsculas.
     */
    public static boolean translateTimeZone(String translateTimeZone) {
        return "true".equalsIgnoreCase(translateTimeZone);
    }

    /** Condición de la transición hacia {@code PerformSuppressionCheck}. */
    public static boolean continueToSuppression(String tzResponseCode) {
        if (tzResponseCode == null || tzResponseCode.isEmpty()) {
            return false;
        }
        return tzResponseCode.endsWith("0") || "COP_TZCOD_114".equals(tzResponseCode);
    }
}
