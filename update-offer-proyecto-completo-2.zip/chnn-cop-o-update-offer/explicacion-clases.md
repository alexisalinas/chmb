# UpdateOffer: de TIBCO BW a Spring Boot

## 1. Flujo completo (BW → Java)

| Paso en BW (`OpUpdateOffer`) | Clase Java | Método |
|---|---|---|
| Start (recibe SOAP/REST) | `UpdateOfferController` | `updateOffer(...)` |
| Validación de headers (el ESB los exigía) | `HeaderValidation` (tuya) | `preHandle(...)` |
| Log service request | `AuditLogService` | `logRequest(headers, requests)`: escribe los headers recibidos y el JSON del body |
| RequestTimeZoneValidation | `TimeZoneValidationService` | `validate(...)` |
| PerformSuppressionCheck | `PerformSuppressionCheckService` | `perform(...)` |
| JMS Queue Requestor (Input) | `OfferEventMapper` + `UpdateOfferRequestXmlMapper` | `map(...)` + `toEmsXml(...)` |
| JMS Queue Requestor (envío / espera de respuesta) | `EmsSender` | `send(xml)` |
| Parse JSON / RsUpdateOffer | `UpdateOfferResponseXmlMapper` | `fromReply(...)` |
| Log service response + `End` | `AuditLogService` | `logResponse(headers, responses)`: escribe el JSON que responde el micro |
| `updateOffer(...)` / `procesarOferta(...)` | `updateOffer` escribe el log del request, procesa cada oferta y escribe el log de la respuesta; `procesarOferta` crea el `RqHeader` y ejecuta el flujo. | Secuencia `GetContext → RequestTimeZoneValidation → PerformSuppressionCheck → JMS Queue Requestor → End`. |

## 2. Decisiones que tomé para que se comporte como BW

1. **XML al EMS = `Envelope/Body` con el evento `UpdateOffer`** (sin `RqHeader` ni `ClientDetails`), en elementos simples: **sin URLs, sin namespaces y sin prefijos**. En el `Body` va el evento `UpdateOffer` cuyos hijos son los `OtherProperties` del JMS Queue Requestor. `_nm_` no es un campo: es el nombre del elemento del evento (`update-offer.ems.body-element`).
2. **Los logs del micro son JSON**: `[REQUEST]` (headers recibidos + body), `[EMS] Envía` / `[EMS] Responde`, `[KAFKA] Recibe` / `[KAFKA] Envía` y `[RESPONSE]`. No hay logs en los subprocesos.
3. **Campos obligatorios de BW (ABC sin `?`) siempre se escriben**, vacíos si no hay dato (`AccountNO`, `CardNO`, `ApptStartTime`, `ApptEndTime`, `ReasonCode`, `Comments`, `UserField1..20`, `UserField29`, etc.). Los opcionales (`ABC?`) solo si traen valor.
4. **Lógica oculta de las capturas**: `ApptDate`, `ApptStartTime`, `UpdateTime` y `CustomerNO` se calculan igual que los XPath de BW (detalle en la sección 3).
5. **`ApptEndTime`**: no se ve en las capturas; lo traté igual que `ApptStartTime`.
6. **UserFields**: ya no vienen sueltos; se leen del JSON de `userText`.
7. **ControlField / LocationIndicator**: `contextType[0]` y `contextType[1]` (antes `ControlField[1]` y `[2]`).
8. **Zona horaria solo si `translate-time-zone=true`** y el `ResponseCode` termina en `'0'` (misma condición `and` que usa BW en cada campo).
9. **Respuesta del EMS**: acepta XML o JSON (en BW había un "Parse JSON"). Los nombres de campo son supuestos y se prueban los nuevos y los antiguos.
10. **Log de respuesta** una sola vez por llamada, con la lista completa de respuestas (también las de supresión, zona horaria o error).
12. **Rama del Null**: siempre va a la rama "XSD Format" del JMS Queue Requestor; `keyProcess` no decide ramas.
13. **Cola**: `citi.gcg.la.cop_163621.mx_card.offer.update`.

## 3. Clase por clase

### `controller/UpdateOfferController`
| Método | Qué hace | Relación con TIBCO |
|---|---|---|
| `updateOffer(headers…, requests)` | Recibe el POST, junta los headers HTTP en `UpdateOfferHeaders` y llama al service. Devuelve 200 con la lista de respuestas. | Evento **Start** del proceso y su operación `OpUpdateOffer`. |
| `@HeaderValidation.Required(...)` | Exige `uuid`, `ChannelId`, `sid`, `countryCode`, `businessCode`, `host`, `Accept`, `Content-Type`. | El ESB/servicio SOAP rechazaba mensajes sin `RqHeader` válido. |

### `dto/UpdateOfferHeaders`
Contenedor de los headers HTTP (`uuid`, `host`, `channelId`, `countryCode`, `businessCode`, `sid`, `acceptLanguage`). En BW esa información venía dentro del `RqHeader` del mensaje.

### `service/impl/UpdateOfferServiceImpl`
| Método | Qué hace | TIBCO |
|---|---|---|
| `updateOffer(requests, headers)` | Procesa cada request de la lista. | Una ejecución del proceso por mensaje. |
| `ejecutar(...)` | Zona horaria → supresión → arma XML → EMS → convierte respuesta. | Transiciones del diagrama (`lower-case(TranslateTimeZone)="true"`, `Suppressed channel`, `Otherwise`). |
| `dates(...)`, `times(...)` | Arman las listas `Start/root/Date` y `Time` para la validación de zona horaria. | `Start/root/Date[]`, `Time[]` de `TimeZoneValidation`. |
| `checkSuppression(...)` | Llama a `PerformSuppressionCheckService`; si hay un detalle con `indicator=true` responde con su código y texto sin llamar al EMS. | Subproceso **PerformSuppressionCheck** y la rama `Suppressed channel`. |

### `mapper/UpdateOfferMapper` (fachada)
Solo delega: `toEmsXml`, `toRestResponse` y `toRestResponses`. Reemplaza al antiguo `updateofferMapper.toSoapRequest/toRestResponse`.

### `mapper/OfferEventMapper` (el corazón: pestaña **Input** del JMS Queue Requestor)
| Parte | Qué hace | XPath de BW |
|---|---|---|
| `map(...)` | Devuelve los campos del evento en el mismo orden que el mapper de BW. | `ActivityInput/OtherProperties` |
| `AccountNO`, `CardNO` | Valor o `""` | `if(AccountNo != "") then … else ""` |
| `ApptDate` | Solo si hay fecha. Con zona horaria: fecha convertida `Date[DateName="AppointmentDate"]`; si no, la original. | `if(ResponseCode termina en '0' and TranslateTimeZone="true") then …/Date[…]/DateVal else AppointmentDate` |
| `ApptStartTime` / `ApptEndTime` | Con zona horaria: hora convertida; si no, quita los segundos cuando viene `HH:mm:ss`. | `Choose`: `…/Time[1]/TimeVal` u `otherwise` con `count(tib:tokenize(x,':'))=3 → tib:substring-before-last(x,':')` |
| `customerNo(...)` | Con padding rellena a la izquierda; sin padding deja el valor; vacío da `""`. | `Choose` con `tib:pad-front(CustomerNo, COP/Padding/CustomerNo, COP/Padding/PadCharacter)` |
| `UpdateTime` | Con zona horaria: ahora en la zona ECRM; si no, la hora en que se recibió la petición. | `tib:translate-timezone(current-dateTime(), ECRMTimeZone)` o `RqHeader/DateAndTimeStamp` |
| `UpdatedBy` | Va vacío: el micro ya no usa el `ClientDetails`. | `$GetContext/…/ClientDetails/UserID` |
| `ControlField`, `LocationIndicator` | `contextType[0]` y `[1]`. | `ControlField[1]`, `[2]` |
| `UserField1..100` | Salen de `userText`; 1–20 y 29 siempre. | `UserFieldN` |
| `tzTime`, `tzDate`, `withoutSeconds`, `tzOk` | Auxiliares de los XPath anteriores. | `substring(ResponseCode, string-length(ResponseCode), 1) = '0'` |

### `mapper/UserTextParser`
`parse(userText)` convierte el JSON de `userText` en `UserField1..100`. En BW esos campos eran elementos sueltos del request; en el contrato nuevo viajan dentro de `userText`.

### `mapper/UpdateOfferRequestXmlMapper`
| Método | Qué hace | TIBCO |
|---|---|---|
| `toEmsXml(...)` | `Envelope/Body/<evento UpdateOffer>` (o solo el evento con `update-offer.ems.envelope: false`) con los campos de `OfferEventMapper`. | Mensaje que construye el **JMS Queue Requestor**. |

### `mapper/UpdateOfferResponseXmlMapper`
| Método | Qué hace | TIBCO |
|---|---|---|
| `fromReply(reply)` | Detecta si la respuesta es JSON o XML y la convierte a `UpdateOfferResponse`. | Actividad **Parse JSON** + mapper **RsUpdateOffer**. |

### `mapper/XmlUtil`
`tag`, `tagOrEmpty`, `esc`: escriben XML a mano y escapan caracteres. Reemplazan a JAXB (ya no existen los DTOs SOAP). Equivale a `tib:render-xml`.

### `sender/EmsSender`
| Método | Qué hace | TIBCO |
|---|---|---|
| `send(xml)` | Crea una cola temporal de respuesta, manda el `TextMessage` (no persistente, con `JMSReplyTo`), espera la respuesta (`timeout-seconds`) y la devuelve como `String`. Enmascara la tarjeta en el log de debug. | **JMS Queue Requestor**: `destinationQueue`, `replyToQueue`, `JMSExpiration` (`time-to-live-ms`) y `requestTimeout` (`timeout-seconds`). |

### `audit/AuditLogService`
Dos logs en JSON; no hay logs en los subprocesos.

| Método | Qué hace | TIBCO |
|---|---|---|
| `logRequest(headers, requests)` | Escribe `[REQUEST] uuid=...` con los **headers recibidos** y el **JSON del body**. Enmascara `cardNumber` (últimos 4 dígitos) y los headers de seguridad (`Authorization`, `Cookie`, ...). | `Log service request`, ahora sin la estructura de BW (`ClientDetails`, `ApplicationID`, ...). |
| `logResponse(headers, responses)` | Escribe `[RESPONSE] uuid=...` con el **JSON que responde el micro** (lista de ofertas). | `End` + `Log service response`, juntos. |
| `requestAuditEnabled` / `responseAuditEnabled` | `AuditPointsEnabled` es una cadena de banderas: la posición 1 activa el log del request y la 4 el de la respuesta. | Transición `Check Audit Enabled` vs `Bypass Audit Log`. |

Nunca rompe el flujo: si falla el log, escribe un `warn` y sigue.

### `config/OfferJmsProperties`
`customerPadding`, `customerPaddingLength`, `customerPaddingChar` ← `GlobalVariables/COP/Padding/CustomerPadding`, `CustomerNo`, `PadCharacter`.

### `service/timeZoneValidation/*`
| Clase | Qué hace | TIBCO |
|---|---|---|
| `TimeZoneValidationService.validate` | Caché → `InitTZ` → consulta BD → `TimeZoneMapRequest`; devuelve `ResponseCode`, `ResponseText`, formatos y grupos Date/Time. | Proceso `/BW/Common/TimeZoneValidation`. |
| `InitTZ.execute` | Busca sistema + modo + tipo en la caché. | Assign **InitTZ**. |
| `CopTimezoneLookupClient.find` | Consulta `COP_TIMEZONE_LOOKUP` con tu librería `cops-bd`. | Actividad JDBC **LookupTZ**. |
| `TimeZoneMapRequest.map` | Valida y convierte fechas/horas. | Mapper **MapRequest**. |

### Flujo Kafka (`sender/OfferFulfillmentEmsSender` y paquete `kafka/`)
Se dispara al final de `OpUpdateOffer`, después de la respuesta del EMS, y **nunca afecta la respuesta**.

| Clase | Qué hace | TIBCO |
|---|---|---|
| `KafkaSenderDashboard.build` | Paso 0: arma el evento de entrada (uuid, sid = ESBUUID, canal, RefID, datos del request y `ResponseCode`/`ResponseText` del EMS). | Actividad **KafkaSenderDashboard** en `OpUpdateOffer`. |
| `OfferFulfillmentEmsSender.sendAsync` | Encola el trabajo en un ejecutor con cola acotada; si está llena lo descarta y lo cuenta. | Llamada en segundo plano al subproceso. |
| `OfferFulfillmentEmsSender.process` | Pasos 1–5: espera `delay-ms`, consulta la BD, ensambla, aplica reglas y publica; reintenta solo fallas de infraestructura. | `/BW/Kafka/FulFillKafkaSender`. |
| `OfferFulfillmentEmsSender.assemble` | Arma `{event:{header,body}}`; `CustomerNo` a 9 dígitos después de la consulta, `AppointmentMinDur` solo si > 0, `timeStamp` siempre actual, UserFields de la BD. | Mapper + `Render JSON`. |
| `OfferKeyBuilder` | Claves `off:mx:…` (RefID y D_OFFERPALETTE.EXTID$) y `wvch:…` (D_WAVECHINFO.EXTID$). | Concatenaciones de `DataFetch`. |
| `OfferDataClient.find` | Llama a la librería `cops-bd` (`CopOfferKafkaService`) y toma la primera fila; si la librería o la BD no están, lanza error (se reintenta). | `/BW/Kafka/DataFetch` (JDBC Query). |
| *(librería cops-bd)* `CopOfferKafkaData`, `CopOfferKafkaNatives`, `CopOfferKafkaRepository`, `CopOfferKafkaService(Impl)` | Modelo, SQL (con 100 UserFields), JDBC con timeout 10 s y 100 filas, servicio. Se registran en `CopsDbAutoConfiguration`. | Conexión y query de `CitiDataStore`. |
| `OfferPublisher` → `DryRunOfferPublisher`, `JmsOfferPublisher` (y `KafkaOfferPublisher` opcional) | Paso 5: publica `{RefId, jsonString}`. `dry-run` solo escribe en el log. | **JMS Queue Sender `KafkaMsgSender`** (cola que lee el bridge). |
| `KafkaMetrics` | Contadores: enviados, sin filas, inválidos, fallidos, rechazados. | — |
| `OfferKafkaProps` | Propiedades `offer.kafka.*`. | Globales `COP/Kafka/...`. |

Códigos del log: `KAFKA-SENT`, `KAFKA-NO-ROWS`, `KAFKA-INVALID`, `KAFKA-RETRY`, `KAFKA-ERROR`, `KAFKA-REJECTED`, `KAFKA-MULTI-ROWS`.

## Notación de los DTOs (esquemas de BW)

| Símbolo en TIBCO | Significa | En Java |
|---|---|---|
| *(ninguno)* | obligatorio | `@NotBlank` (texto) o `@NotNull` (objeto, fecha, o texto que puede ir vacío como los `...Status`) |
| `?` | opcional | sin anotación |
| `*` | lista | `List<…>` con `@NotNull @Valid`, inicializada vacía; cada elemento se valida |

Las pruebas de estas reglas están en `DtoValidationTest`.

## 4. Equivalencia de nombres

| BW (`ns4` / log) | Contrato REST | Campo del evento (OtherProperties) |
|---|---|---|
| RequestingChannel | channelCode | RequestingChannel |
| CampaignID | campaignId | CampaignID |
| WaveID | waveId | WaveID |
| CustomerNo | customerId | CustomerNO |
| AccountNo | accountNumber | AccountNO |
| CardNumber | cardNumber | CardNO |
| AssignedTo | assignedTo | AgentID |
| IsConfirmed | offeredNumber | ApptConfirmation |
| ContactNumber | contactIndicatorNumber | ContactNumber / ContactInfo |
| ContactReference | customerReferenceNumber | ContactReference |
| Sysversion | schemaVersion | SysVersion |
| OfferAction | offerActionCode | OfferAction |
| GiftConfirmationNo | giftConfirmationNumber | GiftConfirmationNO |
| FulfillmentRefNo | fulfillmentTrackerFlag | FulfillmentReferencedNO |
| Amount | amount | ProbabilityAmount |
| DepartmentID / BranchID | departmentId / branchId | Department / Branch |
| OfferPriority | offerPriority | Priority |
| Workgroup | workgroupId | Workgroup |
| LVCode | levelCode | LVCode |
| DivisionID | divisionCode | DivisionID |
| RegionID | branchRegionIdentifier | RegionID |
| AreaID | areaIdentifier | AreaID |
| Agentname | agentName | AgentName |
| ChannelResponse | responseChannel | ChannelResponse |
| FulfillmentScript | fulfillmentCode | FulfillmentScript |
| UserField1..N | userText (JSON) | UserField1..N |
| ControlField[n] | contextType[n] | ControlField / LocationIndicator |
| processVersion | keyProcess | (sin uso todavía) |
| ReferenceContacto *(respuesta)* | customerReferenceNumber | — |
| ModeCmp *(respuesta)* | surveyModeCode | — |

## 5. Pendientes / supuestos
- Nombre del elemento del cuerpo del mensaje al EMS y nombres de campo de la respuesta.
- `ApptEndTime` y las conversiones de Time / DateTime en el request de zona horaria.
- Código de error de fecha/hora inválida (`COP_TZCOD_101` es inventado).
