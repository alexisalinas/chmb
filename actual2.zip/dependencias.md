# Dependencias del micro (`pom.xml`)

Java **21**, Spring Boot **3.5.15**. Salen de los `import` de todo el código (main y pruebas).

## Aplicación

| Dependencia | Para qué | Quién la usa |
|---|---|---|
| `spring-boot-starter-web` | REST, interceptor, `ResponseEntity`, `jakarta.servlet` y las anotaciones de Jackson 2 (`@JsonProperty`, `@JsonInclude`) | `UpdateOfferController`, `HeaderValidation`; DTOs |
| `spring-boot-starter-validation` | Bean Validation (`jakarta.validation` + Hibernate Validator) | Todos los DTOs, `DtoValidator` |
| `spring-boot-starter-jms` | `JmsTemplate` y `jakarta.jms` | `EmsSender`, `JmsOfferPublisher` |
| `tools.jackson.core:jackson-databind` 3.0.0 | `JsonMapper` (Jackson 3) | `AuditLogService`, `HeaderValidation`, `UpdateOfferResponseXmlMapper`, `UserTextParser`, `FulFillkafkaSender`, `JmsOfferPublisher` |
| `springdoc-openapi-starter-webmvc-ui` 2.8.9 | `@Schema` de OpenAPI y documentación del endpoint | `RqHeaderDTO`, `ClientDetailsDTO` |
| `lombok` | `@Data`, `@Builder`, `@RequiredArgsConstructor`, `@Slf4j` | casi todas las clases |
| `ojdbc11` (runtime) | Driver de Oracle | la librería `cops-bd` |

**No necesitan dependencia:** el manejo de XML (`javax.xml`, `org.w3c.dom`, `org.xml.sax`) viene en el JDK.
**No se incluye `spring-kafka`:** solo lo usa `KafkaOfferPublisher`, que está fuera de `src` (`kafka-opcional/`).

## Librerías corporativas (en el `pom.xml` están como comentario, para que pongas tus coordenadas)

| Librería | Qué aporta |
|---|---|
| `cops-bd-libary` | `CopOfferFulfillmentService`, `CopTimezoneLookupService` y su JPA/JDBC |
| Mensajería JMS/EMS | Lee `digital-integration.messaging.*` del yml y crea el `updateOfferJmsTemplate` |
| `tibjms` 8.7.0 | Cliente TIBCO EMS (normalmente llega con la de mensajería) |
| `digital-engineering` | Manejador global de excepciones (si lo usas) |

## Pruebas

| Dependencia | Qué trae |
|---|---|
| `spring-boot-starter-test` | JUnit 5, Mockito 5 (modo *inline*, necesario para simular `JsonMapper`), AssertJ, Spring Test (`MockMvc`), JsonPath y Logback (`ListAppender` de las pruebas de log) |

## JaCoCo (cobertura al 90 %)

- Versión `0.8.13`. Reporte en `target/site/jacoco/index.html` (se genera con `mvn test`).
- `mvn verify` **falla** si la cobertura global baja de **90 % en líneas** o de **90 % en ramas**. Se cambia en las propiedades `jacoco.minimum.line` y `jacoco.minimum.branch`.
- `mvn clean install -DskipTests` no falla por cobertura (sin pruebas no hay datos que revisar).
- Excluidas: `UpdateOfferApplication`, `KafkaExecutorConfig`, `jmsConfig` y `SecurityConfig`.
- `lombok.config` pone `lombok.addLombokGeneratedAnnotation = true` para que no se cuente el código que genera Lombok.

## Ojo con Jackson 3

Spring Boot 3.5 trae Jackson 2 y **no crea un bean de `JsonMapper` de Jackson 3**. El código lo inyecta (por ejemplo en `HeaderValidation` y `AuditLogService`). Si tu proyecto ya tiene ese bean (por la librería corporativa o por una clase de configuración), no hay nada que hacer; si no, el arranque falla con "No qualifying bean of type JsonMapper" y hay que declarar uno:

```java
@Bean
@ConditionalOnMissingBean
JsonMapper jsonMapper() {
    return JsonMapper.builder().build();
}
```

También sube el BOM de Jackson 2 a 2.20.0 (`jackson-bom.version`), porque Jackson 3.0 necesita `jackson-annotations` 2.20.
