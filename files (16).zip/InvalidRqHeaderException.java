package com.banamex.cops.update_offer.service;

/**
 * Los headers HTTP no permiten armar un RqHeader válido (falta el uuid o un campo obligatorio del
 * RqHeader / ClientDetails). El controller la responde con 400 y un ErrorResponse.
 */
public class InvalidRqHeaderException extends IllegalArgumentException {

    public InvalidRqHeaderException(String message) {
        super(message);
    }
}
