package com.banamex.cops.update_offer.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Nombres de los headers HTTP por los que llega el GetContext (RqHeader y ClientDetails).
 * Por defecto son los nombres de los elementos del esquema de BW; si el API Gateway usa otros,
 * se cambian en update-offer.header-names.* sin tocar código. Los nombres de HTTP no distinguen mayúsculas.
 *
 * Los headers del swagger siguen con su nombre: uuid (UUID), ChannelId (ChannelID), countryCode
 * (SrcCountryCode / DestCountryCode si no vienen sus propios headers) y Accept-Language (SessionLanguageCode).
 */
@Data
@Component
@ConfigurationProperties(prefix = "update-offer.header-names")
public class HeaderNamesProperties {

    // RqHeader
    private String dateAndTimeStamp = "DateAndTimeStamp";
    private String esbUuid = "ESBUUID";
    private String serviceTimeout = "ServiceTimeout";
    private String version = "Version";

    // ClientDetails
    private String org = "Org";
    private String orgUnit = "OrgUnit";
    private String terminalId = "TerminalID";
    private String clientIpAddress = "ClientIPAddress";
    private String userId = "UserID";
    private String srcCountryCode = "SrcCountryCode";
    private String destCountryCode = "DestCountryCode";
    private String userDomicileBranchCode = "UserDomicileBranchCode";
    private String userDomicileResponsibilityCentre = "UserDomicileResponsibilityCentre";
    private String processingBranchCode = "ProcessingBranchCode";
    private String processingResponsibilityCentre = "ProcessingResponsibilityCentre";
    private String userGroup = "UserGroup";
    private String sessionLanguageCode = "SessionLanguageCode";
}
