package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.config.HeaderNamesProperties;
import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.log.header.ClientDetailsDTO;
import com.banamex.cops.update_offer.dto.log.header.RqHeaderDTO;
import com.banamex.cops.update_offer.validation.DtoValidator;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Arma el RqHeader (equivale al GetContext de BW). CONFIRMADO: el GetContext llega en los headers HTTP.
 *
 *  UUID .......................... header uuid (no se genera)
 *  ESBUUID ....................... header ESBUUID si llega; si no, uuid + yyyyMMddHHmmss
 *  DateAndTimeStamp .............. header DateAndTimeStamp si llega; si no, la hora actual
 *  ServiceTimeout, Version ....... headers del mismo nombre (opcionales)
 *  ClientDetails/ChannelID ....... header ChannelId
 *  ClientDetails/Src y DestCountryCode ... headers SrcCountryCode y DestCountryCode; si no llegan, countryCode
 *  ClientDetails/SessionLanguageCode ..... header SessionLanguageCode; si no llega, se deriva de Accept-Language
 *  ClientDetails/(demás campos) .. header con el nombre del campo (Org, OrgUnit, TerminalID, UserID, ...)
 *
 * Los nombres de los headers son configurables (HeaderNamesProperties). Sin valores por defecto: si falta un
 * obligatorio se rechaza con InvalidRqHeaderException (400) y el detalle de qué falta.
 * UserID es obligatorio pero puede ir vacío (en el log de BW las llamadas de IVR traen UserID vacío).
 */
@Component
public class RqHeaderFactory {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private final DtoValidator validator;
    private final HeaderNamesProperties names;

    public RqHeaderFactory(DtoValidator validator, HeaderNamesProperties names) {
        this.validator = validator;
        this.names = names;
    }

    public RqHeaderDTO create(UpdateOfferHeaders h) {
        if (!hasText(h.getUuid())) {
            throw new InvalidRqHeaderException("El header uuid es obligatorio: el UUID no se genera, viene en el header");
        }
        String uuid = h.getUuid();
        LocalDateTime now = LocalDateTime.now();
        String esbUuid = h.get(names.getEsbUuid());

        RqHeaderDTO header = RqHeaderDTO.builder()
                .dateTimeStamp(timestamp(h.get(names.getDateAndTimeStamp()), now))
                .uuid(uuid)
                .esbUuid(hasText(esbUuid) ? esbUuid : uuid + now.format(TS))
                .serviceTimeout(h.get(names.getServiceTimeout()))
                .version(h.get(names.getVersion()))
                .clientDetails(ClientDetailsDTO.builder()
                        .org(h.get(names.getOrg()))
                        .orgUnit(h.get(names.getOrgUnit()))
                        .channelID(h.getChannelId())
                        .terminalID(h.get(names.getTerminalId()))
                        .clientIPAddress(h.get(names.getClientIpAddress()))
                        .userID(h.get(names.getUserId()))
                        .srcCountryCode(firstText(h.get(names.getSrcCountryCode()), h.getCountryCode()))
                        .destCountryCode(firstText(h.get(names.getDestCountryCode()), h.getCountryCode()))
                        .userDomicileBranchCode(h.get(names.getUserDomicileBranchCode()))
                        .userDomicileResponsibilityCentre(h.get(names.getUserDomicileResponsibilityCentre()))
                        .processingBranchCode(h.get(names.getProcessingBranchCode()))
                        .processingResponsibilityCentre(h.get(names.getProcessingResponsibilityCentre()))
                        .userGroup(h.get(names.getUserGroup()))
                        .sessionLanguageCode(firstText(h.get(names.getSessionLanguageCode()), language(h.getAcceptLanguage())))
                        .build())
                .build();
        try {
            validator.validateOrThrow(header);
        } catch (IllegalArgumentException e) {
            throw new InvalidRqHeaderException(e.getMessage());
        }
        return header;
    }

    /** Acepta "2026-08-31T17:51:50.371-06:00" (con offset) o "2026-08-28T11:18:28.903" (sin offset). */
    private LocalDateTime timestamp(String value, LocalDateTime fallback) {
        if (!hasText(value)) {
            return fallback;
        }
        String v = value.trim();
        try {
            return OffsetDateTime.parse(v).atZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();
        } catch (DateTimeParseException withOffset) {
            try {
                return LocalDateTime.parse(v);
            } catch (DateTimeParseException withoutOffset) {
                throw new InvalidRqHeaderException("El header " + names.getDateAndTimeStamp()
                        + " no es una fecha válida (yyyy-MM-dd'T'HH:mm:ss[.SSS][offset]): " + value);
            }
        }
    }

    /** "es-MX,es;q=0.9" -> "ES"; null si no llega Accept-Language. */
    private String language(String acceptLanguage) {
        if (!hasText(acceptLanguage)) return null;
        String first = acceptLanguage.split("[,;]")[0].trim();
        String lang = first.split("-")[0].trim();
        return lang.isEmpty() ? null : lang.toUpperCase();
    }

    private static String firstText(String first, String second) {
        return hasText(first) ? first : second;
    }

    private static boolean hasText(String s) { return s != null && !s.trim().isEmpty(); }
}
