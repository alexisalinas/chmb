package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.config.HeaderNamesProperties;
import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.log.header.ClientDetailsDTO;
import com.banamex.cops.update_offer.dto.log.header.RqHeaderDTO;
import com.banamex.cops.update_offer.testutil.TestData;
import com.banamex.cops.update_offer.validation.DtoValidator;
import jakarta.validation.Validation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Map;
import java.util.TreeMap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RqHeaderFactoryTest {

    private HeaderNamesProperties names;
    private RqHeaderFactory factory;

    @BeforeEach
    void setUp() {
        names = new HeaderNamesProperties();
        factory = new RqHeaderFactory(new DtoValidator(Validation.buildDefaultValidatorFactory().getValidator()), names);
    }

    /** Llamada mínima válida: lo obligatorio del RqHeader y de ClientDetails. */
    private Map<String, String> minimos() {
        Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        all.put("Org", "1");
        all.put("OrgUnit", "1");
        all.put("TerminalID", "0001");
        all.put("UserID", "92023797");
        return all;
    }

    private UpdateOfferHeaders con(Map<String, String> all) {
        return UpdateOfferHeaders.builder().uuid("uuid-1").channelId("CAT").countryCode("MX").all(all).build();
    }

    // ------------------------------------------------------------ uuid

    @Test
    void sinUuid_lanzaInvalidRqHeaderException() {
        assertThatThrownBy(() -> factory.create(new UpdateOfferHeaders()))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("uuid");
    }

    @Test
    void uuidEnBlanco_tambienSeRechaza() {
        assertThatThrownBy(() -> factory.create(UpdateOfferHeaders.builder().uuid("  ").build()))
                .isInstanceOf(InvalidRqHeaderException.class);
    }

    @Test
    void elUuidSeToma_delHeader_yNoSeGenera() {
        assertThat(factory.create(TestData.headers()).getUuid()).isEqualTo("uuid-1");
    }

    // ------------------------------------------------------------ GetContext desde los headers

    @Test
    void clientDetails_seLeeDeLosHeaders() {
        Map<String, String> all = minimos();
        all.put("ClientIPAddress", "10.1.2.3");
        all.put("UserDomicileBranchCode", "00071");
        all.put("UserDomicileResponsibilityCentre", "0100101999");
        all.put("ProcessingBranchCode", "0100");
        all.put("ProcessingResponsibilityCentre", "1234567890");
        all.put("UserGroup", "PWS");
        all.put("SessionLanguageCode", "EN");

        ClientDetailsDTO c = factory.create(con(all)).getClientDetails();

        assertThat(c.getOrg()).isEqualTo("1");
        assertThat(c.getOrgUnit()).isEqualTo("1");
        assertThat(c.getChannelID()).isEqualTo("CAT");
        assertThat(c.getTerminalID()).isEqualTo("0001");
        assertThat(c.getUserID()).isEqualTo("92023797");
        assertThat(c.getClientIPAddress()).isEqualTo("10.1.2.3");
        assertThat(c.getUserDomicileBranchCode()).isEqualTo("00071");
        assertThat(c.getUserDomicileResponsibilityCentre()).isEqualTo("0100101999");
        assertThat(c.getProcessingBranchCode()).isEqualTo("0100");
        assertThat(c.getProcessingResponsibilityCentre()).isEqualTo("1234567890");
        assertThat(c.getUserGroup()).isEqualTo("PWS");
        assertThat(c.getSessionLanguageCode()).isEqualTo("EN");
    }

    @Test
    void losOpcionalesQueNoLlegan_quedanNulos_sinValoresPorDefecto() {
        RqHeaderDTO h = factory.create(con(minimos()));

        assertThat(h.getVersion()).isNull();
        assertThat(h.getServiceTimeout()).isNull();
        ClientDetailsDTO c = h.getClientDetails();
        assertThat(c.getClientIPAddress()).isNull();
        assertThat(c.getUserDomicileBranchCode()).isNull();
        assertThat(c.getUserDomicileResponsibilityCentre()).isNull();
        assertThat(c.getProcessingBranchCode()).isNull();
        assertThat(c.getProcessingResponsibilityCentre()).isNull();
        assertThat(c.getUserGroup()).isNull();
        assertThat(c.getSessionLanguageCode()).isNull();
    }

    @Test
    void versionYServiceTimeout_seLeenDeLosHeaders() {
        Map<String, String> all = minimos();
        all.put("Version", "3.0.MX.0");
        all.put("ServiceTimeout", "12000");

        RqHeaderDTO h = factory.create(con(all));

        assertThat(h.getVersion()).isEqualTo("3.0.MX.0");
        assertThat(h.getServiceTimeout()).isEqualTo("12000");
    }

    @Test
    void losNombresDeHeadersNoDistinguenMayusculas() {
        Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        all.put("org", "1");
        all.put("ORGUNIT", "1");
        all.put("terminalid", "0001");
        all.put("userid", "SYSTEM");

        ClientDetailsDTO c = factory.create(con(all)).getClientDetails();

        assertThat(c.getOrg()).isEqualTo("1");
        assertThat(c.getOrgUnit()).isEqualTo("1");
        assertThat(c.getTerminalID()).isEqualTo("0001");
        assertThat(c.getUserID()).isEqualTo("SYSTEM");
    }

    @Test
    void losNombresDeLosHeadersSonConfigurables() {
        names.setOrg("X-Org");
        names.setUserId("X-User");
        Map<String, String> all = minimos();
        all.remove("Org");
        all.remove("UserID");
        all.put("X-Org", "Citi");
        all.put("X-User", "MV00928");

        ClientDetailsDTO c = factory.create(con(all)).getClientDetails();

        assertThat(c.getOrg()).isEqualTo("Citi");
        assertThat(c.getUserID()).isEqualTo("MV00928");
    }

    // ------------------------------------------------------------ headers del swagger

    @Test
    void channelId_vieneDelHeaderChannelId() {
        assertThat(factory.create(con(minimos())).getClientDetails().getChannelID()).isEqualTo("CAT");
    }

    @Test
    void paises_sinSusPropiosHeaders_usanCountryCode() {
        ClientDetailsDTO c = factory.create(con(minimos())).getClientDetails();
        assertThat(c.getSrcCountryCode()).isEqualTo("MX");
        assertThat(c.getDestCountryCode()).isEqualTo("MX");
    }

    @Test
    void paises_conSusPropiosHeaders_tienenPrioridad() {
        Map<String, String> all = minimos();
        all.put("SrcCountryCode", "CO");
        all.put("DestCountryCode", "PE");

        ClientDetailsDTO c = factory.create(con(all)).getClientDetails();

        assertThat(c.getSrcCountryCode()).isEqualTo("CO");
        assertThat(c.getDestCountryCode()).isEqualTo("PE");
    }

    @Test
    void idioma_sinHeaderPropio_seDerivaDeAcceptLanguage() {
        UpdateOfferHeaders h = con(minimos());
        h.setAcceptLanguage("es-MX,es;q=0.9");
        assertThat(factory.create(h).getClientDetails().getSessionLanguageCode()).isEqualTo("ES");
    }

    @Test
    void idioma_conHeaderPropio_tienePrioridadSobreAcceptLanguage() {
        Map<String, String> all = minimos();
        all.put("SessionLanguageCode", "PT");
        UpdateOfferHeaders h = con(all);
        h.setAcceptLanguage("es-MX");
        assertThat(factory.create(h).getClientDetails().getSessionLanguageCode()).isEqualTo("PT");
    }

    // ------------------------------------------------------------ ESBUUID y fecha

    @Test
    void esbUuid_sinHeader_seGeneraComoUuidMasFecha() {
        String esb = factory.create(con(minimos())).getEsbUuid();
        assertThat(esb).matches("uuid-1\\d{14}");
    }

    @Test
    void esbUuid_conHeader_seUsaElDelHeader() {
        Map<String, String> all = minimos();
        all.put("ESBUUID", "57e889b8-8bbd-40a9-bf79-bf299b45c206");
        assertThat(factory.create(con(all)).getEsbUuid()).isEqualTo("57e889b8-8bbd-40a9-bf79-bf299b45c206");
    }

    @Test
    void fecha_sinHeader_esLaHoraActual() {
        LocalDateTime antes = LocalDateTime.now().minusSeconds(1);
        LocalDateTime fecha = factory.create(con(minimos())).getDateTimeStamp();
        assertThat(fecha).isAfterOrEqualTo(antes).isBeforeOrEqualTo(LocalDateTime.now().plusSeconds(1));
    }

    @Test
    void fecha_conHeaderSinOffset_seUsaTalCual() {
        Map<String, String> all = minimos();
        all.put("DateAndTimeStamp", "2026-08-28T11:18:28.903");
        assertThat(factory.create(con(all)).getDateTimeStamp()).isEqualTo(LocalDateTime.of(2026, 8, 28, 11, 18, 28, 903_000_000));
    }

    @Test
    void fecha_conHeaderConOffset_seConvierteALaZonaDelServidor() {
        Map<String, String> all = minimos();
        all.put("DateAndTimeStamp", "2026-08-31T17:51:50.371-06:00");

        LocalDateTime esperado = OffsetDateTime.parse("2026-08-31T17:51:50.371-06:00")
                .atZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();

        assertThat(factory.create(con(all)).getDateTimeStamp()).isEqualTo(esperado);
    }

    @Test
    void fecha_invalida_lanzaInvalidRqHeaderException() {
        Map<String, String> all = minimos();
        all.put("DateAndTimeStamp", "ayer");
        assertThatThrownBy(() -> factory.create(con(all)))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("DateAndTimeStamp");
    }

    // ------------------------------------------------------------ obligatorios del esquema

    @Test
    void sinLosObligatoriosDelGetContext_lanzaInvalidRqHeaderExceptionConElDetalle() {
        assertThatThrownBy(() -> factory.create(con(new TreeMap<>(String.CASE_INSENSITIVE_ORDER))))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("clientDetails.org")
                .hasMessageContaining("clientDetails.orgUnit")
                .hasMessageContaining("clientDetails.terminalID")
                .hasMessageContaining("clientDetails.userID");
    }

    @Test
    void faltaUnSoloObligatorio_loNombra() {
        Map<String, String> all = minimos();
        all.remove("TerminalID");
        assertThatThrownBy(() -> factory.create(con(all)))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("clientDetails.terminalID")
                .hasMessageNotContaining("clientDetails.org:");
    }

    @Test
    void sinChannelIdNiCountryCode_seRechaza() {
        UpdateOfferHeaders h = UpdateOfferHeaders.builder().uuid("uuid-1").all(minimos()).build();
        assertThatThrownBy(() -> factory.create(h))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("clientDetails.channelID")
                .hasMessageContaining("clientDetails.srcCountryCode")
                .hasMessageContaining("clientDetails.destCountryCode");
    }

    @Test
    void userIdVacio_esValido_comoEnLasLlamadasDeIvrDelLogDeBW() {
        Map<String, String> all = minimos();
        all.put("UserID", "");
        assertThat(factory.create(con(all)).getClientDetails().getUserID()).isEmpty();
    }

    @Test
    void userIdAusente_seRechaza_porqueElElementoEsObligatorio() {
        Map<String, String> all = minimos();
        all.remove("UserID");
        assertThatThrownBy(() -> factory.create(con(all)))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("clientDetails.userID");
    }

    @Test
    void orgVacio_seRechaza() {
        Map<String, String> all = minimos();
        all.put("Org", " ");
        assertThatThrownBy(() -> factory.create(con(all)))
                .isInstanceOf(InvalidRqHeaderException.class)
                .hasMessageContaining("clientDetails.org");
    }

    @Test
    void conTodosLosHeadersDeLaLlamadaDePrueba_noFalla() {
        RqHeaderDTO h = factory.create(TestData.headers());
        assertThat(h.getClientDetails().getOrg()).isEqualTo("1");
        assertThat(h.getClientDetails().getTerminalID()).isEqualTo("0001");
        assertThat(h.getClientDetails().getUserID()).isEqualTo("92023797");
        assertThat(h.getClientDetails().getSessionLanguageCode()).isEqualTo("ES");
    }
}
