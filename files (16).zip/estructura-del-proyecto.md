# Estructura del proyecto `chnn-cop-o-update-offer` y estado de cada clase

Estados: **Completa** (hecha; solo falta probarla contra el entorno real), **Con supuestos** (funciona, pero asume algo que hay que confirmar) e **Incompleta** (falta código o un dato para terminarla).
Los detalles de cada pendiente están en `pendientes-y-suposiciones.md`; las variables globales, en `variables-globales-bw.md`.

---

## 1. Árbol del proyecto

```
chnn-cop-o-update-offer
├─ src/main/java/com/banamex/cops/update_offer
│  ├─ UpdateOfferApplication.java ................ (tuya) arranque; escanea solo update_offer
│  ├─ controller/    UpdateOfferController
│  ├─ config/        HeaderValidation, OfferJmsProperties, jmsConfig*, SecurityConfig*, LoggingProperties*
│  ├─ constants/     Constants*, ConstantsGeneric*
│  ├─ dto/           UpdateOfferRequest, UpdateOfferResponse, ControlFieldDTO, KeyProcessEnum, UpdateOfferHeaders
│  │  ├─ error/            ErrorResponse, ErrorType
│  │  ├─ log/              LogDTO, LogHeaderDTO, AdditionalInfoDTO, RqLogDTO
│  │  │  └─ header/        RqHeaderDTO, ClientDetailsDTO
│  │  ├─ suppression/      StartRequest, StartRequestParams, SuppressedEntitiesListRoot, SuppressedEntityDTO,
│  │  │                    OperationDetailsDTO, FilteredSuppressionList, FilteredSuppressionResult,
│  │  │                    OperationDetailOutput, ResponseDetailsDTO
│  │  └─ timeZoneValidation/  TimeZoneValidationStartDTO, ValueItemDTO, TzFormatsDTO, TzLookUpDTO,
│  │                          DateGrpDTO, TimeGrpDTO, DateTimeGrpDTO, MapRequestResultDTO, TimeZoneValidationResult
│  ├─ service/       UpdateOfferService, RqHeaderFactory, LogRequestService*
│  │  ├─ impl/             UpdateOfferServiceImpl
│  │  └─ timeZoneValidation/  TimeZoneValidationService, InitTZ, TimeZoneLookupClient, CopTimezoneLookupClient,
│  │                          TimeZoneMapRequest, UpdateOfferFlowConditions*
│  ├─ suppressed/    PerformSuppressionCheckService, SuppressionCheckService*, SuppressedEntitiesClient*,
│  │                 SharedVariableSuppressedEntitiesClient*, InMemorySuppressedEntitiesClient*
│  ├─ mapper/        UpdateOfferMapper, OfferEventMapper, UpdateOfferRequestXmlMapper,
│  │                 UpdateOfferResponseXmlMapper, RqHeaderXmlMapper, UserTextParser, XmlUtil
│  ├─ sender/        EmsSender, EmsQueueNameBuilder, EmsQueueProperties, FulFillkafkaSender
│  ├─ kafka/         OfferKafkaProps, OfferInput, OfferKeyBuilder, KafkaSenderDashboard, OfferDataClient,
│  │                 OfferPublisher, DryRunOfferPublisher, JmsOfferPublisher, KafkaExecutorConfig, KafkaMetrics
│  ├─ audit/         AuditLogService, TransactionContext
│  └─ validation/    DtoValidator
├─ src/main/resources/config/update-offer.yml
├─ src/test/java/...   (34 clases de prueba + 2 de apoyo; ver sección 6)
├─ docs/               estructura-del-proyecto.md, pendientes-y-suposiciones.md, variables-globales-bw.md, kafka-sql-prueba.sql
├─ pruebas/            probar.ps1, request-ejemplo.json
└─ kafka-opcional/     KafkaOfferPublisher (solo si se usa mode=kafka; requiere spring-kafka)

cops-bd (librería, com.banamex.cops.app)
├─ model/       CopOfferFulfillment                       (nuevo)
├─ natives/     CopOfferFulfillmentNatives                (nuevo)
├─ repository/  CopOfferFulfillmentRepository             (nuevo)
├─ service/     CopOfferFulfillmentService (+ impl/)      (nuevo)
├─ autoconfigure/ CopsDbAutoConfiguration                 (tuya: hay que registrar las 2 clases nuevas en @Import)
└─ ... CopTimezoneLookup*, CopOfferQuery, etc.            (tuyas)
```
`*` = clase tuya que yo no tengo (o de una entrega anterior): se describe en la sección 4.

## 2. Flujo completo (equivalente a `OpUpdateOffer`)

```
POST /sd-campaing-management/v1/update-offer
  HeaderValidation (headers requeridos) -> UpdateOfferController
  -> UpdateOfferServiceImpl (por cada oferta):
       RqHeaderFactory ............... GetContext
       AuditLogService.logRequest .... Log service request
       TimeZoneValidationService ..... RequestTimeZoneValidation (solo si TranslateTimeZone = true)
       PerformSuppressionCheckService  PerformSuppressionCheck   (solo si CheckForSuppression = Y)
       UpdateOfferMapper.toEmsXml .... JMS Queue Requestor (Input)
       EmsSender.send ................ JMS Queue Requestor (envío y espera de respuesta)
       UpdateOfferMapper.toRestResponse  Parse JSON / RsUpdateOffer
       FulFillkafkaSender (asíncrono)  KafkaSenderDashboard + FulFillKafkaSender (si isKafkaOn_1 = true)
       AuditLogService.logResponse ... Log service response
```

---

## 3. Clases del microservicio

### 3.1 `controller` y `config`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `UpdateOfferController` | Recibe el POST con la lista de ofertas, junta los headers en `UpdateOfferHeaders`, valida `countryCode` y el body (`@Valid`) y llama al service | Definir el código HTTP cuando alguna oferta falla (hoy siempre 200 con `code: ERROR` dentro). Los errores de `@Valid` y de JSON mal formado salen con el formato del manejador global (`digital-engineering`), no con `ErrorResponse`. Falta que el service mande todas las ofertas en un solo mensaje al EMS (confirmado que BW lo hace así) | Completa |
| `HeaderValidation` | Rechaza con 400 y `ErrorResponse` si falta un header de `@Required` (`uuid`, `ChannelId`, `sid`, `countryCode`, `businessCode`, `host`, `Accept`, `Content-Type`) | Confirmar que esa lista es definitiva | Completa |
| `HeaderNamesProperties` | Nombres de los headers del GetContext (`update-offer.header-names.*`; por defecto los del esquema de BW) | Confirmar los nombres reales | Con supuestos |
| `OfferJmsProperties` | Propiedades del relleno de `CustomerNO` (activo, longitud, carácter) | Valores reales de `COP/Padding/CustomerPadding` y de la longitud (`COP/Padding/CustomerNo`): no venían en tu lista | Con supuestos |

### 3.2 `dto` (contrato de la API)

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `UpdateOfferRequest` | Cuerpo de cada oferta (4 obligatorios, resto opcional, `contextType` lista, `userText` con los UserFields) | `keyProcess` no se usa (la rama XSD es fija). El `@Pattern` de `userText` solo acepta un objeto `{...}`, no un arreglo. `offerStatus` es opcional aquí pero obligatorio para Kafka | Completa |
| `UpdateOfferResponse` | Respuesta por oferta (`code` y `description` obligatorios) | Confirmar los nombres de los campos de la respuesta real del EMS | Con supuestos |
| `ControlFieldDTO`, `KeyProcessEnum` | `ControlField` (solo `contextType`) y las versiones V1/V2/V3 | Nada | Completa |
| `UpdateOfferHeaders` | Headers del swagger en campos propios y `all` con **todos** los headers recibidos (sin distinguir mayúsculas) | Nada | Completa |
| `error/ErrorResponse`, `ErrorType` | Formato de error de la validación de headers | Nada | Completa |

### 3.3 `dto.log`, `dto.log.header`, `dto.suppression`, `dto.timeZoneValidation` (esquemas de BW)

Todos llevan la regla de BW: sin símbolo = obligatorio, `?` = opcional, `*` = lista (nunca nula, se valida cada elemento).

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `RqHeaderDTO`, `ClientDetailsDTO` | `RqHeader` y `ClientDetails` (7 obligatorios en `ClientDetails`) | El origen de varios datos (ver `RqHeaderFactory`) | Completa |
| `LogDTO`, `LogHeaderDTO`, `AdditionalInfoDTO` | Estructura del `Log` de BW: `Header` + `TimeDuration`, `TraceLevel`, `AdditionalInfo*`, `Payload`, ... | `AdditionalInfo`, `TimeDuration` y `TraceLevel` no se llenan en ninguna parte (BW tampoco los mapeaba en lo que vimos) | Completa |
| `RqLogDTO` | Entrada del subproceso LogRequest (`RqHeader` + `RqBody`) | Ya no lo usa nadie: era de `LogRequestService`. Candidata a borrar | Sin uso |
| `StartRequest`, `StartRequestParams`, `SuppressedEntitiesListRoot`, `SuppressedEntityDTO`, `OperationDetailsDTO`, `FilteredSuppressionList`, `FilteredSuppressionResult`, `OperationDetailOutput` | Entrada y salida de la validación de supresión | Nada | Completa |
| `ResponseDetailsDTO` | Salida del `End` de PerformSuppressionCheck (`ResponseDetails*`) | No se usa: el service lee `FilteredSuppressionList` directo. Borrar o usarlo | Sin uso |
| `TimeZoneValidationStartDTO`, `ValueItemDTO` | `Start` de TimeZoneValidation (`System`, `SysMode`, `Type`, `Date*`, `Time*`, `DateTime*`) | Nada | Completa |
| `TzFormatsDTO`, `TzLookUpDTO` | `Formats` y `LookUp*` (todos los campos obligatorios) | Nada | Completa |
| `DateGrpDTO`, `TimeGrpDTO`, `DateTimeGrpDTO`, `MapRequestResultDTO`, `TimeZoneValidationResult` | Resultado de `MapRequest` y de `RequestTimeZoneValidation` | Nada | Completa |

### 3.4 `service`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `RqHeaderFactory` | Arma el `RqHeader` (GetContext) leyendo **todo de los headers HTTP** (nombres en `HeaderNamesProperties`); `ESBUUID` y fecha se generan si no llegan; lo valida con `DtoValidator` y lanza `InvalidRqHeaderException` (400) si falta un obligatorio | Confirmar los nombres reales de los headers que manda el API Gateway | Con supuestos |
| `InvalidRqHeaderException` | Error de headers inválidos; el controller lo responde con 400 y `ErrorResponse` | Nada | Completa |
| `UpdateOfferService` | Contrato del service (`updateOffer(requests, headers)`) | Nada | Completa |
| `UpdateOfferServiceImpl` | Orquesta todo el flujo por oferta; valida los DTOs que arma; responde `ERROR` si algo falla; dispara Kafka sin afectar la respuesta | No implementa las ramas Counter Offer ni Json Format (indicaste que solo va la XSD). No arma el header de la respuesta (`SetContext`). Kafka solo se dispara si el EMS respondió; confirmar si BW también lo hacía con errores. Hoy manda un mensaje por oferta; confirmado que BW manda todas en uno solo (falta implementarlo) | Con supuestos |

### 3.5 `service.timeZoneValidation`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `TimeZoneValidationService` | `GetVariable` (caché) → `InitTZ` → `LookupTZ` → `SetVariable` → `MapRequest`; devuelve código y texto | Códigos `COP_TZCOD_000` y `101` (supuestos). La caché no se limpia nunca | Con supuestos |
| `InitTZ` | Busca sistema + modo + tipo en la caché y arma los `Formats` | Nada | Completa |
| `TimeZoneLookupClient`, `CopTimezoneLookupClient` | `LookupTZ`: consulta `COP_TIMEZONE_LOOKUP` por la librería; los NULL pasan a `""` | Nada (depende de que la BD esté configurada) | Completa |
| `TimeZoneMapRequest` | `MapRequest`: valida y convierte fecha, hora y fecha-hora (Request y Response) | La fecha, la hora y la fecha-hora en Request vienen de la guía, no de capturas; falta compararlas con una ejecución real. Duda con `US/Central` y el horario de verano | Con supuestos |
| `UpdateOfferFlowConditions` *(tuya)* | Condiciones de las transiciones del flujo | Nada | Completa |

### 3.6 `suppressed`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `PerformSuppressionCheckService` | `PerformSuppressionCheck`: si `CheckForSuppression = Y`, consulta la lista y aplica `CheckIfSuppressed`; si falla, devuelve vacío | El `ErrorLog` de BW es solo un `log.error`. Hoy `CheckForSuppression = N`, así que no se consulta | Completa |
| `SuppressionCheckService`, `SuppressedEntitiesClient`, `SharedVariableSuppressedEntitiesClient`, `InMemorySuppressedEntitiesClient` | Ver sección 4 | Dejar **una sola** implementación del cliente (si no, falla el arranque por dos beans); quién carga la lista | Con supuestos |

### 3.7 `mapper`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `UpdateOfferMapper` | Fachada: `toEmsXml`, `toLogRequestXml`, `toRestResponse`, `toLogResponseXml` | Nada | Completa |
| `OfferEventMapper` | Pestaña `Input` del JMS Queue Requestor: UpdateOfferRequest → campos del evento (obligatorios siempre, opcionales solo con valor, `UserField` corridos, relleno de `CustomerNO`, `ApptDate`, `ApptStartTime`, `UpdateTime`) | XPath de `ApptEndTime` (hoy igual que `ApptStartTime`). Valores de `CustomerPadding` y su longitud. De dónde sale `UserID` (alimenta `UpdatedBy`) | Con supuestos |
| `UpdateOfferRequestXmlMapper` | Arma el XML al EMS (`Envelope/Header/Body`) y el XML del log del request, ambos sin URLs | Confirmar el nombre del elemento del cuerpo (`UpdateOffer`). El log de BW traía `ServiceTimeout` en el header, no existe en `RqHeaderDTO` | Con supuestos |
| `UpdateOfferResponseXmlMapper` | Respuesta del EMS (XML o JSON) → `UpdateOfferResponse`; y XML del log de respuesta | Nombres reales de los campos de la respuesta; el formato del log de respuesta es un supuesto | Con supuestos |
| `RqHeaderXmlMapper` | `RqHeader` a XML para el EMS y para el log | Nada | Completa |
| `UserTextParser` | Convierte el JSON de `userText` en `UserField1..100` | Confirmar si `userText` podrá venir como arreglo (hoy el `@Pattern` lo rechaza) | Completa |
| `XmlUtil` | Escribe XML a mano y escapa caracteres | Nada | Completa |

### 3.8 `sender`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `EmsSender` | Envía el XML a la cola, espera la respuesta (`timeout-seconds`), la extrae (texto, bytes o map) y la deja en el log; modo `dry-run` | Unidad de `JMSExpiration` (hoy 0). Poner `dry-run: false` para enviar de verdad | Completa |
| `EmsQueueNameBuilder`, `EmsQueueProperties` | Arman la cola con el `concat` de las globales: `citi.gcg.la.cop_163621.mx_card.offer.update` (país en minúscula) | Origen del `DestCountryCode` (hoy `mx` fijo) | Con supuestos |
| `FulFillkafkaSender` | Flujo de Kafka: espera, consulta, ensambla el JSON del ejemplo, reglas de formato, publica con reintentos; asíncrono y aislado | Ver sección 3.9 | Con supuestos |

### 3.9 `kafka`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `OfferKafkaProps` | Propiedades `offer.kafka.*` | Cola del bridge y tópico (`CAMBIAR_...`) | Incompleta |
| `OfferInput` | Evento de entrada (paso 0) | Nada | Completa |
| `KafkaSenderDashboard` | Arma el `OfferInput` con el request, el header y la respuesta del EMS | Confirmar `sid` = `UUID` y `Action_ID` = `OfferAction` (sacados del ejemplo) | Con supuestos |
| `OfferKeyBuilder` | Claves: `off:mx:…:CUENTA:TARJETA` (del ejemplo), `RefID` con `_`, clave de la ola | Verificar con datos reales la clave de la ola (`wvch:OLA:CANAL`, viene de la guía) | Con supuestos |
| `OfferDataClient` | Consulta por la librería (`CopOfferFulfillmentService`) | Instalar la librería nueva; confirmar si `CitiDataStore` es la misma BD | Con supuestos |
| `OfferPublisher`, `DryRunOfferPublisher` | Interfaz y modo de prueba (escribe el JSON en el log, tarjeta enmascarada) | Nada | Completa |
| `JmsOfferPublisher` | Deja `{RefId, jsonString}` en la cola del bridge | Cola, modo de entrega y formato del mensaje | Incompleta |
| `KafkaExecutorConfig` | Ejecutor con cola acotada | Dimensionar con la volumetría real | Con supuestos |
| `KafkaMetrics` | Contadores en memoria (enviados, sin filas, inválidos, fallidos, rechazados) | No se exponen en Actuator ni Micrometer | Completa |
| `kafka-opcional/KafkaOfferPublisher` | Publicación directa a Kafka | Dependencia `spring-kafka`, tópico `lac.*`, seguridad (FID/keytab/certificado) y alta con la plataforma | Incompleta |

### 3.10 `audit` y `validation`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `AuditLogService` | `LogRequest`/`LogResponse`: activo si `AuditPointsEnabled` empieza con `1`; `ApplicationID` = nombre + `_` + CSI; escribe título + header en XML + payload (tarjeta enmascarada) | `ServiceName` del request (`v3_0_0_0`) y de la respuesta (`Offer`) son supuestos; `CountryCode` fijo en `MX`; `Hostname` y `CorrelationID` no se llenan | Con supuestos |
| `TransactionContext` | Datos de la transacción (`uuid`, `esbUuid`, hora) que usa el log | Nada | Completa |
| `DtoValidator` | Aplica las reglas obligatorio/opcional/lista de los DTOs y lanza error con el detalle | Nada | Completa |

### 3.11 Recursos y utilidades

| Archivo | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `update-offer.yml` | Toda la configuración (EMS, BD, globales, Kafka, auditoría) | Reemplazar los `CAMBIAR_...`; sacar las contraseñas (EMS y BD) a variables de entorno; confirmar `dry-run`; revisar `isKafkaOn_1` (hoy activa Kafka) | Con supuestos |
| `docs/kafka-sql-prueba.sql` | Para verificar tablas, columnas y claves reales en SQL Developer | Correrlo y pasar los resultados | Completa |
| `pruebas/probar.ps1`, `request-ejemplo.json` | Prueba manual del endpoint con `curl.exe` | Nada | Completa |

---

## 4. Clases tuyas (o de entregas anteriores) que no tengo

| Clase | Qué revisar |
|---|---|
| `UpdateOfferApplication` | `scanBasePackages = "com.banamex.cops.update_offer"` (la librería `cops-bd` se registra sola por autoconfiguración) |
| `jmsConfig` | Debe crear `updateOfferJmsTemplate` (lo piden `EmsSender` y `JmsOfferPublisher`) |
| `SecurityConfig` | Que permita el endpoint |
| `LoggingProperties`, `LogRequestService` | Reemplazados por `AuditLogService`: borrar si ya no los usas (y `update-offer.logging.*` del yml) |
| `Constants`, `ConstantsGeneric` | No sé qué contienen |
| `SuppressedEntitiesClient`, `SharedVariableSuppressedEntitiesClient`, `InMemorySuppressedEntitiesClient` | Deja **una sola** implementación; quién carga la lista de entidades suprimidas está pendiente de confirmar |
| `SuppressionCheckService` | Es tuya; mi test asume que el detalle de entrada se llama `OperationDetailsDTO` con setters |
| `UpdateOfferFlowConditions` | Tuya; contiene las condiciones de las transiciones |
| `CopsDbAutoConfiguration` (librería) | Agregar `CopOfferFulfillmentRepository.class` y `CopOfferFulfillmentServiceImpl.class` al `@Import` (ver `CAMBIOS-EN-CopsDbAutoConfiguration.md`) |

---

## 5. Librería `cops-bd` (solo la consulta)

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `CopOfferFulfillment` | Fila de la consulta (columnas crudas; `userFields` en una lista de 100) | Nada | Completa |
| `CopOfferFulfillmentNatives` | SQL con 100 `USERFIELD_n`, sin cálculos | Probarlo contra Oracle (nombres y tipos de columnas, esquema de las tablas) | Con supuestos |
| `CopOfferFulfillmentRepository` | Ejecuta el SQL con timeout de 10 s y máximo de 100 filas | Nada | Completa |
| `CopOfferFulfillmentService` y su `Impl` | Solo delegan | Nada | Completa |

---

## 6. Pruebas (34 clases en el micro + 2 de apoyo, y 3 en la librería)

| Paquete | Pruebas |
|---|---|
| `controller`, `config` | `UpdateOfferControllerTest`, `HeaderValidationTest` |
| `dto`, `validation` | `DtoValidationTest` (obligatorios, opcionales y listas), `UpdateOfferRequestValidationTest`, `KeyProcessEnumTest`, `DtoValidatorTest` |
| `service` | `RqHeaderFactoryTest`, `UpdateOfferServiceImplTest` |
| `service.timeZoneValidation` | `TimeZoneValidationServiceTest`, `InitTZTest`, `TimeZoneMapRequestTest`, `CopTimezoneLookupClientTest`, `UpdateOfferFlowConditionsTest` |
| `suppressed` | `PerformSuppressionCheckServiceTest`, `SuppressionCheckServiceTest`, `InMemorySuppressedEntitiesClientTest` |
| `mapper` | `OfferEventMapperTest`, `UpdateOfferRequestXmlMapperTest`, `UpdateOfferResponseXmlMapperTest`, `RqHeaderXmlMapperTest`, `UpdateOfferMapperTest`, `UserTextParserTest`, `XmlUtilTest` |
| `sender` | `EmsSenderTest`, `EmsQueueNameBuilderTest`, `FulFillkafkaSenderTest` |
| `kafka` | `OfferKeyBuilderTest`, `KafkaSenderDashboardTest`, `OfferDataClientTest`, `DryRunOfferPublisherTest`, `JmsOfferPublisherTest`, `KafkaMetricsTest` |
| `audit` | `AuditLogServiceTest`, `TransactionContextTest` |
| `testutil` | `TestData`, `XmlTestUtil` (apoyo) |
| librería | `CopOfferFulfillmentNativesTest`, `CopOfferFulfillmentRepositoryTest`, `CopOfferFulfillmentServiceImplTest` |

**Sin pruebas:** `OfferKafkaProps`, `OfferJmsProperties`, `EmsQueueProperties` (el enlace con el yml), `KafkaExecutorConfig`, `KafkaOfferPublisher` (opcional), las clases tuyas (`jmsConfig`, `SecurityConfig`, `UpdateOfferApplication`) y los DTOs de solo datos.
**Falta un tipo completo de prueba:** no hay pruebas de integración (contexto de Spring completo, EMS real, BD real). Ninguna de las pruebas se ha ejecutado todavía.

---

## 7. Orden sugerido para cerrar

1. Instalar la librería nueva (`CopsDbAutoConfiguration` + `mvn clean install`) y compilar el micro; corregir lo que salga (ver nota de nombres en la sección 4).
2. Correr las pruebas unitarias.
3. Probar el flujo con `dry-run: false` y pasar la respuesta real del EMS (`[EMS] Respuesta recibida`).
4. Correr `kafka-sql-prueba.sql` y confirmar las claves y las columnas.
5. Resolver la tabla de `RqHeader` / `ClientDetails` (origen de `Org`, `OrgUnit`, `TerminalID`, `UserID`, `DestCountryCode`).
6. Resolver los pendientes de Kafka (cola del bridge, `AB-KafkaSender...`, `CitiDataStore`).
7. Antes de activar `TranslateTimeZone`, comparar la conversión de horas con una ejecución real de BW.
