# Qué falta para cerrar el desarrollo (sin dejar suposiciones)

Leyenda: **CONFIRMADO** = lo dijiste tú, viene en tus archivos o se ve en una captura. **SUPUESTO** = el código lo asume. **FALTA** = no hay dato.

---

## A. GetContext y ClientDetails

**CONFIRMADO:** el `GetContext` (`RqHeader` y `ClientDetails`) llega en los **headers HTTP**. `RqHeaderFactory` los lee y ya no hay valores fijos en el yml. Los nombres por defecto son los del esquema de BW y se cambian en `update-offer.header-names.*` si el API Gateway usa otros.

| Campo del RqHeader | Header | Obligatorio | Estado |
|---|---|---|---|
| `UUID` | `uuid` | sí | **CONFIRMADO** (no se genera) |
| `ESBUUID` | `ESBUUID` | no (?) | Si llega, se usa; si no, `uuid` + `yyyyMMddHHmmss` (decisión tuya). En BW es un GUID aleatorio |
| `DateAndTimeStamp` | `DateAndTimeStamp` | sí | Si llega, se usa (con o sin offset); si no, la hora actual |
| `ServiceTimeout` | `ServiceTimeout` | no | El log de BW trae `12000`. Va en el log y en el header del mensaje al EMS cuando llega |
| `Version` | `Version` | no (?) | El log de BW trae `3.0.MX.0`. Sin header, se omite |
| `ClientDetails/Org`, `OrgUnit`, `TerminalID` | `Org`, `OrgUnit`, `TerminalID` | sí | **SUPUESTO el nombre del header** |
| `ClientDetails/UserID` | `UserID` | sí (puede ir vacío) | **SUPUESTO el nombre del header.** Alimenta `UpdatedBy` |
| `ClientDetails/ChannelID` | `ChannelId` | sí | Header del swagger |
| `ClientDetails/SrcCountryCode`, `DestCountryCode` | `SrcCountryCode`, `DestCountryCode`; si no llegan, `countryCode` | sí | **SUPUESTO el nombre del header** |
| `ClientDetails/SessionLanguageCode` | `SessionLanguageCode`; si no llega, `Accept-Language` | no (?) | Supuesto |
| `ClientIPAddress`, `UserDomicileBranchCode`, `UserDomicileResponsibilityCentre`, `ProcessingBranchCode`, `ProcessingResponsibilityCentre`, `UserGroup` | el nombre del campo | no (?) | **SUPUESTO el nombre del header** |

Si falta un obligatorio, la respuesta es **400** con el detalle (por ejemplo `clientDetails.org: El campo Org es obligatorio`). Los headers `sid`, `businessCode` y `host` siguen validándose como obligatorios, pero no alimentan ningún campo del `RqHeader`.

**Lo que falta confirmar:** los **nombres reales de los headers** que mandará el API Gateway y qué headers son obligatorios en el swagger.

---

## B. Mensaje al EMS y su respuesta

| Tema | Estado | Qué falta |
|---|---|---|
| Estructura `Envelope/Header/Body` sin URLs | **CONFIRMADO** | — |
| Cola `citi.gcg.la.cop_163621.mx_card.offer.update`, armada con el `concat` de las globales | **CONFIRMADO** (es la que usa tu broker; el país va en minúscula) | El `mx` sale hoy de la configuración; falta el origen del `DestCountryCode` |
| Va por la rama "XSD Format" | **CONFIRMADO** | — |
| `RequestTimeout_Category1 = 7` | **CONFIRMADO** (segundos) | — |
| `JMSExpiration = 30` | **FALTA la unidad** | En milisegundos el mensaje expiraría a los 30 ms. Hoy el yml deja `0` (sin expiración). Confirmar si BW lo trata como segundos |
| Nombre del elemento del cuerpo (`UpdateOffer`) | SUPUESTO | Como ya manda el XML y el EMS responde, confirmar que ese es el correcto |
| Campos de la **respuesta** del EMS | **CONFIRMADO** por el log de BW: `ResponseCode`, `ResponseText` y `ControlField` repetido (el 1.º es el tipo de contexto; el 2.º, un número o vacío) | Falta una respuesta real de tu ambiente (`[EMS] Respuesta recibida`) para confirmar que es igual |
| Varias ofertas en un solo mensaje al EMS | **CONFIRMADO: sí** (el JMS manda múltiples ofertas) | El log que pasaste solo trae peticiones de **una** oferta y no incluye el mensaje JMS: falta la estructura exacta del `Body` con varias ofertas y cómo responde el EMS (una respuesta por oferta o una sola). Hoy el micro manda un mensaje por oferta |
| Formato del log de la respuesta (`LogPayload` > `RsHeader` + `Body/UpdateOfferRs`) | **CONFIRMADO** por el log de BW | `RsHeader/ResponseCode`: solo se vio `0`; para `ERROR` el micro pone `1` (supuesto) |
| XPath de `ApptEndTime` | **FALTA** | `JMS Queue Requestor` > `Input` > `ApptEndTime - [Choose]`, abrir `[When]` y `[Otherwise]` |

---

## C. Zona horaria

| Tema | Estado | Qué falta |
|---|---|---|
| Valores de `TranslateTimeZone` (false), `ECRMTimeZone` (US/Central), `TimeZoneDateTimeFormat`, `BETimeFormat`, `BEDateTimeFormat` | **CONFIRMADO** | — |
| **`US/Central` y el horario de verano** | **FALTA aclarar** | US/Central tiene horario de verano de EE.UU. (en octubre es −05:00), pero tu ejemplo de Kafka muestra `−06:00` el 28 de octubre. ¿La hora del evento sale del servidor (hora de México) y no de `ECRMTimeZone`? |
| `System` y `SysMode` (hoy `COPS`, `RT`) | **FALTA** | `OpUpdateOffer` > `RequestTimeZoneValidation` > `Input` |
| Códigos `COP_TZCOD_000` y `COP_TZCOD_101` | **FALTA** | `/BW/Common/TimeZoneValidation` > `End` > `Input` y `ErrorVar` |
| Hora y fecha-hora en Request (convertir de la zona del cliente a ECRM) | SUPUESTO | Viene de la guía, no de una captura. Comparar con una ejecución real antes de activar `translate-time-zone` |
| Contenido de `COP_TIMEZONE_LOOKUP` | **FALTA** | `SELECT * FROM COP_TIMEZONE_LOOKUP` |
| `CustomerPadding` y longitud del `pad-front` (`COP/Padding/CustomerNo`) | **FALTA** | No venían en tu lista de globales |

---

## D. Kafka

Con tu ejemplo de JSON quedaron resueltos: el nombre del evento (`Fulfillrequest`), el orden de los campos, el `sid`, el formato del `RefID`, `Action_ID`, los formatos de fecha y la omisión de campos nulos. Qué falta:

| # | Dato que falta | Dónde se obtiene | Por qué hace falta |
|---|---|---|---|
| 1 | ¿Se envía por el bridge JMS o directo a Kafka? | Equipo de la plataforma | Define `offer.kafka.mode` (hoy `dry-run`) |
| 2 | **Cola, conexión, modo de entrega y expiración del bridge** | `/BW/Kafka/FulFillKafkaSender` > `KafkaMsgSender` > `Configuration` | Hoy `queue` es `CAMBIAR_COLA_DEL_BRIDGE` |
| 3 | Formato del mensaje a la cola (`RefId` / `jsonString`, JSON o XML) | Misma actividad > `Input` | Hoy se asume un JSON con esos dos campos |
| 4 | **Formato de las claves de la BD** | Bloque 2 de `kafka-sql-prueba.sql` | La clave de la oferta sale de tu ejemplo (`off:mx:CAMPAÑA:OLA:CLIENTE:CUENTA:TARJETA`); la de la ola (`wvch:OLA:CANAL`) es de la guía y no tiene evidencia |
| 5 | **De qué columna sale `OfferStartDate`** | Mapper de `FulFillKafkaSender` | Hoy usa `OFFERCREATIONDATE_TM` (por la fecha del ejemplo) |
| 6 | Si el evento debe llevar `ReasonCode`, `ReasonDesc`, `ProductType`, `ProductFamily`, `CategoryID`, `AppointmentStartDate` y `AppointmentMinDur` | Contrato del consumidor | La consulta los trae, pero el ejemplo no los incluye; hoy **no se envían** |
| 7 | Nombres y tipos reales de tablas y columnas | Bloques 1 y 4 de `kafka-sql-prueba.sql` | La consulta no se ha probado contra Oracle |
| 8 | **¿`CitiDataStore` es la misma BD `RMXCOP4`?** | Recurso JDBC `CitiDataStore` en el proyecto de BW | La consulta usa el `spring.datasource` de `cops-bd` |
| 9 | **Qué son `AB-KafkaSender...` y `AbInitioResponse`** | `OpUpdateOffer`: el diagrama muestra **dos** llamadas a Kafka y una actividad `AbInitioResponse` | Puede haber un segundo envío con otro destino |
| 10 | Si `CustomerNo` ya llega con 9 dígitos | Un request real | En la clave y en el `RefID` va tal como llega; el body lo rellena a 9 |
| 11 | Si el `sid` es siempre el `UUID` | Mapper de `KafkaSenderDashboard` | En tu ejemplo son iguales; la guía decía `ESBUUID` |
| 12 | Si `CardNumber` va completa | Seguridad / consumidor | El ejemplo la trae completa; hoy va completa (`mask-card-number: false`) |
| 13 | Contrato del consumidor (esquema del evento `Fulfillrequest` 1.0) | Equipo consumidor | `OfferStatus` es obligatorio para Kafka y opcional en tu API: esas ofertas se descartan |
| 14 | Si falla: reintentos, alerta, cola de errores | Operación | Hoy: 3 intentos y un `KAFKA-ERROR` en el log |
| 15 | Volumetría (transacciones por segundo) | Negocio | Para dimensionar el ejecutor |
| 16 | Si es Kafka directo: tópico `lac.*`, brokers, seguridad, FID/keytab, tarjeta Jira MIATR, DR | Plataforma Kafka | Solo para `mode: kafka` |

**Ojo:** con `isKafkaOn_1 = true` el flujo de Kafka ya está activo en el yml. Mientras la librería `cops-bd` nueva no esté instalada, cada petición escribirá `KAFKA-ERROR` en el log (no afecta la respuesta). Si molesta, pon `offer.kafka.enabled: false` mientras tanto.

---

## E. Decisiones abiertas

1. ~~Un mensaje por oferta o uno por lote~~: **resuelta, va un solo mensaje con todas las ofertas.** Falta implementarlo (ver sección B).
2. **`*` como lista:** hoy una lista vacía es válida; si "de uno a muchos" significa mínimo uno, hay que agregar `@NotEmpty`.
3. **Header `sid`:** ¿se registra en algún campo del log o del RqHeader?
4. **`CountryCode` del log de auditoría:** hoy fijo en `MX`; en BW es el `DestCountryCode`.
5. **Lo que ibas a preguntar:** el origen de `Org`, `OrgUnit`, `TerminalID` y `UserID` (sección A), y quién carga la lista de entidades suprimidas y cuál de las dos clases cliente se conserva.

---

## F. Suposiciones activas en el código

| Archivo | Suposición | Se confirma con |
|---|---|---|
| `RqHeaderFactory` | Tabla A | Sección A |
| `EmsQueueNameBuilder` | `DestCountryCode` = `MX` | Sección A (Apigee) |
| `UpdateOfferRequestXmlMapper.toEmsXml` | El cuerpo es un elemento `UpdateOffer` con los campos del evento | Sección B |
| `UpdateOfferResponseXmlMapper` | `RsHeader/ResponseCode` = `1` cuando el micro responde `ERROR` | Respuesta real de tu ambiente |
| `OfferEventMapper` | `ApptEndTime` igual que `ApptStartTime`; relleno de `CustomerNO` a 9 | XPath de `ApptEndTime`; sección C |
| `TimeZoneMapRequest` | Request: hora y fecha-hora convertidas de la zona del cliente a ECRM | Sección C |
| `TimeZoneValidationService` | Códigos `000` y `101`; `System` y `SysMode` | Sección C |
| `FulFillkafkaSender` | `OfferStartDate` ← `OFFERCREATIONDATE_TM`; campos que no se envían; clave de la ola | Sección D, puntos 4 a 6 |
| `JmsOfferPublisher` | Cuerpo `{RefId, jsonString}`; `JMSCorrelationID` = RefID | Sección D, puntos 2 y 3 |
| `AuditLogService` | `ServiceName` del request y de la respuesta; `CountryCode` fijo | Sección E |
