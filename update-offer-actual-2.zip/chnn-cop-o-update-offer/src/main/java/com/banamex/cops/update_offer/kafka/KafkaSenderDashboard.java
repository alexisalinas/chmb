package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Paso 0 (BW: actividad KafkaSenderDashboard dentro de OpUpdateOffer).
 * Toma el request, los headers HTTP y la respuesta del EMS (UpdateOfferRes -> ResponseCode / ResponseText).
 * Formatos tomados del ejemplo del evento:
 *   transactionTime  yyyy-MM-dd'T'HH:mm:ss.SSS          (hora en que se recibió la petición, sin offset)
 *   ResponseTime     yyyy-MM-dd'T'HH:mm:ss.SSSXXX       (hora en que respondió el EMS)
 *   Action_ID        = OfferAction del request (offerActionCode)
 */
@Component
@RequiredArgsConstructor
public class KafkaSenderDashboard {

    private static final DateTimeFormatter TRANSACTION_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    private static final DateTimeFormatter WITH_OFFSET = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    private final OfferKeyBuilder keys;

    /**
     * Arma el evento de entrada del envío a Kafka con el request, los headers HTTP y la respuesta del EMS.
     *
     * @param rq          oferta recibida
     * @param headers     headers HTTP de la petición (de ahí sale el uuid)
     * @param requestTime hora en que se recibió la petición
     * @param rs          respuesta del EMS (puede ser nula)
     * @return el evento de entrada con las claves ya construidas
     */
    public OfferInput build(UpdateOfferRequest rq, UpdateOfferHeaders headers, LocalDateTime requestTime,
                            UpdateOfferResponse rs) {
        LocalDateTime time = requestTime != null ? requestTime : LocalDateTime.now();
        return OfferInput.builder()
                .uuid(headers.getUuid())
                .channel(rq.getChannelCode())                  // RequestingChannel
                .transactionTime(time.format(TRANSACTION_TIME))
                .refId(keys.refId(rq.getCampaignId(), rq.getWaveId(), rq.getCustomerId(), rq.getAccountNumber(), rq.getCardNumber()))
                .offerKey(keys.offerKey(rq.getCampaignId(), rq.getWaveId(), rq.getCustomerId(), rq.getAccountNumber(), rq.getCardNumber()))
                .campaignId(rq.getCampaignId())
                .waveId(rq.getWaveId())
                .customerNo(rq.getCustomerId())                // sin modificar (sin ceros)
                .accountNo(rq.getAccountNumber())
                .cardNumber(rq.getCardNumber())
                .offerStatus(rq.getOfferStatus())
                .actionId(rq.getOfferActionCode())             // según el ejemplo: PROCESSCALL_ON_...
                .responseTime(OffsetDateTime.now().format(WITH_OFFSET))
                .responseCode(rs != null ? rs.getCode() : null)
                .responseText(rs != null ? rs.getDescription() : null)
                .build();
    }
}
