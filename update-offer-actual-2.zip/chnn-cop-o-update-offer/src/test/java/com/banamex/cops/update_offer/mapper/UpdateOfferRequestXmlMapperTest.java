package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.config.OfferJmsProperties;
import com.banamex.cops.update_offer.testutil.TestData;
import com.banamex.cops.update_offer.testutil.XmlTestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import org.w3c.dom.Document;
import tools.jackson.databind.json.JsonMapper;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias de {@code UpdateOfferRequestXmlMapper}.
 * <p>
 * Casos cubiertos: estructura del XML al EMS (con y sin {@code Envelope}); que no lleve RqHeader ni ClientDetails;
 * que no lleve URLs ni prefijos; campos transformados; escape de caracteres; nombre del elemento configurable.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class UpdateOfferRequestXmlMapperTest {

    private UpdateOfferRequestXmlMapper mapper;

    @BeforeEach
    void setUp() {
        OfferJmsProperties props = new OfferJmsProperties();
        props.setCustomerPadding(true);
        UserTextParser parser = new UserTextParser(JsonMapper.builder().build());
        OfferEventMapper event = new OfferEventMapper(props, parser);
        ReflectionTestUtils.setField(event, "translateTimeZone", false);
        ReflectionTestUtils.setField(event, "ecrmTimeZone", "America/Mexico_City");
        mapper = new UpdateOfferRequestXmlMapper(event);
        ReflectionTestUtils.setField(mapper, "bodyElement", "UpdateOffer");
        ReflectionTestUtils.setField(mapper, "envelope", true);
    }

    // ------------------------------------------------------------ estructura

    @Test
    void emsXml_tieneLaEstructuraEnvelopeBody_sinHeader() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        String xml = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);

        // Then
        Document doc = XmlTestUtil.parse(xml);
        assertThat(doc.getDocumentElement().getNodeName()).isEqualTo("Envelope");
        assertThat(XmlTestUtil.childNames(doc, "Envelope")).containsExactly("Body");
        assertThat(XmlTestUtil.childNames(doc, "Body")).containsExactly("UpdateOffer");
    }

    @Test
    void emsXml_noLlevaRqHeaderNiClientDetails() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        String xml = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);

        // Then
        assertThat(xml).doesNotContain("<Header>", "RqHeader", "ClientDetails", "<UUID>", "<ESBUUID>", "<Org>", "<UserID>");
    }

    @Test
    void emsXml_sinEnvelope_vaSoloElEvento() {
        // Given
        ReflectionTestUtils.setField(mapper, "envelope", false);

        // When
        String xml = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);

        // Then
        Document doc = XmlTestUtil.parse(xml);
        assertThat(doc.getDocumentElement().getNodeName()).isEqualTo("UpdateOffer");
        assertThat(xml).doesNotContain("Envelope", "<Body>");
        assertThat(XmlTestUtil.childNames(doc, "UpdateOffer")).isNotEmpty();
    }

    @Test
    void emsXml_conYSinEnvelopeLlevaLosMismosCampos() {
        // Given
        String conEnvelope = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);
        ReflectionTestUtils.setField(mapper, "envelope", false);

        // When
        String sinEnvelope = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);

        // Then
        assertThat(XmlTestUtil.childNames(XmlTestUtil.parse(conEnvelope), "UpdateOffer"))
                .isEqualTo(XmlTestUtil.childNames(XmlTestUtil.parse(sinEnvelope), "UpdateOffer"));
    }

    @Test
    void emsXml_noTieneUrlsNiPrefijos() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        String xml = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);

        // Then
        assertThat(XmlTestUtil.hasUrls(xml)).isFalse();
        assertThat(xml).doesNotContain("soapenv:", "head:", "ns0:", "ns1:", "ns:");
    }

    // ------------------------------------------------------------ contenido

    @Test
    void emsXml_llevaLosCamposTransformados() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        String xml = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);

        // Then
        assertThat(xml).contains("<RequestingChannel>CAT</RequestingChannel>",
                "<CardNO>1234567812345678</CardNO>",
                "<CustomerNO>0012345678</CustomerNO>",
                "<ApptStartTime>10:30</ApptStartTime>",
                "<UserField1>valor 1</UserField1>",
                "<UserField100>valor 100</UserField100>",
                "<UserField3></UserField3>");
    }

    @Test
    void emsXml_laHoraDeLaPeticionVaEnUpdateTime() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        String xml = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);

        // Then
        assertThat(xml).contains("<UpdateTime>2026-10-26T10:54:55.852</UpdateTime>");
    }

    @Test
    void emsXml_ningunElementoDelEventoSeRepite() {
        // Given
        // (sin precondiciones propias: se usan los datos de setUp)

        // When
        Document doc = XmlTestUtil.parse(mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null));

        // Then
        List<String> hijos = XmlTestUtil.childNames(doc, "UpdateOffer");
        assertThat(hijos).isNotEmpty().doesNotHaveDuplicates();
    }

    @Test
    void emsXml_escapaLosCaracteresEspeciales() {
        // Given
        var rq = TestData.request();
        rq.setComments("a & b < c");

        // When
        String xml = mapper.toEmsXml(rq, TestData.requestTime(), null, null);

        // Then
        assertThat(xml).contains("<Comments>a &amp; b &lt; c</Comments>");
        XmlTestUtil.parse(xml);
    }

    @Test
    void emsXml_usaElNombreDeElementoConfigurable() {
        // Given
        ReflectionTestUtils.setField(mapper, "bodyElement", "OtroEvento");

        // When
        String xml = mapper.toEmsXml(TestData.request(), TestData.requestTime(), null, null);

        // Then
        assertThat(xml).contains("<OtroEvento>", "</OtroEvento>");
    }
}
