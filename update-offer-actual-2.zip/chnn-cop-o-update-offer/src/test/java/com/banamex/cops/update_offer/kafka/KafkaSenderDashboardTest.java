package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.testutil.TestData;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias de {@code KafkaSenderDashboard}.
 * <p>
 * Cada prueba se escribe con el esquema Given / When / Then.
 */
class KafkaSenderDashboardTest {

    private final KafkaSenderDashboard dashboard = new KafkaSenderDashboard(new OfferKeyBuilder(new OfferKafkaProps()));

    private UpdateOfferResponse respuesta() {
        UpdateOfferResponse r = new UpdateOfferResponse();
        r.setCode("COP_UPDOF_0");
        r.setDescription("Successfully update offer");
        return r;
    }

    @Test
    void armaElEventoDeEntradaConLosDatosDelRequestLosHeadersYLaRespuesta() {
        // Given
        // (sin precondiciones)

        // When
        OfferInput in = dashboard.build(TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

        // Then
        assertThat(in.getUuid()).isEqualTo("uuid-1");
        assertThat(in.getChannel()).isEqualTo("CAT");
        assertThat(in.getCampaignId()).isEqualTo("CAMP001");
        assertThat(in.getWaveId()).isEqualTo("WAVE01");
        assertThat(in.getCustomerNo()).isEqualTo("12345678");                  // sin ceros
        assertThat(in.getAccountNo()).isEqualTo("00112233445566");
        assertThat(in.getCardNumber()).isEqualTo("1234567812345678");
        assertThat(in.getOfferStatus()).isEqualTo("01");
        assertThat(in.getResponseCode()).isEqualTo("COP_UPDOF_0");
        assertThat(in.getResponseText()).isEqualTo("Successfully update offer");
    }

    @Test
    void refIdYOfferKeyUsanCampanaOlaClienteCuentaYTarjeta() {
        // Given
        // (sin precondiciones)

        // When
        OfferInput in = dashboard.build(TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

        // Then
        assertThat(in.getRefId()).isEqualTo("CAMP001_WAVE01_12345678_00112233445566_1234567812345678");
        assertThat(in.getOfferKey()).isEqualTo("off:mx:CAMP001:WAVE01:12345678:00112233445566:1234567812345678");
    }

    @Test
    void actionIdEsElOfferActionDelRequest() {
        // Given
        // (sin precondiciones)

        // When
        OfferInput in = dashboard.build(TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

        // Then
        assertThat(in.getActionId()).isEqualTo("UPD");

        var rq = TestData.request();
        rq.setOfferActionCode(null);
        assertThat(dashboard.build(rq, TestData.headers(), TestData.requestTime(), respuesta()).getActionId()).isNull();
    }

    @Test
    void transactionTimeEsLaHoraDeLaPeticionConMilisegundosYSinOffset() {
        // Given
        // (sin precondiciones)

        // When
        OfferInput in = dashboard.build(TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

        // Then
        assertThat(in.getTransactionTime()).isEqualTo("2026-10-26T10:54:55.852");
    }

    @Test
    void sinHoraDeLaPeticion_transactionTimeUsaLaHoraActual() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(dashboard.build(TestData.request(), TestData.headers(), null, respuesta()).getTransactionTime())
                .matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}");
    }

    @Test
    void responseTimeLlevaMilisegundosYOffset() {
        // Given
        // (sin precondiciones)

        // When
        OfferInput in = dashboard.build(TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

        // Then
        assertThat(in.getResponseTime()).matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}([+-]\\d{2}:\\d{2}|Z)");
    }

    @Test
    void sinRespuesta_elCodigoYElTextoQuedanNulos() {
        // Given
        // (sin precondiciones)

        // When
        OfferInput in = dashboard.build(TestData.request(), TestData.headers(), TestData.requestTime(), null);

        // Then
        assertThat(in.getResponseCode()).isNull();
        assertThat(in.getResponseText()).isNull();
    }
}
