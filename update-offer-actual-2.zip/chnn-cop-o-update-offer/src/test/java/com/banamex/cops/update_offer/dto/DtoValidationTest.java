package com.banamex.cops.update_offer.dto;

import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionList;
import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionResult;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailOutput;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailsDTO;
import com.banamex.cops.update_offer.dto.suppression.StartRequest;
import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntityDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.DateGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.DateTimeGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationResult;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationStartDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzFormatsDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.ValueItemDTO;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Reglas de los esquemas de BW: sin símbolo = obligatorio, ? = opcional, * = lista.
 * Obligatorio  -> la prueba exige que falle si falta.
 * Opcional (?) -> la prueba verifica que NO falle si falta.
 * Lista (*)    -> nunca es nula y se valida cada elemento (ruta lista[0].campo).
 */
class DtoValidationTest {

    private static Validator validator;

    @BeforeAll
    static void init() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    private static Set<String> paths(Object o) {
        return validator.validate(o).stream().map(ConstraintViolation::getPropertyPath)
                .map(Object::toString).collect(Collectors.toSet());
    }

    // ============================================================ supresión

    @Nested
    class Suppression {
        @Test
        void startRequestParams_requestingChannelEsOpcional() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new StartRequestParams())).containsExactlyInAnyOrder("countryCode", "currentOperationName");
            assertThat(paths(StartRequestParams.builder().countryCode("MX").currentOperationName("UpdateOffer").build())).isEmpty();
        }

        @Test
        void startRequest_exigeParamsYLosValidaAdentro() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new StartRequest())).containsExactly("requestParams");
            assertThat(paths(StartRequest.builder().requestParams(new StartRequestParams()).build()))
                    .contains("requestParams.countryCode", "requestParams.currentOperationName");
        }

        @Test
        void operationDetails_lostresCamposSonObligatorios() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new OperationDetailsDTO())).containsExactlyInAnyOrder("operationName", "operationFlag", "reqChannel");
        }

        @Test
        void suppressedEntity_obligatoriosOpcionalesYLista() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new SuppressedEntityDTO())).containsExactlyInAnyOrder(
                    "mode", "suppressionFlag", "operationFlag", "sourceSystem");     // CountryCode? y ChannelId? opcionales
            assertThat(new SuppressedEntityDTO().getOperationDetails()).isNotNull().isEmpty();

            SuppressedEntityDTO e = SuppressedEntityDTO.builder().mode("RT").suppressionFlag("Y").operationFlag("Y")
                    .sourceSystem("ECRM").operationDetails(List.of(new OperationDetailsDTO())).build();
            assertThat(paths(e)).contains("operationDetails[0].operationName");
        }

        @Test
        void suppressedEntitiesList_esListaYValidaCadaElemento() {
            // Given
            SuppressedEntitiesListRoot r = SuppressedEntitiesListRoot.builder()
                    .suppressedEntities(List.of(new SuppressedEntityDTO())).build();

            // When / Then
            assertThat(paths(r)).contains("suppressedEntities[0].mode");
            assertThat(new SuppressedEntitiesListRoot().getSuppressedEntities()).isNotNull().isEmpty();
        }

        @Test
        void operationDetailOutput_indicatorEsOpcional() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new OperationDetailOutput())).containsExactlyInAnyOrder(
                    "operationName", "reqChannel", "operationFlag", "countryCode", "responseCode", "responseText");
        }

        @Test
        void filteredSuppressionResult_camposObligatoriosYListaDeDetalles() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new FilteredSuppressionResult())).containsExactlyInAnyOrder(
                    "countryCode", "channelID", "suppressionFlag", "operationFlag", "mode", "sourceSystem");
            assertThat(new FilteredSuppressionResult().getOperationDetails()).isNotNull().isEmpty();
        }

        @Test
        void filteredSuppressionList_esListaYValidaCadaResultado() {
            // Given
            FilteredSuppressionList l = FilteredSuppressionList.builder().results(List.of(new FilteredSuppressionResult())).build();

            // When / Then
            assertThat(paths(l)).contains("results[0].countryCode", "results[0].mode");
            assertThat(new FilteredSuppressionList().getResults()).isNotNull().isEmpty();
        }

    }

    // ============================================================ zona horaria

    @Nested
    class TimeZone {
        @Test
        void start_obligatoriosYListasNoNulas() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new TimeZoneValidationStartDTO())).containsExactlyInAnyOrder("system", "sysMode", "type");
            TimeZoneValidationStartDTO s = new TimeZoneValidationStartDTO();
            assertThat(s.getDate()).isNotNull().isEmpty();
            assertThat(s.getTime()).isNotNull().isEmpty();
            assertThat(s.getDateTime()).isNotNull().isEmpty();
        }

        @Test
        void start_validaCadaElementoDeLasListas() {
            // Given
            TimeZoneValidationStartDTO s = TimeZoneValidationStartDTO.builder().system("COPS").sysMode("RT").type("Request")
                    .date(List.of(new ValueItemDTO("2026-10-25", null)))
                    .time(List.of(new ValueItemDTO("10:30:00", "T")))
                    .build();

            // When / Then
            assertThat(paths(s)).containsExactly("date[0].name");
        }

        @Test
        void valueItem_elValorEsOpcionalYElNombreObligatorio() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new ValueItemDTO())).containsExactly("name");
            assertThat(paths(new ValueItemDTO(null, "AppointmentDate"))).isEmpty();
        }

        @Test
        void formatsYLookUp_todosObligatorios() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new TzFormatsDTO())).hasSize(5);
            assertThat(paths(new TzLookUpDTO())).hasSize(8);
        }

        @Test
        void grupos_statusObligatorioPeroPuedeIrVacio_yNameOpcional() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new DateGrpDTO())).containsExactlyInAnyOrder("date", "dateStatus");
            assertThat(paths(new TimeGrpDTO())).containsExactlyInAnyOrder("time", "timeStatus");
            assertThat(paths(new DateTimeGrpDTO())).containsExactlyInAnyOrder("dateTime", "dateTimeStatus");
            assertThat(paths(new DateGrpDTO("2026-10-25T00:00:00-0600", "", null))).isEmpty();
        }

        @Test
        void mapRequestResult_listasNoNulasYValidaCadaGrupo() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new MapRequestResultDTO())).isEmpty();
            MapRequestResultDTO r = new MapRequestResultDTO();
            r.getDateGrp().add(new DateGrpDTO());
            r.getTimeGrp().add(new TimeGrpDTO());
            assertThat(paths(r)).contains("dateGrp[0].date", "timeGrp[0].timeStatus");
        }

        @Test
        void resultado_codeYTextObligatorios_formatsYDetalleOpcionales() {
            // Given
            // (sin precondiciones)

            // When / Then
            assertThat(paths(new TimeZoneValidationResult())).containsExactlyInAnyOrder("responseCode", "responseText");
            TimeZoneValidationResult ok = new TimeZoneValidationResult();
            ok.setResponseCode("COP_TZCOD_000");
            ok.setResponseText("Success");
            assertThat(paths(ok)).isEmpty();
        }
    }
}
