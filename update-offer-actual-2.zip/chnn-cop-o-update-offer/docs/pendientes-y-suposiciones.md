# Qué falta para cerrar el desarrollo (sin dejar suposiciones)

Leyenda: **CONFIRMADO** = lo dijiste tú, viene en tus archivos o se ve en una captura. **SUPUESTO** = el código lo asume. **FALTA** = no hay dato.

---

## A. Sin `RqHeader` ni `ClientDetails`

**Decisión:** el flujo ya no usa `RqHeader` ni `ClientDetails`. Se eliminaron `RqHeaderFactory`, `InvalidRqHeaderException`, `RqHeaderXmlMapper`, `RqHeaderDTO` y `ClientDetailsDTO`, y el bloque `update-offer.header` del yml.

| Antes salía del `RqHeader` | Ahora |
|---|---|
| `Header` del mensaje al EMS | **No se manda.** El XML lleva solo el evento `UpdateOffer` con sus campos |
| `UpdatedBy` (`ClientDetails/UserID`) | Va **vacío** (el elemento se escribe porque es obligatorio) |
| `UpdateTime` sin zona horaria | La hora en que se recibe la oferta |
| `uuid` del evento de Kafka | Header HTTP `uuid` |
| `transactionTime` de Kafka | La hora en que se recibe la oferta |
| `ESBUUID` | Ya no se usa |

Los headers que llegan se siguen validando con `HeaderValidation` (`uuid`, `ChannelId`, `sid`, `countryCode`, `businessCode`, `host`, `Accept`, `Content-Type`) y se muestran en el log `[REQUEST]`.

**Pendiente de confirmar con una respuesta real del EMS:**
1. ¿Acepta el mensaje **sin `Header`**? El que sí aceptó (respondió con un error de negocio) llevaba `Envelope/Header/Body`.
2. ¿Espera el `Envelope`? Con `update-offer.ems.envelope: false` se manda solo `<UpdateOffer>`.
3. ¿Acepta `UpdatedBy` vacío? Si necesita un valor, hay que decidir de dónde sale.

---

## B. Mensaje al EMS y su respuesta

| Tema | Estado | Qué falta |
|---|---|---|
| Estructura `Envelope/Header/Body` sin URLs | **CONFIRMADO** | — |
| Cola `citi.gcg.la.cop_163621.mx_card.offer.update` | **CONFIRMADO**: es una sola cola, fija en `update-offer.ems.queue` (ya no se arma con el `concat`) | — |
| Va por la rama "XSD Format" | **CONFIRMADO** | — |
| `RequestTimeout_Category1 = 7` | **CONFIRMADO** (segundos) | — |
| `JMSExpiration = 30` | **FALTA la unidad** | En milisegundos el mensaje expiraría a los 30 ms. Hoy el yml deja `0` (sin expiración). Confirmar si BW lo trata como segundos |
| Nombre del elemento del cuerpo (`UpdateOffer`) | SUPUESTO | Como ya manda el XML y el EMS responde, confirmar que ese es el correcto |
| Campos de la **respuesta** del EMS | **CONFIRMADO** por el log de BW: `ResponseCode`, `ResponseText` y `ControlField` repetido (el 1.º es el tipo de contexto; el 2.º, un número o vacío) | Falta una respuesta real de tu ambiente (`[EMS] Respuesta recibida`) para confirmar que es igual |
| Varias ofertas en un solo mensaje al EMS | **CONFIRMADO: sí** (el JMS manda múltiples ofertas) | **La respuesta es una por oferta**: según la guía de `OpUpdateOffer`, el mapper recorre un `UpdateOfferRes` por cada oferta (el parser ya lo soporta: `toRestResponses`). El `Start` también trae `UpdateOfferRq` repetido. **Falta la estructura del `Body` del mensaje con varias ofertas** (el log que pasaste solo trae peticiones de una). Hoy el micro manda un mensaje por oferta |
| Formato del log de la respuesta (`LogPayload` > `RsHeader` + `Body/UpdateOfferRs`) | **CONFIRMADO** por el log de BW | `RsHeader/ResponseCode`: solo se vio `0`; para `ERROR` el micro pone `1` (supuesto) |
| XPath de `ApptEndTime` | **FALTA** | `JMS Queue Requestor` > `Input` > `ApptEndTime - [Choose]`, abrir `[When]` y `[Otherwise]` |

---

## C. Zona horaria

| Tema | Estado | Qué falta |
|---|---|---|
| Valores de `TranslateTimeZone` (false), `ECRMTimeZone` (US/Central), `TimeZoneDateTimeFormat`, `BETimeFormat`, `BEDateTimeFormat` | **CONFIRMADO** | — |
| **`US/Central` y el horario de verano** | **FALTA aclarar** | US/Central tiene horario de verano de EE.UU. (en octubre es −05:00), pero tu ejemplo de Kafka muestra `−06:00` el 28 de octubre. ¿La hora del evento sale del servidor (hora de México) y no de `ECRMTimeZone`? |
| `System` y `SysMode` (hoy `COPS`, `RT`) | **FALTA** | `OpUpdateOffer` > `RequestTimeZoneValidation` > `Input` |
| Códigos `COP_TZCOD_000` y `COP_TZCOD_101` | **FALTA** | `/BW/Common/TimeZoneValidation` > `End` > `Input` y `ErrorVar` |
| Hora y fecha-hora en Request (convertir de la zona del cliente a ECRM) | SUPUESTO | Viene de la guía, no de una captura. Comparar con una ejecución real antes de activar `translate-time-zone` |
| Contenido de `COP_TIMEZONE_LOOKUP` | **FALTA** | `SELECT * FROM COP_TIMEZONE_LOOKUP` |
| `CustomerPadding` = `false` y longitud del `pad-front` (`COP/Padding/CustomerNo`) = `19` | **CONFIRMADO** | — (con `false` no se rellena `CustomerNO`) |

---

## D. Kafka

Con tu ejemplo de JSON quedaron resueltos: el nombre del evento (`Fulfillrequest`), el orden de los campos, el `sid`, el formato del `RefID`, `Action_ID`, los formatos de fecha y la omisión de campos nulos. Qué falta:

| # | Dato que falta | Dónde se obtiene | Por qué hace falta |
|---|---|---|---|
| 1 | ¿Se envía por el bridge JMS o directo a Kafka? | Equipo de la plataforma | Define `offer.kafka.mode` (hoy `dry-run`) |
| 2 | **Cola, conexión, modo de entrega y expiración del bridge** | `/BW/Kafka/FulFillKafkaSender` > `KafkaMsgSender` > `Configuration` | Hoy `queue` es `CAMBIAR_COLA_DEL_BRIDGE` |
| 3 | Formato del mensaje a la cola (`RefId` / `jsonString`, JSON o XML) | Misma actividad > `Input` | Hoy se asume un JSON con esos dos campos |
| 4 | **Formato de las claves de la BD** | Bloque 2 de `kafka-sql-prueba.sql` | La clave de la oferta sale de tu ejemplo (`off:mx:CAMPAÑA:OLA:CLIENTE:CUENTA:TARJETA`); la de la ola (`wvch:OLA:CANAL`) es de la guía y no tiene evidencia |
| 5 | **De qué columna sale `OfferStartDate`** | Mapper de `FulFillKafkaSender` | Hoy usa `OFFERCREATIONDATE_TM` (por la fecha del ejemplo) |
| 6 | Si el evento debe llevar `ReasonCode`, `ReasonDesc`, `ProductType`, `ProductFamily`, `CategoryID`, `AppointmentStartDate` y `AppointmentMinDur` | Contrato del consumidor | La consulta los trae, pero el ejemplo no los incluye; hoy **no se envían** |
| 7 | Nombres y tipos reales de tablas y columnas | Bloques 1 y 4 de `kafka-sql-prueba.sql` | La consulta no se ha probado contra Oracle |
| 8 | **¿`CitiDataStore` es la misma BD `RMXCOP4`?** | Recurso JDBC `CitiDataStore` en el proyecto de BW | La consulta usa el `spring.datasource` de `cops-bd` |
| 9 | **`AB-KafkaSender...` y `AbInitioResponse`** | Según la guía de `OpUpdateOffer`, **AbInitio** es un camino alterno que se usa solo si la global `AbInitioTest = 'Y'` (la respuesta sale de `ResponseJSON` o `ErrorResponse`). Falta confirmar el valor de `AbInitioTest` y qué envía `AB-KafkaSender` | Si en todos los ambientes es `N`, no hay que migrarlo |
| 10 | Si `CustomerNo` ya llega con 9 dígitos | Un request real | En la clave y en el `RefID` va tal como llega; el body lo rellena a 9 |
| 11 | Si el `sid` es siempre el `UUID` | Mapper de `KafkaSenderDashboard` | En tu ejemplo son iguales; la guía decía `ESBUUID` |
| 12 | Si `CardNumber` va completa | Seguridad / consumidor | El ejemplo la trae completa; hoy va completa (`mask-card-number: false`) |
| 13 | Contrato del consumidor (esquema del evento `Fulfillrequest` 1.0) | Equipo consumidor | `OfferStatus` es obligatorio para Kafka y opcional en tu API: esas ofertas se descartan |
| 14 | Si falla: reintentos, alerta, cola de errores | Operación | Hoy: 3 intentos y un `KAFKA-ERROR` en el log |
| 15 | Volumetría (transacciones por segundo) | Negocio | Para dimensionar el ejecutor |
| 16 | Si es Kafka directo: tópico `lac.*`, brokers, seguridad, FID/keytab, tarjeta Jira MIATR, DR | Plataforma Kafka | Solo para `mode: kafka` |

**Ojo:** con `isKafkaOn_1 = true` el flujo de Kafka ya está activo en el yml. Mientras la librería `cops-bd` nueva no esté instalada, cada petición escribirá `KAFKA-ERROR` en el log (no afecta la respuesta). Si molesta, pon `offer.kafka.enabled: false` mientras tanto.

---

## D2. Mapper final de `OpUpdateOffer` (el que arma `UpdateOfferRes`)

Según `guia_OpUpdateOffer.md`:

| Caso del mapper | Qué hace en BW | En el micro | Qué falta |
|---|---|---|---|
| **1.** Existe el `ResponseCode` de zona horaria | Responde con su `ResponseCode` y `ResponseText`; `ContactReference`, `StartDate`, `EndDate` y `CmpMode` vacíos | **Implementado** (`UpdateOfferServiceImpl` + `UpdateOfferFlowConditions`) | El sub-`Choose` **`ControlField`** (colapsado). Y dos condiciones extra de la guía: `OfferStatus != "U"` y `CounterOfferAvailUpdate != 'Y'` |
| **2.** `OfferStatus = "U"` | Arma la llave `off:mx:...` (4 combinaciones de cuenta y tarjeta) y llena `UpdateOfferRes` **sin leer la respuesta del EMS ni de AbInitio** | La llave **ya está** (`OfferKeyBuilder`, con prueba de las 4 combinaciones). **Lo demás no** | El contenido de `UpdateOfferRes` de este caso (colapsado): `ResponseCode`, `ResponseText`, `ControlField` |
| **3.** Cualquier otro caso | `AbInitioTest='Y'`: respuesta de AbInitio; si no, la respuesta del JMS (un `UpdateOfferRes` por oferta) | La respuesta del JMS **sí** (una oferta por mensaje); AbInitio **no** | Valor de `AbInitioTest`; estructura del `Body` para varias ofertas |

Globales que salen de esta guía: `COP/ParametricConfiguration/CounterOfferAvailUpdate` = **`Y`** (confirmado) y `AbInitioTest` (falta su valor). Con `CounterOfferAvailUpdate = Y`, la condición corta del Notepad (`OfferStatus = "U"` y `CounterOfferAvailUpdate = 'Y'`) se cumple para los pedidos con estatus `U`, y la condición larga del error de zona horaria (que exige `CounterOfferAvailUpdate != 'Y'`) nunca se cumple. En el log que pasaste todas las peticiones tienen `OfferStatus` `G`, `K` o `R`; ninguna `U`. Todas las respuestas traen `COP_UPDOF_0` y `Successfully update offer off:mx:...`, así que ese texto lo arma el EMS en el flujo normal.

**Pendiente de tu parte (la guía lo pide):** expandir en TIBCO el `ControlField` del Caso 1 y el `UpdateOfferRes` del Caso 2, con la tabla de qué escribe cada campo.

---

## D3. `SetContext` (el `RsHeader` de la respuesta)

Según `migracion-updateoffer-setcontext.md`, `SetContext` arma el `RsHeader` de la respuesta de BW: `DateAndTimeStamp`, `UUID` y `ESBUUID` se copian del `GetContext`, y el `ResponseCode` sale así:

| Supresión (`Indicator`) | Global `COP/Connections/JSON/updateoffer` | `RsHeader/ResponseCode` |
|---|---|---|
| `"true"` | cualquiera | El `ResponseCode` del primer `ResponseDetails` de la supresión |
| distinto de `"true"` | distinto de `'Y'` | El `ResponseCode` de `Map-Data` (la respuesta final, camino JMS) |
| distinto de `"true"` | `'Y'` | El `ResponseCode` de `RsUpdateOffer` (camino REST/JSON del backend) |

**En el micro:** la API REST no devuelve `RsHeader` (la respuesta es la lista de ofertas), así que no hay nada que migrar para el cliente. La lógica de supresión ya coincide: si el `Indicator` es `"true"`, se responde con el `ResponseCode` y `ResponseText` del detalle, y las listas vacías o los `Indicator` nulos no fallan.

**Valor confirmado: `COP/Connections/JSON/updateoffer = Y`.** Entonces el `RsHeader/ResponseCode` sale de `RsUpdateOffer`, la respuesta de una llamada **REST/JSON** del backend (`RenderJSON` → `Invoke-REST` → `Parse-JSON`).

**Corrección a lo que dije antes:** había afirmado que esto explicaba el `RsHeader/ResponseCode = 0` del log de ejemplo frente a `COP_UPDOF_0` en el cuerpo. No se sostiene: según `guia_migracion_logresponse_tibco_a_java.md`, con `updateoffer = Y` el cuerpo que se registra también sale de `RsUpdateOffer`, así que cabecera y cuerpo tendrían el **mismo** código. El `0` del log de ejemplo sigue **sin explicación** (probablemente es de otra versión del proceso).

**Consecuencia:** en BW, con `updateoffer = Y`, además del mensaje JMS hay una llamada REST/JSON al backend, y el micro **no la hace**. Hoy el micro escribe `RsHeader/ResponseCode` = `0` (o `1` si responde `ERROR`), un supuesto que coincide con lo visto en el log.

**Preguntas:**
1. ¿Qué es esa llamada REST (`Invoke-REST`): URL, método, JSON que manda (`RenderJSON`) y qué conexión usa? ¿Va antes o después del JMS? ¿Si falla, cambia la respuesta al cliente o solo el `RsHeader`?
2. ¿Qué valor lleva `RsHeader/ResponseCode` en los casos de error y de supresión? (`SetContext` toma el código del primer detalle de supresión cuando el `Indicator` es `"true"`).

---

## D4. Logs (nuevo enfoque)

Cambio de rumbo: el micro ya no replica los logs de BW. Quedan solo estos, todos en JSON o con el mensaje tal cual:

| Log | Qué muestra | Dónde |
|---|---|---|
| `[REQUEST]` | Los **headers recibidos** y el **JSON del body** (tarjeta y headers de seguridad enmascarados) | `AuditLogService.logRequest`, al entrar |
| `[EMS] Envía` / `[EMS] Responde` | El XML que se manda al EMS y lo que responde | `EmsSender` |
| `[KAFKA] Recibe` / `[KAFKA] Envía` | El evento que recibe al inicio y el JSON que se le va a enviar (tarjeta enmascarada en el log) | `FulFillkafkaSender` |
| `[RESPONSE]` | El JSON que responde el micro (une `LogResponse` y `End`) | `AuditLogService.logResponse`, al salir |

- No hay logs en los subprocesos (zona horaria, supresión, etc.), salvo errores reales (`error`/`warn`).
- `AuditPointsEnabled` se conserva: posición 1 = `[REQUEST]`, posición 4 = `[RESPONSE]`. Con `1001` salen los dos.
- Se eliminaron los XML de log de BW (`<root>`, `LogPayload`, `RsHeader`), `TransactionContext` y los métodos `toLog...` de los mappers. Con eso dejan de aplicar las dudas anteriores sobre el formato del `Payload`, el `ServiceName` y el `RsHeader/ResponseCode`.
- El `ClientDetails` ya no existe en el micro.

---

## D5. `End` de `OpUpdateOffer` (la respuesta que se devuelve al cliente)

Según `guia_migracion_end_updateoffer_tibco_a_java.md`, el `End` elige de dónde sale la respuesta (`ResponseCode`, `ResponseText`, `ControlField*`):

| Camino | Condición | Fuente | En el micro |
|---|---|---|---|
| When 1 | `Indicator != "true"` y `updateoffer != 'Y'` | `Map-Data/UpdateOfferRes` (camino JMS) | Respuesta del EMS (**sí**) |
| When 2 | `Indicator != "true"` y `updateoffer = 'Y'` | `RsUpdateOffer/UpdateOfferRes` (camino REST/JSON) | **No existe** |
| Otherwise | Supresión | Primer `ResponseDetails`: código y texto; sin `ControlField` | **Sí** (código y texto del detalle suprimido, sin `contextType`) |

**Lo más importante:** con `updateoffer = Y` (valor confirmado), BW devuelve al cliente la respuesta de la llamada **REST/JSON** (`RsUpdateOffer`) y **no** la del JMS (`Map-Data`). El micro hoy devuelve la del EMS. Hay que decidir con el equipo:
1. ¿El micro debe **sustituir** esa llamada REST por el mensaje al EMS (lo que hace hoy)? ¿O debe llamar a la REST del backend?
2. ¿Qué servicio es `Invoke-REST-API` (URL, JSON que manda)? ¿Cuál de los dos caminos (REST o JMS) es el que está en producción?
3. Con `updateoffer = Y`, ¿el JMS sigue ejecutándose en BW y su respuesta se ignora?

**Decisión sobre `Indicator` (lista):** en XPath, `Indicator != "true"` es verdadero si **al menos un** `Indicator` existe y es distinto de `"true"`.
- **Opción A (paridad con BW):** una lista `["true","false"]` **no** se considera suprimida y sigue el flujo normal.
- **Opción B (lo que hace hoy el micro):** si **algún** detalle trae `Indicator = "true"`, se responde con la supresión.

Recomiendo la B (la A parece un defecto de BW), pero conviene confirmarlo con datos reales: ¿puede `ResponseDetails` traer valores mezclados?

**Diferencias que dejé a propósito:**
- Si `PerformSuppressionCheck` no devuelve nada (ruta de error), BW responde con `ResponseCode` y `ResponseText` vacíos sin error. El micro continúa con el flujo normal hacia el EMS.
- `ControlField` se copia en el mismo orden que llega (lista, no conjunto): ya es así.

**Pendiente de tu parte:** el XSD o contrato de `UpdateOfferRs` (si se conserva el doble `UpdateOfferRs` anidado), los valores posibles de `Indicator` (¿solo `"true"` y `"false"`?), si el `ControlField` es un `For-each` que copia cada elemento, y si el proceso tiene otros `End` (por ejemplo, un camino de error).

---

## E. Decisiones abiertas

1. ~~Un mensaje por oferta o uno por lote~~: **resuelta, va un solo mensaje con todas las ofertas.** Falta implementarlo (ver sección B).
2. **Camino de la respuesta con `updateoffer = Y`:** REST/JSON del backend o EMS (sección D5).
3. **`*` como lista:** hoy una lista vacía es válida; si "de uno a muchos" significa mínimo uno, hay que agregar `@NotEmpty`.
4. **Header `sid`:** ¿se usa en algún campo?
5. **Lo que ibas a preguntar:** el origen de `Org`, `OrgUnit`, `TerminalID` y `UserID` (sección A), y quién carga la lista de entidades suprimidas y cuál de las dos clases cliente se conserva.

---

## F. Suposiciones activas en el código

| Archivo | Suposición | Se confirma con |
|---|---|---|

| `UpdateOfferRequestXmlMapper.toEmsXml` | El cuerpo es un elemento `UpdateOffer` con los campos del evento | Sección B |
| `UpdateOfferResponseXmlMapper` | `RsHeader/ResponseCode` = `1` cuando el micro responde `ERROR` | Respuesta real de tu ambiente |
| `OfferEventMapper` | `ApptEndTime` igual que `ApptStartTime`; relleno de `CustomerNO` a 9 | XPath de `ApptEndTime`; sección C |
| `TimeZoneMapRequest` | Request: hora y fecha-hora convertidas de la zona del cliente a ECRM | Sección C |
| `TimeZoneValidationService` | Códigos `000` y `101`; `System` y `SysMode` | Sección C |
| `FulFillkafkaSender` | `OfferStartDate` ← `OFFERCREATIONDATE_TM`; campos que no se envían; clave de la ola | Sección D, puntos 4 a 6 |
| `JmsOfferPublisher` | Cuerpo `{RefId, jsonString}`; `JMSCorrelationID` = RefID | Sección D, puntos 2 y 3 |
