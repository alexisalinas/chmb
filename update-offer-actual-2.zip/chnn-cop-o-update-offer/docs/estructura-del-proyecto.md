# Estructura del proyecto `chnn-cop-o-update-offer` y estado de cada clase

Estados: **Completa** (hecha; solo falta probarla contra el entorno real), **Con supuestos** (funciona, pero asume algo que hay que confirmar) e **Incompleta** (falta código o un dato para terminarla).
Los detalles de cada pendiente están en `pendientes-y-suposiciones.md`; las variables globales, en `variables-globales-bw.md`.

---

## Convenciones del código

- **Javadoc en español** en todas las clases y en todos los métodos públicos (con `@param`, `@return` y `@throws` donde aplica).
- **Pruebas con Given / When / Then:** cada método de prueba lleva los comentarios `// Given` (datos y simulaciones previas), `// When` (la acción que se prueba) y `// Then` (las verificaciones). Cuando la acción va dentro de la verificación (por ejemplo `assertThatThrownBy(() -> ...)`) se usa `// When / Then`. Cuando no hay datos previos propios se indica con una nota.
- Cada clase de prueba lleva un Javadoc con los casos que cubre.

---

## 0. Clases en uso por paquete (55 en el micro)

Se eliminaron las que ningún código usaba o que ya no hacen falta: `LogDTO`, `LogHeaderDTO`, `AdditionalInfoDTO`, `RqLogDTO`, `ResponseDetailsDTO`, y las del `RqHeader` (`RqHeaderFactory`, `InvalidRqHeaderException`, `RqHeaderXmlMapper`, `RqHeaderDTO` y `ClientDetailsDTO`).

| Paquete | Clases | Para qué sirven |
|---|---|---|
| `controller` | `UpdateOfferController` | Recibe el POST y pasa los headers al service |
| `config` | `HeaderValidation`, `OfferJmsProperties` | Valida los headers del swagger; relleno de `CustomerNO` |
| `validation` | `DtoValidator` | Aplica las reglas obligatorio / opcional / lista |
| `service` | `UpdateOfferService` | Contrato del service |
| `service.impl` | `UpdateOfferServiceImpl` | Orquesta todo el flujo |
| `service.timeZoneValidation` | `TimeZoneValidationService`, `InitTZ`, `TimeZoneLookupClient`, `CopTimezoneLookupClient`, `TimeZoneMapRequest` | Validación de zona horaria |
| `suppressed` | `PerformSuppressionCheckService` | Validación de supresión |
| `mapper` | `UpdateOfferMapper`, `UpdateOfferRequestXmlMapper`, `UpdateOfferResponseXmlMapper`, `OfferEventMapper`, `UserTextParser`, `XmlUtil` | Request → XML al EMS y respuesta del EMS → REST |
| `sender` | `EmsSender`, `FulFillkafkaSender` | Envío al EMS y flujo de Kafka |
| `kafka` | `KafkaSenderDashboard`, `OfferInput`, `OfferKeyBuilder`, `OfferDataClient`, `OfferKafkaProps`, `OfferPublisher`, `DryRunOfferPublisher`, `JmsOfferPublisher`, `KafkaExecutorConfig`, `KafkaMetrics` | Piezas del envío a Kafka |
| `audit` | `AuditLogService` | `[REQUEST]` y `[RESPONSE]` en JSON |
| `dto` | `UpdateOfferRequest`, `UpdateOfferResponse`, `UpdateOfferHeaders`, `ControlFieldDTO`, `KeyProcessEnum` | Contrato de la API |
| `dto.error` | `ErrorResponse`, `ErrorType` | Formato de error |
| `dto.suppression` | `StartRequest`, `StartRequestParams`, `SuppressedEntitiesListRoot`, `SuppressedEntityDTO`, `OperationDetailsDTO`, `FilteredSuppressionList`, `FilteredSuppressionResult`, `OperationDetailOutput` | Supresión |
| `dto.timeZoneValidation` | `TimeZoneValidationStartDTO`, `ValueItemDTO`, `TzFormatsDTO`, `TzLookUpDTO`, `DateGrpDTO`, `TimeGrpDTO`, `DateTimeGrpDTO`, `MapRequestResultDTO`, `TimeZoneValidationResult` | Zona horaria |

Fuera de `src`: `KafkaOfferPublisher` (en `kafka-opcional/`, solo si usas Kafka directo).

---

## 1. Árbol del proyecto

```
chnn-cop-o-update-offer
├─ src/main/java/com/banamex/cops/update_offer
│  ├─ UpdateOfferApplication.java ................ (tuya) arranque; escanea solo update_offer
│  ├─ controller/    UpdateOfferController
│  ├─ config/        HeaderValidation, OfferJmsProperties, jmsConfig*, SecurityConfig*, LoggingProperties*
│  ├─ constants/     Constants*, ConstantsGeneric*
│  ├─ dto/           UpdateOfferRequest, UpdateOfferResponse, ControlFieldDTO, KeyProcessEnum, UpdateOfferHeaders
│  │  ├─ error/            ErrorResponse, ErrorType
│  │  ├─ suppression/      StartRequest, StartRequestParams, SuppressedEntitiesListRoot, SuppressedEntityDTO,
│  │  │                    OperationDetailsDTO, FilteredSuppressionList, FilteredSuppressionResult,
│  │  │                    OperationDetailOutput
│  │  └─ timeZoneValidation/  TimeZoneValidationStartDTO, ValueItemDTO, TzFormatsDTO, TzLookUpDTO,
│  │                          DateGrpDTO, TimeGrpDTO, DateTimeGrpDTO, MapRequestResultDTO, TimeZoneValidationResult
│  ├─ service/       UpdateOfferService, LogRequestService*
│  │  ├─ impl/             UpdateOfferServiceImpl
│  │  └─ timeZoneValidation/  TimeZoneValidationService, InitTZ, TimeZoneLookupClient, CopTimezoneLookupClient,
│  │                          TimeZoneMapRequest, UpdateOfferFlowConditions*
│  ├─ suppressed/    PerformSuppressionCheckService, SuppressionCheckService*, SuppressedEntitiesClient*,
│  │                 SharedVariableSuppressedEntitiesClient*, InMemorySuppressedEntitiesClient*
│  ├─ mapper/        UpdateOfferMapper, OfferEventMapper, UpdateOfferRequestXmlMapper,
│  │                 UpdateOfferResponseXmlMapper, UserTextParser, XmlUtil
│  ├─ sender/        EmsSender, FulFillkafkaSender
│  ├─ kafka/         OfferKafkaProps, OfferInput, OfferKeyBuilder, KafkaSenderDashboard, OfferDataClient,
│  │                 OfferPublisher, DryRunOfferPublisher, JmsOfferPublisher, KafkaExecutorConfig, KafkaMetrics
│  ├─ audit/         AuditLogService
│  └─ validation/    DtoValidator
├─ src/main/resources/config/update-offer.yml
├─ src/test/java/...   (32 clases de prueba + 2 de apoyo; ver sección 6)
├─ docs/               estructura-del-proyecto.md, pendientes-y-suposiciones.md, variables-globales-bw.md, kafka-sql-prueba.sql
├─ pruebas/            probar.ps1, request-ejemplo.json
└─ kafka-opcional/     KafkaOfferPublisher (solo si se usa mode=kafka; requiere spring-kafka)

cops-bd (librería, com.banamex.cops.app)
├─ model/       CopOfferFulfillment                       (nuevo)
├─ natives/     CopOfferFulfillmentNatives                (nuevo)
├─ repository/  CopOfferFulfillmentRepository             (nuevo)
├─ service/     CopOfferFulfillmentService (+ impl/)      (nuevo)
├─ autoconfigure/ CopsDbAutoConfiguration                 (tuya: hay que registrar las 2 clases nuevas en @Import)
└─ ... CopTimezoneLookup*, CopOfferQuery, etc.            (tuyas)
```
`*` = clase tuya que yo no tengo (o de una entrega anterior): se describe en la sección 4.

## 2. Flujo completo (equivalente a `OpUpdateOffer`)

```
POST /sd-campaing-management/v1/update-offer
  HeaderValidation (headers requeridos) -> UpdateOfferController
  -> UpdateOfferServiceImpl (por cada oferta):
       AuditLogService.logRequest .... log de lo que recibe el micro (headers + JSON del body)
       TimeZoneValidationService ..... RequestTimeZoneValidation (solo si TranslateTimeZone = true)
       PerformSuppressionCheckService  PerformSuppressionCheck   (solo si CheckForSuppression = Y)
       UpdateOfferMapper.toEmsXml .... JMS Queue Requestor (Input)
       EmsSender.send ................ JMS Queue Requestor (envío y espera de respuesta)
       UpdateOfferMapper.toRestResponse  Parse JSON / RsUpdateOffer
       FulFillkafkaSender (asíncrono)  KafkaSenderDashboard + FulFillKafkaSender (si isKafkaOn_1 = true)
       AuditLogService.logResponse ... log de lo que responde el micro (JSON) = End + LogResponse
```

---

## 3. Clases del microservicio

### 3.1 `controller` y `config`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `UpdateOfferController` | Recibe el POST con la lista de ofertas, junta los headers en `UpdateOfferHeaders`, valida `countryCode` y el body (`@Valid`) y llama al service | Definir el código HTTP cuando alguna oferta falla (hoy siempre 200 con `code: ERROR` dentro). Los errores de `@Valid` y de JSON mal formado salen con el formato del manejador global (`digital-engineering`), no con `ErrorResponse`. Falta que el service mande todas las ofertas en un solo mensaje al EMS (confirmado que BW lo hace así) | Completa |
| `HeaderValidation` | Rechaza con 400 y `ErrorResponse` si falta un header de `@Required` (`uuid`, `ChannelId`, `sid`, `countryCode`, `businessCode`, `host`, `Accept`, `Content-Type`) | Confirmar que esa lista es definitiva | Completa |
| `OfferJmsProperties` | Propiedades del relleno de `CustomerNO` (activo, longitud, carácter) | Nada: `CustomerPadding = false` y longitud `19` confirmados | Completa |

### 3.2 `dto` (contrato de la API)

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `UpdateOfferRequest` | Cuerpo de cada oferta (4 obligatorios, resto opcional, `contextType` lista, `userText` con los UserFields) | `keyProcess` no se usa (la rama XSD es fija). El `@Pattern` de `userText` solo acepta un objeto `{...}`, no un arreglo. `offerStatus` es opcional aquí pero obligatorio para Kafka | Completa |
| `UpdateOfferResponse` | Respuesta por oferta (`code` y `description` obligatorios) | Confirmar los nombres de los campos de la respuesta real del EMS | Con supuestos |
| `ControlFieldDTO`, `KeyProcessEnum` | `ControlField` (solo `contextType`) y las versiones V1/V2/V3 | Nada | Completa |
| `UpdateOfferHeaders` | Headers del swagger en campos propios y `all` con **todos** los headers recibidos (sin distinguir mayúsculas), que se muestran en el log `[REQUEST]` | Nada | Completa |
| `error/ErrorResponse`, `ErrorType` | Formato de error de la validación de headers | Nada | Completa |

### 3.3 `dto.suppression`, `dto.timeZoneValidation` (esquemas de BW)

Todos llevan la regla de BW: sin símbolo = obligatorio, `?` = opcional, `*` = lista (nunca nula, se valida cada elemento).

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `StartRequest`, `StartRequestParams`, `SuppressedEntitiesListRoot`, `SuppressedEntityDTO`, `OperationDetailsDTO`, `FilteredSuppressionList`, `FilteredSuppressionResult`, `OperationDetailOutput` | Entrada y salida de la validación de supresión | Nada | Completa |
| `TimeZoneValidationStartDTO`, `ValueItemDTO` | `Start` de TimeZoneValidation (`System`, `SysMode`, `Type`, `Date*`, `Time*`, `DateTime*`) | Nada | Completa |
| `TzFormatsDTO`, `TzLookUpDTO` | `Formats` y `LookUp*` (todos los campos obligatorios) | Nada | Completa |
| `DateGrpDTO`, `TimeGrpDTO`, `DateTimeGrpDTO`, `MapRequestResultDTO`, `TimeZoneValidationResult` | Resultado de `MapRequest` y de `RequestTimeZoneValidation` | Nada | Completa |

### 3.4 `service`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `UpdateOfferService` | Contrato del service (`updateOffer(requests, headers)`) | Nada | Completa |
| `UpdateOfferServiceImpl` | Orquesta todo el flujo por oferta; valida los DTOs que arma; responde `ERROR` si algo falla; dispara Kafka sin afectar la respuesta | No implementa las ramas Counter Offer ni Json Format (indicaste que solo va la XSD). No arma el header de la respuesta (`SetContext`). Kafka solo se dispara si el EMS respondió; confirmar si BW también lo hacía con errores. Hoy manda un mensaje por oferta; confirmado que BW manda todas en uno solo (falta implementarlo) | Con supuestos |

### 3.5 `service.timeZoneValidation`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `TimeZoneValidationService` | `GetVariable` (caché) → `InitTZ` → `LookupTZ` → `SetVariable` → `MapRequest`; devuelve código y texto | Códigos `COP_TZCOD_000` y `101` (supuestos). La caché no se limpia nunca | Con supuestos |
| `InitTZ` | Busca sistema + modo + tipo en la caché y arma los `Formats` | Nada | Completa |
| `TimeZoneLookupClient`, `CopTimezoneLookupClient` | `LookupTZ`: consulta `COP_TIMEZONE_LOOKUP` por la librería; los NULL pasan a `""` | Nada (depende de que la BD esté configurada) | Completa |
| `TimeZoneMapRequest` | `MapRequest`: valida y convierte fecha, hora y fecha-hora (Request y Response) | La fecha, la hora y la fecha-hora en Request vienen de la guía, no de capturas; falta compararlas con una ejecución real. Duda con `US/Central` y el horario de verano | Con supuestos |
| `UpdateOfferFlowConditions` *(tuya)* | Condiciones de las transiciones del flujo | Nada | Completa |

### 3.6 `suppressed`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `PerformSuppressionCheckService` | `PerformSuppressionCheck`: si `CheckForSuppression = Y`, consulta la lista y aplica `CheckIfSuppressed`; si falla, devuelve vacío | El `ErrorLog` de BW es solo un `log.error`. Hoy `CheckForSuppression = N`, así que no se consulta | Completa |
| `SuppressionCheckService`, `SuppressedEntitiesClient`, `SharedVariableSuppressedEntitiesClient`, `InMemorySuppressedEntitiesClient` | Ver sección 4 | Dejar **una sola** implementación del cliente (si no, falla el arranque por dos beans); quién carga la lista | Con supuestos |

### 3.7 `mapper`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `UpdateOfferMapper` | Fachada: `toEmsXml`, `toRestResponse` y `toRestResponses` | Nada | Completa |
| `OfferEventMapper` | Pestaña `Input` del JMS Queue Requestor: UpdateOfferRequest → campos del evento (obligatorios siempre, opcionales solo con valor, `UserField` corridos, relleno de `CustomerNO`, `ApptDate`, `ApptStartTime`, `UpdateTime`) | XPath de `ApptEndTime` (hoy igual que `ApptStartTime`). Valores de `CustomerPadding` y su longitud. De dónde sale `UserID` (alimenta `UpdatedBy`) | Con supuestos |
| `UpdateOfferRequestXmlMapper` | Arma el XML al EMS: el evento `UpdateOffer` con los campos del JMS Queue Requestor, dentro de `Envelope/Body` (o solo el evento, con `update-offer.ems.envelope: false`). Sin `RqHeader` ni `ClientDetails`, ni URLs, namespaces o prefijos | Confirmar el nombre del elemento del cuerpo y si el EMS espera el `Envelope` | Con supuestos |
| `UpdateOfferResponseXmlMapper` | Respuesta del EMS (XML o JSON) → `UpdateOfferResponse`, una o **una por oferta** (`UpdateOfferRes` repetido, método `fromReplies`) | Confirmar con una respuesta real de tu ambiente; el service aún usa una sola respuesta por mensaje | Con supuestos |
| `UserTextParser` | Convierte el JSON de `userText` en `UserField1..100` | Confirmar si `userText` podrá venir como arreglo (hoy el `@Pattern` lo rechaza) | Completa |
| `XmlUtil` | Escribe XML a mano y escapa caracteres | Nada | Completa |

### 3.8 `sender`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `EmsSender` | Envía el XML a la cola y espera la respuesta (`timeout-seconds`). **Solo escribe en el log lo que envía (`[EMS] Envía`) y lo que responde (`[EMS] Responde`)**; modo `dry-run` | Unidad de `JMSExpiration` (hoy 0). Poner `dry-run: false` para enviar de verdad | Completa |
| `FulFillkafkaSender` | Flujo de Kafka: espera, consulta, ensambla el JSON del ejemplo, reglas de formato, publica con reintentos; asíncrono y aislado | Ver sección 3.9 | Con supuestos |

### 3.9 `kafka`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `OfferKafkaProps` | Propiedades `offer.kafka.*` | Cola del bridge y tópico (`CAMBIAR_...`) | Incompleta |
| `OfferInput` | Evento de entrada (paso 0) | Nada | Completa |
| `KafkaSenderDashboard` | Arma el `OfferInput` con el request, el header y la respuesta del EMS | Confirmar `sid` = `UUID` y `Action_ID` = `OfferAction` (sacados del ejemplo) | Con supuestos |
| `OfferKeyBuilder` | Claves: `off:mx:…:CUENTA:TARJETA` (del ejemplo), `RefID` con `_`, clave de la ola | Verificar con datos reales la clave de la ola (`wvch:OLA:CANAL`, viene de la guía) | Con supuestos |
| `OfferDataClient` | Consulta por la librería (`CopOfferFulfillmentService`) | Instalar la librería nueva; confirmar si `CitiDataStore` es la misma BD | Con supuestos |
| `OfferPublisher`, `DryRunOfferPublisher` | Interfaz y modo de prueba (solo avisa que no se publicó; el mensaje ya se ve en `[KAFKA] Envía`) | Nada | Completa |
| `JmsOfferPublisher` | Deja `{RefId, jsonString}` en la cola del bridge | Cola, modo de entrega y formato del mensaje | Incompleta |
| `KafkaExecutorConfig` | Ejecutor con cola acotada | Dimensionar con la volumetría real | Con supuestos |
| `KafkaMetrics` | Contadores en memoria (enviados, sin filas, inválidos, fallidos, rechazados) | No se exponen en Actuator ni Micrometer | Completa |
| `kafka-opcional/KafkaOfferPublisher` | Publicación directa a Kafka | Dependencia `spring-kafka`, tópico `lac.*`, seguridad (FID/keytab/certificado) y alta con la plataforma | Incompleta |

### 3.10 `audit` y `validation`

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `AuditLogService` | Escribe **dos logs en JSON**: `[REQUEST]` (los headers recibidos y el JSON del body) al entrar, y `[RESPONSE]` (el JSON que responde el micro) al salir. Enmascara la tarjeta y los headers de seguridad. `AuditPointsEnabled`: posición 1 = request, posición 4 = respuesta | Nada | Completa |
| `DtoValidator` | Aplica las reglas obligatorio/opcional/lista de los DTOs y lanza error con el detalle | Nada | Completa |

### 3.11 Recursos y utilidades

| Archivo | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `update-offer.yml` | Toda la configuración (EMS, BD, globales, Kafka, auditoría) | Reemplazar los `CAMBIAR_...`; sacar las contraseñas (EMS y BD) a variables de entorno; confirmar `dry-run`; revisar `isKafkaOn_1` (hoy activa Kafka) | Con supuestos |
| `docs/kafka-sql-prueba.sql` | Para verificar tablas, columnas y claves reales en SQL Developer | Correrlo y pasar los resultados | Completa |
| `pruebas/probar.ps1`, `request-ejemplo.json` | Prueba manual del endpoint con `curl.exe` | Nada | Completa |

---

## 4. Clases tuyas (o de entregas anteriores) que no tengo

| Clase | Qué revisar |
|---|---|
| `UpdateOfferApplication` | `scanBasePackages = "com.banamex.cops.update_offer"` (la librería `cops-bd` se registra sola por autoconfiguración) |
| `jmsConfig` | Debe crear `updateOfferJmsTemplate` (lo piden `EmsSender` y `JmsOfferPublisher`) |
| `SecurityConfig` | Que permita el endpoint |
| `LoggingProperties`, `LogRequestService` | Reemplazados por `AuditLogService` (ahora en JSON): borrar si ya no los usas (y `update-offer.logging.*` del yml) |
| `Constants`, `ConstantsGeneric` | No sé qué contienen |
| `SuppressedEntitiesClient`, `SharedVariableSuppressedEntitiesClient`, `InMemorySuppressedEntitiesClient` | Deja **una sola** implementación; quién carga la lista de entidades suprimidas está pendiente de confirmar |
| `SuppressionCheckService` | Es tuya; mi test asume que el detalle de entrada se llama `OperationDetailsDTO` con setters |
| `UpdateOfferFlowConditions` | Tuya; contiene las condiciones de las transiciones |
| `CopsDbAutoConfiguration` (librería) | Agregar `CopOfferFulfillmentRepository.class` y `CopOfferFulfillmentServiceImpl.class` al `@Import` (ver `CAMBIOS-EN-CopsDbAutoConfiguration.md`) |

---

## 5. Librería `cops-bd` (solo la consulta)

| Clase | Qué hace | Qué le falta | Estado |
|---|---|---|---|
| `CopOfferFulfillment` | Fila de la consulta (columnas crudas; `userFields` en una lista de 100) | Nada | Completa |
| `CopOfferFulfillmentNatives` | SQL con 100 `USERFIELD_n`, sin cálculos | Probarlo contra Oracle (nombres y tipos de columnas, esquema de las tablas) | Con supuestos |
| `CopOfferFulfillmentRepository` | Ejecuta el SQL con timeout de 10 s y máximo de 100 filas | Nada | Completa |
| `CopOfferFulfillmentService` y su `Impl` | Solo delegan | Nada | Completa |

---

## 6. Pruebas (32 clases en el micro + 2 de apoyo, y 3 en la librería)

| Paquete | Pruebas |
|---|---|
| `controller`, `config` | `UpdateOfferControllerTest`, `HeaderValidationTest` |
| `dto`, `validation` | `DtoValidationTest` (obligatorios, opcionales y listas), `UpdateOfferRequestValidationTest`, `KeyProcessEnumTest`, `DtoValidatorTest` |
| `service` | `UpdateOfferServiceImplTest` |
| `service.timeZoneValidation` | `TimeZoneValidationServiceTest`, `InitTZTest`, `TimeZoneMapRequestTest`, `CopTimezoneLookupClientTest`, `UpdateOfferFlowConditionsTest` |
| `suppressed` | `PerformSuppressionCheckServiceTest`, `SuppressionCheckServiceTest`, `InMemorySuppressedEntitiesClientTest` |
| `mapper` | `OfferEventMapperTest`, `UpdateOfferRequestXmlMapperTest`, `UpdateOfferResponseXmlMapperTest`, `RqHeaderXmlMapperTest`, `UpdateOfferMapperTest`, `UserTextParserTest`, `XmlUtilTest` |
| `sender` | `EmsSenderTest`, `FulFillkafkaSenderTest` |
| `kafka` | `OfferKeyBuilderTest`, `KafkaSenderDashboardTest`, `OfferDataClientTest`, `DryRunOfferPublisherTest`, `JmsOfferPublisherTest`, `KafkaMetricsTest` |
| `audit` | `AuditLogServiceTest` |
| `testutil` | `TestData`, `XmlTestUtil` (apoyo) |
| librería | `CopOfferFulfillmentNativesTest`, `CopOfferFulfillmentRepositoryTest`, `CopOfferFulfillmentServiceImplTest` |

**Sin pruebas:** `OfferKafkaProps`, `OfferJmsProperties` (el enlace con el yml), `KafkaExecutorConfig`, `KafkaOfferPublisher` (opcional), las clases tuyas (`jmsConfig`, `SecurityConfig`, `UpdateOfferApplication`) y los DTOs de solo datos.
**Falta un tipo completo de prueba:** no hay pruebas de integración (contexto de Spring completo, EMS real, BD real). Ninguna de las pruebas se ha ejecutado todavía.

---

## 7. Orden sugerido para cerrar

1. Instalar la librería nueva (`CopsDbAutoConfiguration` + `mvn clean install`) y compilar el micro; corregir lo que salga (ver nota de nombres en la sección 4).
2. Correr las pruebas unitarias.
3. Probar el flujo con `dry-run: false` y pasar la respuesta real del EMS (`[EMS] Respuesta recibida`).
4. Correr `kafka-sql-prueba.sql` y confirmar las claves y las columnas.
5. Confirmar con una respuesta real del EMS el formato del XML (con o sin `Envelope`) y qué espera en `UpdatedBy`.
6. Resolver los pendientes de Kafka (cola del bridge, `AB-KafkaSender...`, `CitiDataStore`).
7. Antes de activar `TranslateTimeZone`, comparar la conversión de horas con una ejecución real de BW.
